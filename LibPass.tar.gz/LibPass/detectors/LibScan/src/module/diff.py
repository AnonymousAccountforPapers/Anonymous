from operator import eq
import os
import json

cls_dict = "classes_dict_"
app_filter = "app_filter_"
attack = "/root/TPL/Attack/"
original = "/root/TPL/LibScan/tool/module/"

attack_cls_dict = attack+cls_dict+"attack.json"
original_cls_dict = original+cls_dict+"original.json"

attack_app_filter = attack+app_filter+"attack.json"
original_app_filter = original+app_filter+"original.json"

with open(attack_cls_dict) as f, open(original_cls_dict) as g:
    attack_cls_dict = json.load(f)
    original_cls_dict = json.load(g)
    
with open(attack_app_filter) as f, open(original_app_filter) as g:
    attack_app_filter = json.load(f)
    original_app_filter = json.load(g)
    
    
def dif(a, b, depth):
    if isinstance(a, dict) and isinstance(b, dict):
        for key in a:
            if key in b:
                if not dif(a[key], b[key], depth+1):
                    # print(f"depth:{depth} | DIFF:\n{a[key]}\n{b[key]}\n")
                    return False
            else:
                print(f"depth:{depth} key mismatch | DIFF:\n{a}\n{b}\n")
                return False
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            print("length not equal")
            print("Attack:")
            print(a)
            print("Original:")
            print(b)
            return False
        prim_type = True
        for item in a:
            if not isinstance(item, int) and not isinstance(item, float) and not isinstance(item, str):
                prim_type = False
                break
        if prim_type:
            equal = set(a) == set(b)
            if not equal:
                print(f"equal: {equal}")
            return equal
        else:
            for i in range(len(a)):
                if not dif(a[i], b[i], depth+1):
                    print(f"depth:{depth} | DIFF:")
                    for item in a[i]:
                        print(item)
                    print("---")
                    for item in b[i]:
                        print(item)
                    print("===")
                    if len(a[i]) > len(b[i]):
                        print("Miss:", set(a[i])-set(b[i]))
                    else:
                        print("Miss:", set(b[i])-set(a[i]))
                    return False
    elif not isinstance(a, dict) and not isinstance(b, dict):
        return a==b
    else:
        print(f"depth:{depth} | DIFF:\n{a}\n{b}\n")
        return False
    return True
    
if dif(attack_cls_dict, original_cls_dict, 0):
    print("Equal")
else:
    print("Not Equal\n\n\n")
    

if dif(attack_app_filter, original_app_filter, 0):
    print("Equal")
else:
    print("Not Equal")