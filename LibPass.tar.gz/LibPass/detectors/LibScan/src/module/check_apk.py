from apk_for_check import Apk


if __name__ == "__main__":
    apk_path = "/root/TPL/LibScan/data/ground_truth_apks/"+"me.shrimadhavuk.watransmitter.apk"
    apk = Apk(apk_path)