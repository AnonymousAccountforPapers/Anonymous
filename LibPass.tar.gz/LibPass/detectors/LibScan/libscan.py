import sys
from detectors.LibScan.src.module.analyzer import search_lib_in_one_app
from detectors.base import Detector
from detectors.LibScan.src.module.config import lib_similar


class LibScan(Detector):
    def __init__(self):
        super().__init__()
        self.threshold = lib_similar
        
    @Detector.measure_time
    def __call__(self, sample_path, score=False):
        self.total += 1
        
        apk_path, lib_dex_path = sample_path
        detect_res = search_lib_in_one_app(lib_dex_path, apk_path)
        if score:
            if detect_res >= self.threshold:
                return detect_res
            else:
                return 0
        else:
            if detect_res < self.threshold:
                return 0
            return 1
        