# -*- coding: utf-8 -*-
# ************************************
# @Author           : Bolin Zhou
# @File             : __init__.py
# @Create           : 2023/3/24
# @LastModified     : 2023/3/24
# ************************************

from detectors.LibScan.libscan import LibScan