# -*- coding: utf-8 -*-
# ************************************
# @Author           : Bolin Zhou
# @File             : base.py
# @Create           : 2023/3/24
# @LastModified     : 2023/3/24
# ************************************

from abc import abstractmethod
import time

class Detector:
    
    def __init__(self):
        self.recoder = {
            # pairs of app & lib
            'TP': [],   # 检测正确
            'FP': [],   # 误报
            'FN': [],   # 漏报
        }
        self.total = 0
        self.query_time = []
        
    def measure_time(func):
        def wrapper(self, *args, **kwargs):
            start_time = time.time()
            result = func(self, *args, **kwargs)
            end_time = time.time()
            self.query_time.append(end_time - start_time)
            return result
        return wrapper
    
    def avg_query_time(self):
        return sum(self.query_time) / len(self.query_time)
    
    @abstractmethod
    def query(self, sample_paths, score=False):
        """
        Args:
            sample_paths (list[str]): the path of samples to be detected.

        Returns:
            list[float]: score or label
        """
        pass

    def Precision(self):
        return self.recoder['TP']/(self.recoder['TP']+self.recoder['FP'])
    
    def Recall(self):
        return self.recoder['TP']/(self.recoder['TP']+self.recoder['FN'])

    def F1(self):
        return 2*self.Precision()*self.Recall()/(self.Precision()+self.Recall())
    
    def FPR(self):
        return self.recoder['FP']/(self.recoder['FP']+self.recoder['TP'])
    
    def FNR(self):
        return self.recoder['FN']/(self.recoder['FN']+self.recoder['TP'])