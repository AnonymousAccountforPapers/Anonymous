import os, sys
import json
import random
import numpy as np
import tqdm
import shutil
import networkx as nx
from heterogeneous_graph.build_graph.create_graph import Edge_Type, Node_Type, Node, HeterogeneousGraph
from heterogeneous_graph.actions import generate_name_without_underline, generate_name
from modifier.modifier import Modifier
from collections import defaultdict
from cdlib.algorithms import walktrap

class Firefly:
    def __init__(self, 
                xid, 
                solution_length,
                Gstate: HeterogeneousGraph, 
                detector, 
                attacker, 
                APK_path, 
                TPL_path, 
                original_score,
                dataset, 
                blacklist, 
                greylist, 
                implemented_itfc, 
                ActionSeqSavePath_forAPK, 
                hyperparams, 
                with_score=False):
        super().__init__()
        self.x = []
        self.xid = xid
        self.solution_length = solution_length
        self.Gstate = Gstate
        self.detector = detector
        self.attacker = attacker
        self.APK_path = APK_path
        self.TPL = TPL_path.split("/")[-1]
        self.TPL_path = TPL_path
        self.original_score = original_score
        self.dataset = dataset
        
        self.blacklist = blacklist
        self.greylist = greylist
        self.implemented_itfc = implemented_itfc
        
        self.ActionSeqSavePath_forAPK = ActionSeqSavePath_forAPK
        self.hyperparams = hyperparams
        self.with_score = with_score
        
        self.action_type = ["add", "merge"]
        self.action_gran = [
            Node_Type.PACKAGE,
            Node_Type.CLASS,
            Node_Type.METHOD,
            Node_Type.FIELD,
            Node_Type.PARAMETER
        ]
        self.primitive_type = ["int", "char", "boolean", "byte", "long", "short", "float", "double"]
        self.ActSeq = ""
        self.prob_threshold = 0.35
        
        self.recover()
        
    def checkpoint(self):
        self.chkp_graph = self.Gstate
        self.chkp_blacklist = self.blacklist
        self.chkp_greylist = self.greylist
        
    def load_checkpoint(self):
        self.Gstate = self.chkp_graph.make_copy()
        self.blacklist = self.chkp_blacklist.copy()
        self.greylist = self.chkp_greylist.copy()
        
    def recover(self):
        
        self.success = False
        self.result = 1.0
        self.I = None
        self.Beta = None
        self.effective_operations = []
        
        self.ToPS = Modifier(self.detector, self.attacker, self.APK_path, self.TPL_path, self.dataset, self.xid, self.with_score)
        
        self.ActionSeqSavePath_forAPKwithFFid = os.path.join(self.ActionSeqSavePath_forAPK, "ff"+str(self.xid), "withscore" if self.with_score else "withoutscore")
        if os.path.isdir(self.ActionSeqSavePath_forAPKwithFFid):
            shutil.rmtree(self.ActionSeqSavePath_forAPKwithFFid)
        os.makedirs(self.ActionSeqSavePath_forAPKwithFFid)
        
        self.merge_processed_classes = defaultdict(set)
        self.ActSeq = ""
        
    # @timeout_decorator.timeout(30)
    def get_node_entropy(self, hetG: HeterogeneousGraph, node):
        if hetG.get_node_type(node) != Node_Type.CLASS:
            raise Exception("Invalid node type.")
        
        param_type = defaultdict(int)
        ret_type = defaultdict(int)
        fld_type = defaultdict(int)
        ivk_type = defaultdict(int)
        ref_type = defaultdict(int)

        for edge in hetG.get_all_edge_for_node(node):
            src = edge[0]
            tgt = edge[1]
            if hetG.get_edge_type((edge[0], edge[1])) == Edge_Type.CLASS_CONTAIN:
                if hetG.get_node_type(tgt) == Node_Type.METHOD:
                    params = hetG.get_ordered_method_parameters(tgt)
                    for p in params:
                        param_type[p.data['type']] += 1
                    
                    ret_type[tgt.data['mtd_ret']] += 1
                    
                    for direction in [True, False]:
                        for callee in hetG.get_specific_type_neighbors(tgt, Edge_Type.METHOD_INVOKE, Node_Type.METHOD, dest=direction):
                            callee_cls = hetG.get_specific_type_neighbor(callee, Edge_Type.CLASS_CONTAIN, Node_Type.CLASS, dest=True)
                            cls_name = hetG.get_class_full_name(callee_cls)
                            ivk_type[cls_name] += 1

                elif hetG.get_node_type(tgt) == Node_Type.FIELD:
                    fld_type[tgt.data['fld_type']] += 1

                    for refer in hetG.get_specific_type_neighbors(tgt, Edge_Type.FIELD_REFERENCE, Node_Type.METHOD, dest=True):
                        refer_cls = hetG.get_specific_type_neighbor(refer, Edge_Type.CLASS_CONTAIN, Node_Type.CLASS, dest=True)
                        cls_name = hetG.get_class_full_name(refer_cls)
                        ref_type[cls_name] += 1

        def calculate_entropy(type_dict):
            total = sum(type_dict.values())
            if total == 0:
                return 0
            entropy = -sum((count / total) * np.log(count / total) for count in type_dict.values())
            if len(type_dict) > 1:
                entropy /= np.log(len(type_dict))
            return entropy

        H_mtd_param = calculate_entropy(param_type)
        H_mtd_ret = calculate_entropy(ret_type)
        H_fld = calculate_entropy(fld_type)
        H_ivk = calculate_entropy(ivk_type)
        H_ref = calculate_entropy(ref_type)

        result = (H_mtd_param + H_mtd_ret + H_fld + H_ivk + H_ref) / 5
        return result
        
    def get_entropy(self):
        self.nodes_entropy = {}
        for node in self.Gstate.get_all_specific_nodes(Node_Type.CLASS):
            etp = self.get_node_entropy(self.Gstate, node)
            self.nodes_entropy[node] = etp
            
    def get_field_type_count(self, clz):
        type2count = defaultdict(int)
        for fld in self.Gstate.get_specific_type_neighbor(clz, Edge_Type.CLASS_CONTAIN, Node_Type.FIELD):
            type2count[fld.data['fld_type'].strip("[]")] += 1
        return type2count
            
    def get_method_type_count(self, clz):
        type2count = defaultdict(int)
        for mtd in self.Gstate.get_specific_type_neighbor(clz, Edge_Type.CLASS_CONTAIN, Node_Type.METHOD):
            type2count[mtd.data['mtd_ret'].strip("[]")] += 1
            for p in self.Gstate.get_ordered_method_parameters(mtd):
                type2count[p.data['type']] += 1
        return type2count
            

    def get_add_src(self, granularity):
        node_to_add = None
        if granularity == Node_Type.PACKAGE:
            pkg_name = generate_name_without_underline("package")
            node_to_add = self.Gstate._add_package(pkg_name)
            
        elif granularity == Node_Type.CLASS:
            cls_name = generate_name("class")
            cls_access_flag = "public"
            node_to_add = self.Gstate._add_class(cls_name, cls_access_flag, superclass="java.lang.Object")
            
            
        elif granularity == Node_Type.METHOD:
            mtd_name = generate_name("method")
            
            node_mapping = {node: idx for idx, node in enumerate(self.Gstate.G.nodes)}
            G_mapped = nx.relabel_nodes(self.Gstate.G, node_mapping)

            communities = walktrap(G_mapped)

            inverse_mapping = {v: k for k, v in node_mapping.items()}
            clusters = [[inverse_mapping[idx] for idx in community] for community in communities.communities]
            
            cluster_num = len(clusters)
            param_num = random.randint(0, cluster_num)
            params = []
            for cluster_ids in clusters:
                _clz = []
                for node_tmp in cluster_ids:
                    if self.Gstate.G.nodes[node_tmp]['type'] == Node_Type.CLASS:
                        _clz.append(node_tmp)
                if len(_clz):
                    chooz = random.choice(_clz)
                    params.append(self.Gstate.get_class_full_name(chooz))
                if len(params) >= param_num:
                    break
            
            return_type = self.Gstate.get_class_full_name(random.choice(self.Gstate.get_all_specific_nodes(Node_Type.CLASS)))
            
            node_to_add = self.Gstate._add_method(mtd_name, params, return_type, random.choice(["public", "private", "protected"]))
            
        elif granularity == Node_Type.FIELD:
            fld_name = generate_name("fld")
            fld_type = self.Gstate.get_class_full_name(random.choice(self.Gstate.get_all_specific_nodes(Node_Type.CLASS)))
            node_to_add = self.Gstate._add_field(fld_name, fld_type, random.choice(["public", "private", "protected"]), None)
            
        elif granularity == Node_Type.PARAMETER:
            param_type = self.Gstate.get_class_full_name(random.choice(self.Gstate.get_all_specific_nodes(Node_Type.CLASS)))
            node_to_add = self.Gstate._add_parameter(param_type)
            
        return node_to_add

    def get_merge_target(self, src_node, wlist):
        self.get_entropy()
        
        node_mapping = {node: idx for idx, node in enumerate(self.Gstate.G.nodes)}
        G_mapped = nx.relabel_nodes(self.Gstate.G, node_mapping)

        communities = walktrap(G_mapped)

        inverse_mapping = {v: k for k, v in node_mapping.items()}
        clusters = [[inverse_mapping[idx] for idx in community] for community in communities.communities]
        cluster_num = len(clusters)
        
        node_cluster_id = None
        for i, cluster_ids in enumerate(clusters):
            if src_node in cluster_ids:
                node_cluster_id = i
        
        assert node_cluster_id is not None
            
        if cluster_num > 1:
            for i, cluster_ids in enumerate(clusters):
                if i != node_cluster_id:
                    for tgt_node in cluster_ids:
                        if tgt_node in wlist and self.Gstate.get_node_type(tgt_node) == self.Gstate.get_node_type(src_node):
                            return tgt_node
            for tgt_node in clusters[node_cluster_id]:
                if tgt_node in wlist and self.Gstate.get_node_type(tgt_node) == self.Gstate.get_node_type(src_node) and tgt_node != src_node:
                    return tgt_node
        else:
            for tgt_node in clusters[0]:
                if tgt_node in wlist and self.Gstate.get_node_type(tgt_node) == self.Gstate.get_node_type(src_node):
                    return tgt_node
        
        return None
        
    def compatible(self, clz1, clz2):
        supclz1, supclz2 = self.Gstate.get_superclass(clz1), self.Gstate.get_superclass(clz2)
        if isinstance(supclz1, Node):
            supclz1 = self.Gstate.get_class_full_name(supclz1)
        if isinstance(supclz2, Node):
            supclz2 = self.Gstate.get_class_full_name(supclz2)
        if supclz2 != supclz1 and supclz2 != "java.lang.Object" and supclz1 != "java.lang.Object":
            return False
        return True
        
    def generate_operation_one_step(self, action=None, granularity=None):        
        self.PROB = random.random()
        action = random.choice(self.action_type) if action is None else action
        granularity = random.choice(self.action_gran) if granularity is None else granularity
        
        if action == 'merge':
            if self.PROB > self.prob_threshold:
                self.get_entropy()
                if granularity != Node_Type.PACKAGE:
                    blist_nodes, glist_node = set(self.blacklist[granularity]), set(self.greylist[granularity])
                    availble_nodes = set(self.Gstate.get_all_specific_nodes(granularity))-blist_nodes-glist_node-{self.Gstate.defaultPackage}
                    merge_target_availble_nodes = set(self.Gstate.get_all_specific_nodes(granularity))-blist_nodes-{self.Gstate.defaultPackage}
                    
                    tobe_merged_node = None
                    merged_target = None
                    
                    sorted_classes = sorted(self.nodes_entropy.items(), key=lambda x: x[1], reverse=False)
                    for i, (n, e) in enumerate(sorted_classes):
                        if granularity == Node_Type.CLASS:
                            if n in availble_nodes:
                                tobe_merged_node = n
                                break
                                
                        elif granularity == Node_Type.METHOD:
                            for mtd in self.Gstate.get_specific_type_neighbors(n, Edge_Type.CLASS_CONTAIN, Node_Type.METHOD):
                                if mtd in availble_nodes:
                                    tobe_merged_node = mtd
                                    break
                            if tobe_merged_node is not None:
                                break
                            
                        elif granularity == Node_Type.FIELD:
                            for fld in self.Gstate.get_specific_type_neighbors(n, Edge_Type.CLASS_CONTAIN, Node_Type.FIELD):
                                if fld in availble_nodes:
                                    tobe_merged_node = fld
                                    break
                            if tobe_merged_node is not None:
                                break
                            
                        elif granularity == Node_Type.PARAMETER:
                            for mtd in self.Gstate.get_specific_type_neighbors(n, Edge_Type.CLASS_CONTAIN, Node_Type.METHOD):
                                params = self.Gstate.get_ordered_method_parameters(mtd)
                                if len(params) < 2:
                                    continue
                                for param in params:
                                    if param in availble_nodes and tobe_merged_node is None and param != merged_target:
                                        tobe_merged_node = param
                                        continue
                                    if param in merge_target_availble_nodes and merged_target is None and param != tobe_merged_node:
                                        merged_target = param
                                        continue
                                
                                if tobe_merged_node is not None and merged_target is not None:
                                    break
                            if tobe_merged_node is not None and merged_target is not None:
                                break
                    
                    if merged_target is None:
                        for i, (n, e) in enumerate(sorted_classes):
                            if granularity == Node_Type.CLASS:
                                if n in merge_target_availble_nodes and tobe_merged_node != n and \
                                    self.compatible(tobe_merged_node, n):
                                    merged_target = n
                                    break
                                    
                            elif granularity == Node_Type.METHOD:
                                for mtd in self.Gstate.get_specific_type_neighbors(n, Edge_Type.CLASS_CONTAIN, Node_Type.METHOD):
                                    if mtd in merge_target_availble_nodes and tobe_merged_node != mtd:
                                        merged_target = mtd
                                        break
                                if merged_target is not None:
                                    break
                                
                            elif granularity == Node_Type.FIELD:
                                for fld in self.Gstate.get_specific_type_neighbors(n, Edge_Type.CLASS_CONTAIN, Node_Type.FIELD):
                                    if fld in merge_target_availble_nodes and tobe_merged_node != fld:
                                        merged_target = fld
                                        break
                                if merged_target is not None:
                                    break
                    
                else:
                    packages_entropy_map = {}
                    for pkg in self.Gstate.get_all_specific_nodes(Node_Type.PACKAGE):
                        if pkg == self.Gstate.defaultPackage:
                            continue
                        packages_entropy_map[pkg] = sum([self.nodes_entropy[c] for c in self.Gstate.get_specific_type_neighbors(pkg, Edge_Type.PACKAGE_CONTAIN, Node_Type.CLASS)])
                    
                    sorted_pkgs = sorted(packages_entropy_map.items(), key=lambda x: x[1])
                    tobe_merged_node = sorted_pkgs[0][0]
                    merged_target = sorted_pkgs[1][0]
                    
            else:
                if granularity != Node_Type.PARAMETER:
                    blist_nodes, glist_node = set(self.blacklist[granularity]), set(self.greylist[granularity])

                    availble_nodes = set(self.Gstate.get_all_specific_nodes(granularity))-blist_nodes-glist_node-{self.Gstate.defaultPackage}
                    tobe_merged_node = random.choice(list(availble_nodes))
                    
                    itfc_nodes = self.Gstate.get_specific_type_neighbors(tobe_merged_node, Edge_Type.IMPLEMENT, Node_Type.INTERFACE)
                    for itfc in itfc_nodes:
                        blist_nodes |= self.implemented_itfc[itfc]
                    
                    merge_target_availble_nodes = set(self.Gstate.get_all_specific_nodes(granularity))-blist_nodes-{self.Gstate.defaultPackage}
                    addition_blist = set()
                    if granularity == Node_Type.CLASS:
                        for clz in merge_target_availble_nodes:
                            if not self.compatible(tobe_merged_node, clz):
                                addition_blist.add(clz)
                        merge_target_availble_nodes -= addition_blist
                    merged_target = self.get_merge_target(tobe_merged_node, merge_target_availble_nodes)
                else:
                    availble_nodes = []
                    for node in self.Gstate.get_all_specific_nodes(Node_Type.METHOD):
                        if not node.data['in_interface'] and node not in self.blacklist[Node_Type.METHOD]:
                            availble_nodes += self.Gstate.get_specific_type_neighbors(node, Edge_Type.PARAMETER, Node_Type.PARAMETER)
                                
                    while len(availble_nodes):
                        tobe_merged_node = random.choice(list(availble_nodes))
                        params = self.Gstate.get_ordered_method_parameters(self.Gstate.get_specific_type_neighbor(tobe_merged_node, Edge_Type.PARAMETER, Node_Type.METHOD, dest=True))
                        param_num = len(params)
                        if param_num >= 2:
                            merged_target = random.choice(list(set(params) - {tobe_merged_node}))
                            break
                        else: 
                            availble_nodes.remove(tobe_merged_node)
            return ('merge', tobe_merged_node, merged_target)
        else:
            if self.PROB < self.prob_threshold:
                added_target = None
                self.get_entropy()
                if granularity != Node_Type.PACKAGE and granularity != Node_Type.CLASS:
                    sorted_classes = sorted(self.nodes_entropy.items(), key=lambda x: x[1], reverse=False)
                    for _, (n, _) in enumerate(sorted_classes):                                
                        if granularity == Node_Type.METHOD or granularity == Node_Type.FIELD:
                            if n in self.blacklist[Node_Type.CLASS]:
                                added_target = n
                                break
                            
                        elif granularity == Node_Type.PARAMETER:
                            for mtd in self.Gstate.get_specific_type_neighbors(n, Edge_Type.CLASS_CONTAIN, Node_Type.METHOD):
                                if mtd not in self.blacklist[Node_Type.METHOD]:
                                    added_target = mtd
                                    break
                            if added_target is not None:
                                break
                else:
                    packages_entropy_map = {}
                    for pkg in self.Gstate.get_all_specific_nodes(Node_Type.PACKAGE):
                        packages_entropy_map[pkg] = sum([self.nodes_entropy[c] for c in self.Gstate.get_specific_type_neighbors(pkg, Edge_Type.PACKAGE_CONTAIN, Node_Type.CLASS)])
                    
                    sorted_pkgs = sorted(packages_entropy_map.items(), key=lambda x: x[1])
                    for pkg, e in sorted_pkgs:
                        if pkg not in self.blacklist[Node_Type.PACKAGE]|{self.Gstate.defaultPackage}:
                            added_target = pkg
                            break
                
            else:
                added_target = None
                if granularity == Node_Type.PACKAGE or granularity == Node_Type.CLASS:
                    added_target = random.choice(list(set(self.Gstate.get_all_specific_nodes(Node_Type.PACKAGE))-set(self.blacklist[Node_Type.PACKAGE])|{self.Gstate.defaultPackage}))
                elif granularity == Node_Type.METHOD or granularity == Node_Type.FIELD:
                    added_target = random.choice(list(set(self.Gstate.get_all_specific_nodes(Node_Type.CLASS))-set(self.blacklist[Node_Type.CLASS])))
                elif granularity == Node_Type.PARAMETER:
                    max_param = 255
                    add_blist = set()
                    tmp = set(self.Gstate.get_all_specific_nodes(Node_Type.METHOD))-set(self.blacklist[Node_Type.METHOD])
                    for mtd in tmp:
                        if len(self.Gstate.get_specific_type_neighbors(mtd, Edge_Type.PARAMETER, Node_Type.PARAMETER)) >= max_param:
                            add_blist.add(mtd)
                    tmp -= add_blist
                    added_target = random.choice(list(tmp))
                
            tobe_added_node = self.get_add_src(granularity)
            if self.Gstate.get_node_type(tobe_added_node) != Node_Type.PARAMETER:
                self.greylist[self.Gstate.get_node_type(tobe_added_node)].add(tobe_added_node)
            return ('add', tobe_added_node, added_target)
    
    def execute_operation(self, operation):
        op_type, node1, node2 = operation
        if node1 is None or node2 is None:
            return False

        local_ActSeq = ""
        result = False
        if op_type == 'add':
            gran = self.Gstate.get_node_type(node1)
            if gran == Node_Type.PACKAGE:
                assert self.Gstate.get_node_type(node2) == Node_Type.PACKAGE
                local_ActSeq += "00:\n"
                assert node1.data['pkg_name'] is not None
                if self.Gstate.get_SootDescriptor(node2) is None:
                    local_ActSeq += "{"+node1.data['pkg_name']+"}, {"+" }\n"
                else:
                    local_ActSeq += "{"+node1.data['pkg_name']+"}, {"+self.Gstate.get_SootDescriptor(node2)+"}\n"
            elif gran == Node_Type.CLASS:
                assert self.Gstate.get_node_type(node2) == Node_Type.PACKAGE
                local_ActSeq += "01:\n"
                if node2.data['pkg_name'] is None:
                    cls_signature = node1.data['cls_name']
                else:
                    cls_signature = node2.data['pkg_name']+"."+node1.data['cls_name']
                local_ActSeq += "{"+cls_signature+"}, {"+node1.data['cls_access_flag']+"}\n"
            elif gran == Node_Type.METHOD:
                assert self.Gstate.get_node_type(node2) == Node_Type.CLASS
                local_ActSeq += "02:\n"
                local_ActSeq += "{"+self.Gstate.get_SootDescriptor(node2)+": "+self.Gstate.get_method_SootSubSig(node1)+"}, {"+node1.data['mtd_access_flag']+"}"
            elif gran == Node_Type.FIELD:
                assert self.Gstate.get_node_type(node2) == Node_Type.CLASS
                local_ActSeq += "03:\n"
                local_ActSeq += "{"+self.Gstate.get_SootDescriptor(node2)+": "+node1.data['fld_type']+" "+node1.data['fld_name']+"}, {"+node1.data['fld_access_flag']+"}\n"
            elif gran == Node_Type.PARAMETER:
                assert self.Gstate.get_node_type(node2) == Node_Type.METHOD
                local_ActSeq += "04:\n"
                local_ActSeq += "{"+self.Gstate.get_SootDescriptor(node2)+"}, {"+node1.data['type']+"}\n"
                
            result = self.Gstate.add_node(gran, node1, node2)
            if result and gran == Node_Type.METHOD:
                local_ActSeq += ", {"+self.Gstate.get_SootDescriptor(result)+"}\n"
                
        elif op_type == 'merge':
            gran = self.Gstate.get_node_type(node1)
            if gran == Node_Type.PACKAGE:
                assert self.Gstate.get_node_type(node2) == Node_Type.PACKAGE
                local_ActSeq += "10:\n"
                local_ActSeq += "{"+self.Gstate.get_SootDescriptor(node1)+"}, {"+self.Gstate.get_SootDescriptor(node2)+"}\n"
            elif gran == Node_Type.CLASS:
                assert self.Gstate.get_node_type(node2) == Node_Type.CLASS
                local_ActSeq += "11:\n"
                local_ActSeq += "{"+self.Gstate.get_SootDescriptor(node1)+ "}, {"+self.Gstate.get_SootDescriptor(node2)+"}\n"
            elif gran == Node_Type.METHOD:
                assert self.Gstate.get_node_type(node2) == Node_Type.METHOD
                local_ActSeq += "12:\n"
                local_ActSeq += "{"+self.Gstate.get_SootDescriptor(node1)+"}, {"+self.Gstate.get_SootDescriptor(node2)+"}"
            elif gran == Node_Type.FIELD:
                assert self.Gstate.get_node_type(node2) == Node_Type.FIELD
                local_ActSeq += "13:\n"
                local_ActSeq += "{"+self.Gstate.get_SootDescriptor(node1)+"}, {"+self.Gstate.get_SootDescriptor(node2)+"}"
            elif gran == Node_Type.PARAMETER:
                assert self.Gstate.get_node_type(node2) == Node_Type.PARAMETER
                local_ActSeq += "14:\n"
                mtd = self.Gstate.get_specific_type_neighbor(node1, Edge_Type.PARAMETER, Node_Type.METHOD, dest=True)
                local_ActSeq += "{"+self.Gstate.get_SootDescriptor(mtd)+"}, {"+str(node1.data['position'])+"}, {"+str(node2.data['position'])+"}"
            
            result, tobeblist = self.Gstate.merge_nodes(gran, node1, node2)
            if result:
                if gran == Node_Type.METHOD:
                    if result != True:
                        local_ActSeq += ", {"+result+"}\n"
                    else:
                        local_ActSeq += ", {"+"None"+"}\n"
                if gran == Node_Type.FIELD or gran == Node_Type.PARAMETER:
                    local_ActSeq += ", {"+result+"}\n"
                if len(tobeblist):
                    for node in tobeblist:
                        self.blacklist[self.Gstate.get_node_type(node)].add(node)
                    
        if local_ActSeq[-1] == '{':
            raise Exception(f"{local_ActSeq}")
        self.ActSeq += local_ActSeq
        return True
        
    def get_light_intensity(self):
        self.recover()
        self.ActSeq = ""
        self.step = 0
        for i in tqdm.tqdm(range(self.solution_length)):
            if len(self.x) < self.solution_length:
                operation = self.generate_operation_one_step()
            else:
                action, gran = self.x[i]//5, self.action_gran[self.x[i]%5]
                operation = self.generate_operation_one_step(action, gran)
            result = self.execute_operation(operation)
            self.x.append(operation)
            self.step += 1
            
        suffix = len(os.listdir(self.ActionSeqSavePath_forAPKwithFFid))
        f_ActSeq = open(os.path.join(self.ActionSeqSavePath_forAPKwithFFid, f"{self.TPL.strip('.dex')}_{suffix}.act"), "w")
        f_ActSeq.write(self.ActSeq)
        f_ActSeq.close()
        self.result = self.ToPS(f_ActSeq.name)
        if self.with_score:
            self.I = 1-self.result
        else:
            self.get_entropy()
            self.I = sum(self.nodes_entropy.values())/len(self.nodes_entropy.values())
        return self.I
    
    def get_attractiveness(self, anothers):
        self.Beta = []
        for firefly in anothers:
            if firefly == self:
                r = np.linalg.norm(np.array(self.x) - np.array(firefly.x))
                self.Beta.append(self.hyperparams['beta0']/np.exp(self.hyperparams['gamma']*(r**2)))
            else:
                self.Beta.append(self.hyperparams['beta0'])
            
    def moveTowards(self, taget):
        tmp = np.round(np.array(self.x) + self.Beta[self.xid]*(np.array(taget.x) - np.array(self.x)) + self.hyperparams['alpha']*np.random.uniform(0, 9.5, len(self.x)))
        self.x = []
        for item in tmp:
            if item < 0:
                self.x.append(0)
            elif item > 9:
                self.x.append(9)
            else:
                self.x.append(int(item))