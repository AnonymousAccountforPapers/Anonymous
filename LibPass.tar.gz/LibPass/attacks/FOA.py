from collections import defaultdict
import os, sys
import time
from heterogeneous_graph.build_graph.create_graph import Edge_Type, Node_Type, Node
from heterogeneous_graph.decoupler import Decoupler
from datetime import datetime
from modifier.modifier import Modifier
from attacks.firefly import Firefly


class Attack():
    def __init__(self, max_step=30, dataset=1, detector="libscan", use_score=False) -> None:
        self.attacker = "LibPass"
        self.max_step = max_step
        self.use_score = use_score
        
        self.dataset = dataset
        self.detector = detector

        self.action_type = ["add", "merge"]
        self.action_gran = ["package", "class", "method", "field", "parameter"]
 
        self.primitive_type = ["int", "char", "boolean", "byte", "long", "short", "float", "double"]
        
        self.colors = {'package': 'blue', 'class': 'green', 'method': 'red', 'field': 'yellow'}
        
        self.datetime = datetime.now().strftime("%Y-%m-%d_%H:%M")
        
        self.apk_folder = os.path.join(os.getcwd(), f"samples/D{dataset}/apps/")
        self.lib_dex_folder = os.path.join(os.getcwd(), f"samples/D{dataset}/libs_dex/")
        self.action_seq_save = os.path.join(os.getcwd(), f"modifier/ApkMod/TmpDir/mod_seq/{self.detector}/D{dataset}/{self.attacker}/")
        if not os.path.exists(self.action_seq_save):
            os.makedirs(self.action_seq_save)
        self.ToPS = None
        
        self.decouple_time_consume = []
        self.effective_operations = []
        self.curt_perturb = None
        
    def backup(self):
        self.modifier.checkpoint()
        
    def rollback(self):
        self.modifier.recover()
    
    def reset(self, TPL, APK):
        self.TPL = TPL
        self.APK = APK
        if (not os.path.exists(os.path.join(self.lib_dex_folder, TPL))) or (not os.path.exists(os.path.join(self.apk_folder, APK))):
            print("Error: Can't find the TPL or APK!")
            return False
        self.ActionSeqSavePath_forAPK = os.path.join(self.action_seq_save, f"{self.APK}-{self.TPL}/{self.datetime}/")
        if not os.path.isdir(self.ActionSeqSavePath_forAPK):
            os.makedirs(self.ActionSeqSavePath_forAPK)
        
        return self.recover()
    
        
    def FFA(self):
        cls_num = len(self.curt_graph.get_all_specific_nodes(Node_Type.CLASS))
        if cls_num <= 500:
            firefly_num = 8
        elif cls_num <= 1000:
            firefly_num = 16
        else:
            firefly_num = 32
            
        solution_length = 20
        fireflies = []
        for i in range(firefly_num):
            ff = Firefly(
                xid=i,
                solution_length=solution_length,
                Gstate=self.curt_graph, 
                detector=self.detector, 
                attacker=self.attacker, 
                APK_path=os.path.join(self.apk_folder, self.APK), 
                TPL_path=os.path.join(self.lib_dex_folder, self.TPL), 
                original_score=self.result,
                dataset=self.dataset, 
                blacklist=self.blacklist, 
                greylist=self.greylist, 
                implemented_itfc=self.implemented_itfc,
                ActionSeqSavePath_forAPK=self.ActionSeqSavePath_forAPK, 
                hyperparams={
                    "beta0": 1,
                    "gamma": 0.3,
                    "alpha": 0.2
                },
                with_score=self.use_score
            )
            fireflies.append(ff)
        
        for ff in fireflies:
            ff.get_light_intensity()
            if ff.result == 0:
                self.effective_operations = ff.effective_operations
                self.modify_time = ff.ToPS.avg_query_time()
                self.query_time = ff.ToPS.D.avg_query_time()
                self.operations = ff.x
                return True, ff.step
            ff.get_attractiveness(fireflies)

        iters = 0
        label = self.result
        label_next = label
        while iters < self.max_step and label_next != 0:
            iters += 1
            
            for i in range(firefly_num):
                for j in range(firefly_num):
                    if i == j:
                        continue
                    if fireflies[i].I <= fireflies[j].I:
                        fireflies[i].moveTowards(fireflies[j])
                        fireflies[i].get_light_intensity()
                        fireflies[i].get_attractiveness(fireflies)
                        
            if self.use_score:
                min_score = max([fireflies[i].result for i in range(firefly_num)])
                best_id = [fireflies[i].result for i in range(firefly_num)].index(min_score)
            else:
                max_I = max([fireflies[i].I for i in range(firefly_num)])
                best_id = [fireflies[i].I for i in range(firefly_num)].index(max_I)
                
            curt_best = fireflies[best_id]
            label_next = curt_best.result
            
        self.effective_operations = curt_best.effective_operations
        self.modify_time = curt_best.ToPS.avg_query_time()
        self.query_time = curt_best.ToPS.D.avg_query_time()
        self.operations = curt_best.x
        return label_next == 0, iters
        
                
    def __call__(self):
        return self.FFA()


    def recover(self):
        self.orig_size = os.path.getsize(os.path.join(self.apk_folder, self.APK))
        start_time = time.time()
        self.decoupler = Decoupler(os.path.join(self.lib_dex_folder, self.TPL), 
                                   os.path.join(self.apk_folder, self.APK),
                                   custom_decouple=False,
                                   dataset=self.dataset)
        self.orig_graph = self.decoupler()
        self.curt_graph = self.decoupler.tgtgraph
        self.decouple_time_consume.append(time.time() - start_time)
        
        self.ToPS = Modifier(self.detector, self.attacker, os.path.join(self.apk_folder, self.APK), os.path.join(self.lib_dex_folder, self.TPL), self.dataset, fid="-1")
        self.result = self.ToPS.query(self.ToPS.tmp_apk_path, self.ToPS.tmp_lib_path)
        
        if self.result is None:
            print("Detection result is None")
            return False
        if self.result == 0:
            print("TPL Detection Failed.")
            return False

        print(f"[+] Original Result: {self.result}")
        self.new_packages = list()
        self.new_classes = list()
        self.new_interfaces = list()
        self.new_fields = list()
        self.new_methods = list()
        
        if len(self.curt_graph.get_all_specific_nodes(Node_Type.CLASS)) == 0:
            print("No class modifiable!")
            return False
        
        self.blacklist = defaultdict(set)
        self.greylist = defaultdict(set)
        self.build_constraints()
        if len(self.blacklist['package']) == len(self.curt_graph.get_all_specific_nodes(Node_Type.PACKAGE)) or \
            len(self.blacklist['class']) == len(self.curt_graph.get_all_specific_nodes(Node_Type.CLASS)) or \
            len(self.blacklist['method']) == len(self.curt_graph.get_all_specific_nodes(Node_Type.METHOD)):
            return False
        
        
        self.node_IS = defaultdict(float)
        for n in self.curt_graph.G.nodes:
            self.node_IS[n] = 1.0
            
        self.idx = len(os.listdir(self.ActionSeqSavePath_forAPK))
        self.ActionSeqSavePath_forAPKwithRandom = os.path.join(self.ActionSeqSavePath_forAPK, str(self.idx))
        if not os.path.isdir(self.ActionSeqSavePath_forAPKwithRandom):
            os.makedirs(self.ActionSeqSavePath_forAPKwithRandom)
        
        return True
    
    def build_constraints(self):
        self.implemented_itfc = defaultdict(set)
        
        for cls in self.curt_graph.get_all_specific_nodes(Node_Type.CLASS):
            if "abstract" in self.curt_graph.get_access_flag(cls) or cls.data["cls_name"].startswith("R$"):
                self.blacklist[Node_Type.CLASS].add(cls)
            
            for itfc in self.curt_graph.get_specific_type_neighbors(cls, Edge_Type.IMPLEMENT, Node_Type.INTERFACE):
                self.implemented_itfc[itfc].add(cls)
                
        for mtd in self.curt_graph.get_all_specific_nodes(Node_Type.METHOD):
            if "abstract" in self.curt_graph.get_access_flag(mtd):
                self.blacklist[Node_Type.METHOD].add(mtd)
                
            if mtd.data["in_interface"] or mtd.data["mtd_name"] == "<init>" or mtd.data["mtd_name"] == "<clinit>":
                self.blacklist[Node_Type.METHOD].add(mtd)
                
                
            if mtd.data["mtd_name"].startswith("bridge") or mtd.data["mtd_name"].startswith("synthetic"):
                self.blacklist[Node_Type.METHOD].add(mtd)
            
        for fld in self.curt_graph.get_all_specific_nodes(Node_Type.FIELD):
            if fld.data["in_interface"]:
                self.blacklist[Node_Type.FIELD].add(fld)
                
        interface_mtd = defaultdict(set)
        for itfc in self.curt_graph.get_all_specific_nodes(Node_Type.INTERFACE):
            for mtd in self.curt_graph.get_specific_type_neighbors(itfc, Edge_Type.INTERFACE_CONTAIN, Node_Type.METHOD):
                if mtd.data["in_interface"]:
                    interface_mtd[itfc].add(self.curt_graph.get_method_SootSubSig(mtd))
        for claz in self.curt_graph.get_all_specific_nodes(Node_Type.CLASS):
            for itfc in self.curt_graph.get_specific_type_neighbors(claz, Edge_Type.IMPLEMENT, Node_Type.INTERFACE):
                for mtd in self.curt_graph.get_specific_type_neighbors(claz, Edge_Type.CLASS_CONTAIN, Node_Type.METHOD):
                    if not mtd.data["in_interface"] and \
                        self.curt_graph.get_method_SootSubSig(mtd) in interface_mtd[itfc]:
                        self.blacklist[Node_Type.METHOD].add(mtd)
    
        self.curt_graph.post_process()
    