1. download android-platforms-master into `LibPass/modifier/ApkMod/android-platforms-master`
2. run `python LibPass.py --detector libscan --score --dataset 1`