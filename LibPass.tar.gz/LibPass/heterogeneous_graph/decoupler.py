import os
from typing import Any
import sys
import json
from typing import List
from androguard.core.analysis.analysis import Analysis, ExternalMethod
from androguard.core.bytecodes.dvm import ClassDefItem
from androguard.misc import AnalyzeAPK, AnalyzeDex
from heterogeneous_graph.build_graph.create_graph import Node_Type, Edge_Type, HeterogeneousGraph
from collections import defaultdict
import datetime
import numpy as np
from .utils import get_clazzitem

class Decoupler:
    def __init__(self, libfile=None, apkfile=None, verbose=False, custom_decouple=False, dataset=1, threshold=0.8, validation=False, gt=None) -> None:
        self.lib = libfile
        self.apk = apkfile
        if self.apk is not None:
            self.a, self.d, self.dx = AnalyzeAPK(self.apk)
        
        self.libgraph = HeterogeneousGraph()
        self.tgtgraph = HeterogeneousGraph()
        
        self.white_list = [
            "Ljava/lang/Object;",
        ]
        self.verbose = verbose
        
        self.packages = set()
        self.classes = set()
        self.interfaces = set()
        self.methods = set()
        self.methods_itfc = set()
        self.fields = set()
        self.fields_itfc = set()
        
        self.custom_decouple = custom_decouple
        self.dataset = dataset
        self.threshold = threshold
        self.validation = validation
        self.gt = gt
    
    def construct_graph(self, classes: List[ClassDefItem], dx: Analysis, G:HeterogeneousGraph):
        self.cls_desp_2_obj = {}
        self.itfc_desp_2_obj = {}
        self.mtd_desp_2_obj = {}
        self.fld_desp_2_obj = {}
        for i, clsitem in enumerate(classes):
            _pkg_name = '.'.join(self.get_descriptor2type(clsitem.get_name()).split('.')[:-1])
            if not (_pkg_obj := G.find_package(_pkg_name)):
                _pkg_obj = G._add_package(_pkg_name)
            self.packages.add(_pkg_name)
            
            if "interface" in clsitem.get_access_flags_string():
                _itfc_name = self.get_descriptor2type(clsitem.get_name()).split(".")[-1]
                _itfc_access_flag = clsitem.get_access_flags_string()
                _itfc_obj = G._add_interface(_itfc_name, _itfc_access_flag)
                self.interfaces.add(clsitem.get_name())
                self.itfc_desp_2_obj[clsitem.get_name()] = _itfc_obj
                
                G._add_in_package(_itfc_obj, _pkg_obj)
            else:
                _cls_name = self.get_descriptor2type(clsitem.get_name()).split(".")[-1]
                _cls_access_flag = clsitem.get_access_flags_string()
                _cls_obj = G._add_class(_cls_name, _cls_access_flag)
                self.classes.add(clsitem.get_name())
                self.cls_desp_2_obj[clsitem.get_name()] = _cls_obj
                
                G._add_in_package(_cls_obj, _pkg_obj)
        
        for i, clsitem in enumerate(classes):
            _pkg_name = '.'.join(self.get_descriptor2type(clsitem.get_name()).split('.')[:-1])
            
            if "interface" in clsitem.get_access_flags_string():
                _itfc_name = self.get_descriptor2type(clsitem.get_name()).split(".")[-1]
                itfc_vertex = G.find_interface(_itfc_name, _pkg_name)
                
                for mtd in clsitem.get_methods():
                    _mtd_name = mtd.get_name()
                    _mtd_descriptor = mtd.get_descriptor()
                    _mtd_access_flag = mtd.get_access_flags_string()
                    no_args = _mtd_descriptor.find("(") == _mtd_descriptor.find(")")-1
                    _mtd_arg_list = [self.get_descriptor2type(item) for item in _mtd_descriptor.split("(")[-1].split(")")[0].split(" ")] if not no_args else []
                    _mtd_ret = self.get_descriptor2type(_mtd_descriptor.split(')')[-1])
                                
                    _mtd_obj = G._add_method(_mtd_name, 
                                            _mtd_arg_list, 
                                            _mtd_ret,
                                            _mtd_access_flag,
                                            True)
                    
                    G._add_interface_with_method(itfc_vertex, _mtd_obj)
                    self.methods_itfc.add(" ".join([clsitem.get_name(), _mtd_name, _mtd_descriptor]))
                
                for fld in clsitem.get_fields():
                    fld_name = fld.get_name()
                    init_value = fld.get_init_value()
                    fld_type = self.get_descriptor2type(fld.get_descriptor())
                    fld_access_flag = fld.get_access_flags_string()
                    _fld_obj = G._add_field(fld_name, fld_type, fld_access_flag, init_value, True)
                    G._add_interface_with_field(itfc_vertex, _fld_obj)
                    self.fields_itfc.add(" ".join([clsitem.get_name(), fld_name, fld.get_descriptor()]))

            else:
                _cls_name = self.get_descriptor2type(clsitem.get_name()).split(".")[-1]
                cls_vertex = G.find_class(_cls_name, _pkg_name)
                
                for mtd in clsitem.get_methods():
                    _mtd_name = mtd.get_name()
                    _mtd_descriptor = mtd.get_descriptor()
                    _mtd_access_flag = mtd.get_access_flags_string()
                    no_args = _mtd_descriptor.find("(") == _mtd_descriptor.find(")")-1
                    _mtd_arg_list = [self.get_descriptor2type(item) for item in _mtd_descriptor.split("(")[-1].split(")")[0].split(" ")] if not no_args else []
                    _mtd_ret = self.get_descriptor2type(_mtd_descriptor.split(')')[-1])
                    _mtd_obj = G._add_method(_mtd_name, 
                                            _mtd_arg_list,
                                            _mtd_ret,
                                            _mtd_access_flag,
                                            False)
                    
                    G._add_class_with_method(cls_vertex, _mtd_obj)
                    self.methods.add(" ".join([clsitem.get_name(), _mtd_name, _mtd_descriptor]))
                    self.mtd_desp_2_obj[" ".join([clsitem.get_name(), _mtd_name, _mtd_descriptor])] = _mtd_obj
                    
                for fld in clsitem.get_fields():
                    fld_name = fld.get_name()
                    init_value = fld.get_init_value()
                    fld_type = self.get_descriptor2type(fld.get_descriptor())
                    fld_access_flag = fld.get_access_flags_string()
                    _fld_obj = G._add_field(fld_name, fld_type, fld_access_flag, init_value, False)
                    G._add_class_with_field(cls_vertex, _fld_obj)
                    self.fields.add(" ".join([clsitem.get_name(), fld_name, fld.get_descriptor()]))
                    self.fld_desp_2_obj[" ".join([clsitem.get_name(), fld_name, fld.get_descriptor()])] = _fld_obj
                    
        for clsitem in classes:
            _pkg_name = '.'.join(self.get_descriptor2type(clsitem.get_name()).split('.')[:-1])
            cls_name = self.get_descriptor2type(clsitem.get_name()).split('.')[-1]
            _cls_obj = G.find_class(cls_name, _pkg_name)
            if _cls_obj is None:
                continue
            
            for impl_itfc in clsitem.get_interfaces():
                _itfc_name = self.get_descriptor2type(impl_itfc)
                _itfc_package = '.'.join(_itfc_name.split(".")[:-1])
                _itfc_name = _itfc_name.split(".")[-1]
                _itfc_obj = G.find_interface(_itfc_name, _itfc_package)
                if _itfc_obj is not None:
                    G._add_class_implement_interface(_cls_obj, _itfc_obj)
                else:
                    continue

            super_class_name = clsitem.get_superclassname()
            super_class_name = self.get_descriptor2type(super_class_name)
            super_class_obj = G.find_class(super_class_name.split(".")[-1], ".".join(super_class_name.split(".")[:-1]))
            if super_class_obj is not None:
                G._add_class_inherit(_cls_obj, super_class_obj)
            else:
                _cls_obj.data["superclass"] = super_class_name
                continue
                
        inner_classes = {}
        for cls_name in self.classes:
            if "$" in cls_name:
                inner_classes[cls_name] = cls_name[:cls_name.rfind("$")]
        for innercls_name in inner_classes:
            dot_innercls_name = innercls_name.replace("/", ".")[1:-1]
            dot_outercls_name = inner_classes[innercls_name].replace("/", ".")[1:-1]
            inner_cls = G.find_class(dot_innercls_name.split(".")[-1], dot_innercls_name[:dot_innercls_name.rfind(".")])
            outer_cls = G.find_class(dot_outercls_name.split(".")[-1], dot_outercls_name[:dot_outercls_name.rfind(".")])
            if inner_cls and outer_cls:
                if outer_cls != inner_cls:
                    G._add_inner_class(outer_cls, inner_cls)
        
        fcg = dx.get_call_graph()
        for edge in fcg.edges:
            mtd1_desp = " ".join([edge[0].get_class_name(), edge[0].get_name(), edge[0].get_descriptor()])
            mtd2_desp = " ".join([edge[1].get_class_name(), edge[1].get_name(), edge[1].get_descriptor()])
            if mtd1_desp in self.methods and\
                mtd2_desp in self.methods:
                src_mtd = self.mtd_desp_2_obj[mtd1_desp]
                tgt_mtd = self.mtd_desp_2_obj[mtd2_desp]
                if src_mtd != tgt_mtd:
                    G._add_method_invoke(src_mtd, tgt_mtd)
    
        for curt_cls in classes:
            curt_cls_aly = dx.get_class_analysis(curt_cls.get_name())
            if len(curt_cls.get_fields()) == 0 or curt_cls_aly is None:
                continue
            for curt_fld_aly in curt_cls_aly.get_fields():
                fld_desp = " ".join([curt_cls.get_name(), curt_fld_aly.get_field().name, curt_fld_aly.get_field().get_descriptor()])
                if fld_desp not in self.fields or fld_desp not in self.fld_desp_2_obj:
                    continue
                curt_fld_obj = self.fld_desp_2_obj[fld_desp]
                for xref_cls, xref_emtd in curt_fld_aly.get_xref_read():
                    if " ".join([xref_cls.name, xref_emtd.get_name(), xref_emtd.get_descriptor()]) not in self.mtd_desp_2_obj:
                        continue
                    xref_emtd_obj = self.mtd_desp_2_obj[" ".join([xref_cls.name, xref_emtd.get_name(), xref_emtd.get_descriptor()])]
                    G._add_field_reference(xref_emtd_obj, curt_fld_obj)
                for xref_cls, xref_emtd in curt_fld_aly.get_xref_write():
                    if " ".join([xref_cls.name, xref_emtd.get_name(), xref_emtd.get_descriptor()]) not in self.mtd_desp_2_obj:
                        continue
                    xref_emtd_obj = self.mtd_desp_2_obj[" ".join([xref_cls.name, xref_emtd.get_name(), xref_emtd.get_descriptor()])]
                    G._add_field_reference(xref_emtd_obj, curt_fld_obj) 
    
        return
    
    def _parse_lib(self):
        analysis = AnalyzeDex(self.lib)[2]
        classes = analysis.get_classes()
        self.construct_graph(classes, self.libgraph, self.libgraph)
        
    def _split_class_beyond_tpl(self, contain_main=True):
        self.classes_beyond_tpl = list()
        if contain_main:
            for curt_class in self.dx.get_classes():
                if curt_class.is_external() or curt_class.is_android_api():
                    continue
                if curt_class not in self.class_dependency_graph:
                    self.classes_beyond_tpl.append(curt_class)
        else:
            for CDG in self.CDGs:
                if CDG == self.class_dependency_graph:
                    continue
                for curt_class in CDG:
                    self.classes_beyond_tpl.append(curt_class)
    
    
    def __call__(self) -> Any:
        self._parse_apk()
        return self.tgtgraph
    
    def _parse_apk(self):
        if self.dataset != 1:
            self.class_dependency_graph = get_clazzitem(self.d, AnalyzeDex(self.lib)[1], self.threshold)
            self.classes_beyond_tpl = []
            intfc = 0
            
        else:
            lib_d = AnalyzeDex(self.lib)[1]
            lib_classes = lib_d.get_classes()
            lib_cls_names = []
            for cls in lib_classes:
                lib_cls_names.append(cls.get_name())
            
            self.class_dependency_graph = []
            self.classes_beyond_tpl = []
            intfc = 0
            for dev in self.d:
                for curt_cls in dev.get_classes():
                    curt_cls_name = curt_cls.name
                    if curt_cls_name in lib_cls_names:
                        if "interface" in curt_cls.get_access_flags_string():
                            intfc += 1
                        self.class_dependency_graph.append(curt_cls)
                    else:
                        self.classes_beyond_tpl.append(curt_cls)
                        
        if not self.validation:
            self.construct_graph(self.class_dependency_graph, self.dx, self.tgtgraph)
        
        
    def _find_external_dependency(self):
        tpl_mtds = []
        for cls in self.class_dependency_graph:
            tpl_mtds += cls.get_methods()
        
        self.xref_tpl = {"packages": set(), "classes": set(), "methods": set(), "fields": set()}
        for cls in self.classes_beyond_tpl:
            cls_aly = self.dx.get_class_analysis(cls.get_name())
            ref_clses = cls_aly.get_xref_to()
            for xref_cls in ref_clses.keys():
                for d in self.d:
                    if d.get_class(xref_cls.name) in self.class_dependency_graph and "interface" not in d.get_class(xref_cls.name).get_access_flags_string():
                        self.xref_tpl["classes"].add(xref_cls.name.replace("/", ".")[1:-1])
                        pkg_name = xref_cls.name.replace("/", ".")[1:-1][:xref_cls.name.replace("/", ".")[1:-1].rfind(".")]
                        self.xref_tpl["packages"].add(pkg_name)
                        break
            
            for mtd_aly in cls_aly.get_methods():
                for xref_cls, xref_emtd, _ in mtd_aly.get_xref_to():
                    if not isinstance(xref_emtd, ExternalMethod):
                        if xref_emtd in tpl_mtds and "interface" not in xref_cls.get_vm_class().get_access_flags_string():
                            self.xref_tpl["methods"].add(" ".join([xref_cls.name, xref_emtd.get_name(), xref_emtd.get_descriptor()]))
                            if xref_cls.name.replace("/", ".")[1:-1] not in self.xref_tpl["classes"]:
                                raise Exception(f"Miss Class: {xref_cls.name.replace('/', '.')[1:-1]}.")
                            
        for cls in self.class_dependency_graph:
            cls_aly = self.dx.get_class_analysis(cls.get_name())
            for fld_aly in cls_aly.get_fields():
                for ref_acls, ref_emtd in fld_aly.get_xref_read():
                    if ref_acls.get_vm_class() in self.classes_beyond_tpl and "interface" not in ref_acls.get_vm_class().get_access_flags_string():
                        self.xref_tpl["fields"].add(" ".join(cls_aly.name, fld_aly.name, fld_aly.get_field().get_descriptor()))
                        if ref_acls.name.replace("/", ".")[1:-1] not in self.xref_tpl["classes"]:
                            raise Exception(f"Miss Class: {ref_acls.name.replace('/', '.')[1:-1]}.")
                for ref_acls, ref_emtd in fld_aly.get_xref_write():
                    if ref_acls.get_vm_class() in self.classes_beyond_tpl and "interface" not in ref_acls.get_vm_class().get_access_flags_string():
                        self.xref_tpl["fields"].add(" ".join(cls_aly.name, fld_aly.name, fld_aly.get_field().get_descriptor()))
                        if ref_acls.name.replace("/", ".")[1:-1] not in self.xref_tpl["classes"]:
                            raise Exception(f"Miss Class: {ref_acls.name.replace('/', '.')[1:-1]}.")
    
    def get_descriptor2type(self, type):
        if type == "I":
            return "int"
        if type == "J":
            return "long"
        if type == "F":
            return "float"
        if type == "D":
            return "double"
        if type == "C":
            return "char"
        if type == "Z":
            return "boolean"
        if type == "V":
            return "void"
        if type == "B":
            return "byte"
        elif type.startswith("["):
            return self.get_descriptor2type(type[type.find('[')+1:])+'[]'
        elif type.startswith("L"):
            return type.replace('/', '.').strip("L").strip(";")
        else:
            return type
    