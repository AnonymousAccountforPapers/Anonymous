from collections import defaultdict

basic_types = [
    "I",
    "J",
    "F",
    "D",
    "C",
    "Z",
    "V",
    "B",
    "S"
]

def ConvertType(_type):
    if _type.startswith("L"):
        if _type.startswith("Ljava/") or \
            _type.startswith("Landroid/os/") or\
            _type.startswith("Landroid/widget/") or\
            _type.startswith("Landroid/content/") or\
            _type.startswith("Landroid/media/") or\
            _type.startswith("Landroid/app/") or\
            _type.startswith("Landroid/graphics/") or\
            _type.startswith("Landroid/util/") or\
            _type.startswith("Landroid/text/") or\
            _type.startswith("Landroid/net/") or\
            _type.startswith("Landroid/database/") or\
            _type.startswith("Landroid/print/") or\
            _type.startswith("Landroid/transition/") or\
            _type.startswith("Landroid/animation/") or\
            _type.startswith("Landroid/provider/") or\
            _type.startswith("Landroid/accessibilityservice/") or\
            _type.startswith("Landroid/speech/") or\
            _type.startswith("Landroid/hardware/") or\
            _type.startswith("Landroid/webkit/") or\
            _type.startswith("Landroid/view/"):
            return _type
        else:
            return "self-defined"
    elif _type.startswith("["):
        return '['+ConvertType(_type[1:])
    else:
        if _type in basic_types:
            return _type
        else:
            raise Exception("Unsupported type: "+_type)


def overlap(list1, list2, threshold):
    dict1 = defaultdict(int)
    dict2 = defaultdict(int)
    for item in list1:
        dict1[item] += 1
    for item in list2:
        dict2[item] += 1
    
    count1 = 0
    for key in set(list1+list2):
        if key in dict1 and key in dict2:
            count1 += min(dict1[key], dict2[key])
    
    return (count1/min(len(list1), len(list2)) > threshold)

class Node:
    def __init__(self, cls_node):
        self.cls_node = cls_node
        self.cls_access_flag = cls_node.get_access_flags_string()
        
        self.extends = cls_node.get_superclassname()
        self.extends = ConvertType(self.extends)
            
        self.implements = []
        for item in cls_node.get_interfaces():
            self.implements.append(ConvertType(item))
            
        self.methods = []
        for mtd in cls_node.get_methods():
            Desp = ""
            if mtd.get_name() == "<init>" or mtd.get_name() == "<clinit>":
                Desp += mtd.get_name()
            _mtd_descriptor = mtd.get_descriptor()
            no_args = _mtd_descriptor.find("(") == _mtd_descriptor.find(")")-1
            if no_args:
                Desp += "()"
            else:
                params = []
                for item in _mtd_descriptor.split("(")[-1].split(")")[0].split(" "):
                    params.append(ConvertType(item))
                Desp += "("+' '.join(params)+")"
            _return = ConvertType(_mtd_descriptor.split(')')[-1])
            Desp += _return
            
            self.methods.append(Desp)
        
        self.fields = []
        for fld in cls_node.get_fields():
            self.fields.append(ConvertType(fld.get_descriptor()))
        
        self.signatures = []
        self.signatures.append("extends:"+self.extends)
        for impl in self.implements:
            self.signatures.append("implements:"+impl)
        for mtd in self.methods:
            self.signatures.append("method:"+mtd)
        for fld in self.fields:
            self.signatures.append("field:"+fld)
    
    def get_interface_signature(self):
        desps = [self.cls_node.get_access_flags_string() + " " + self.cls_node.get_name()]
        for impl in self.cls_node.get_interfaces():
            desps.append("implements:"+impl)
        for mtd in self.cls_node.get_methods():
            desps.append("method:"+mtd.get_name()+" "+mtd.get_descriptor())
        for fld in self.cls_node.get_fields():
            desps.append("field:"+fld.get_name()+" "+fld.get_descriptor())
        return desps
            
    def _match(self, node, threshold):
        if "interface" in self.cls_access_flag:
            if "interface" not in self.cls_access_flag:
                return False
            for item in node.get_interface_signature():
                if item not in self.get_interface_signature():
                    return False
        else:
            if "interface" in self.cls_access_flag:
                return False
            if set(self.cls_access_flag.replace("private", "").replace("protected", "").replace("public", "").replace("final", "").split(" ")) != \
                set(node.cls_access_flag.replace("private", "").replace("protected", "").replace("public", "").replace("final", "").split(" ")):
                return False
            if (len(node.signatures) == 0 and len(self.signatures) != 0) or \
                (len(node.signatures) != 0 and len(self.signatures) == 0):
                return False
            if not overlap(node.signatures, self.signatures, threshold):
                return False
        return True
    
        
def get_clz(vm):
    All_Cls = []
    for v in vm:
        for clz in v.get_classes():
            All_Cls.append(Node(clz))
    return All_Cls

def worker(apk_clz, ALL_LIB_Clz, threshold):
    matched_clz = []
    for clz in apk_clz:
        for lib_clz in ALL_LIB_Clz:
            if clz._match(lib_clz, threshold):
                matched_clz.append(clz)
                break
    return matched_clz

def match(ALL_LIB_Clz, ALL_APK_Clz, threshold):
    matched_clz = worker(ALL_APK_Clz, ALL_LIB_Clz, threshold)
    return matched_clz
    
def get_clazzitem(apk_vm, lib_vm, threshold=0.85):
    All_Lib_Clz = get_clz([lib_vm])
    All_APK_Clz = get_clz(apk_vm)
    matched_clz = match(All_Lib_Clz, All_APK_Clz, threshold)
    return [clz.cls_node for clz in matched_clz]
    