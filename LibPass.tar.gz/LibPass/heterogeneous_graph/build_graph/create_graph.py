import os, sys
import re
import uuid
import networkx as nx
from collections import defaultdict
from enum import Enum, auto


G_Names = defaultdict(set)
G_Names_without_udl = defaultdict(set)

def generate_name(prefix):
    name = 'abc_'+prefix + "_" + str(uuid.uuid4()).replace("-", "_")
    while name in G_Names[prefix]:
        name = prefix + "_" + str(uuid.uuid4()).replace("-", "_")
    G_Names[prefix].add(name)
    return name

def generate_name_without_underline(prefix, concat_char=""):
    name = 'abc'+prefix + str(uuid.uuid4()).replace("-", concat_char)
    while name in G_Names_without_udl[prefix]:
        name = prefix + str(uuid.uuid4()).replace("-", concat_char)
    G_Names_without_udl[prefix].add(name)
    return name


class Node:
    def __init__(self, kwargs) -> None:
        self.data = kwargs
    
    def update(self, key, value) -> None:
        self.data[key] = value


class Node_Type(Enum):
    PACKAGE = auto()
    CLASS = auto()
    METHOD = auto()
    FIELD = auto()
    PARAMETER = auto()
    INTERFACE = auto()
    

class Edge_Type(Enum):
    PACKAGE_CONTAIN = auto()
    CLASS_CONTAIN = auto()
    SUBPACKAGE = auto()
    CLASS_REF = auto()
    INHERIT = auto()
    IMPLEMENT = auto()
    ACCESS_FLAG = auto()
    INNER_CLASS = auto()
    INTERFACE_CONTAIN = auto()
    FIELD_REFERENCE = auto()
    METHOD_INVOKE = auto()
    PARAMETER = auto()

class HeterogeneousGraph:
    def __init__(self, verbose=False) -> None:
        self.G = nx.DiGraph()
        self.verbose = verbose
        self.primitive_type = {'byte', 'char', 'double', 'float', 'int', 'long', 'short', 'boolean'}
        self.class_ref_by_param = defaultdict(set)
        
        self.defaultPackage = Node({
            "pkg_name": None
        })
        self._create_node(self.defaultPackage, Node_Type.PACKAGE)
        
    def post_process(self):
        self.itfc_member_desp = defaultdict(set)
        for itfc in self.get_all_specific_nodes(Node_Type.INTERFACE):
            for mtd in self.get_specific_type_neighbors(itfc, Edge_Type.INTERFACE_CONTAIN, Node_Type.METHOD):
                self.itfc_member_desp[itfc].add(mtd.data["mtd_name"] + " " +self.get_method_descriptor(mtd))


    def get_all_edge_for_node(self, node, mode="all", type=None):
        if mode == "in":
            return self.G.in_edges(node)
        elif mode == "out":
            return self.G.out_edges(node)
        else:
            return self.G.edges(node)
        
    def get_node_type(self, node):
        try:
            return self.G.nodes[node]['type']
        except Exception as e:
            raise Exception(f"{e}: {node} {node.data}")
    
    def get_edge_type(self, edge):
        return self.G.get_edge_data(edge[0], edge[1])['type']
    
    
    def get_all_specific_nodes(self, node_type):
        nodes = []
        for v in self.G.nodes:
            if self.get_node_type(v) == node_type:
                nodes.append(v)
        return nodes
    
    def get_all_nodes(self):
        return self.G.nodes
    
    def make_copy(self):
        copy_graph = HeterogeneousGraph()
        copy_graph.G = self.G.copy()
        copy_graph.class_ref_by_param = self.class_ref_by_param.copy()
        copy_graph.verbose = self.verbose
        copy_graph.defaultPackage = copy_graph.find_package(None)
        copy_graph.itfc_member_desp = self.itfc_member_desp.copy()
        return copy_graph
    
            
    def _create_node(self, node, type):
        return self.G.add_node(node, type=type)
        
    def _create_edge(self, node_from, node_to, type):
        assert node_from is not None
        assert node_to is not None
        
        if type != Edge_Type.SUBPACKAGE and type != Edge_Type.INHERIT and type != Edge_Type.METHOD_INVOKE and type != Edge_Type.INNER_CLASS:
            assert self.get_node_type(node_from) != self.get_node_type(node_to)
        try:
            assert type in Edge_Type
            assert node_from != node_to
        except:
            raise Exception(f"{type} {node_from.data} {node_to.data}")
        return self.G.add_edge(node_from, node_to, type=type)
    
    def print_edges(self, node):
        print(node.data)
        for edge in self.G.in_edges(node):
            print(f"<---{self.get_edge_type((edge[0], edge[1]))}---{self.get_node_type(edge[0])}")
        for edge in self.G.out_edges(node):
            print(f"---{self.get_edge_type((edge[0], edge[1]))}--->{self.get_node_type(edge[1])}")
        
    """
    @ ============================== @
    @             Package
    @ ============================== @
    """
    def _add_package(self, 
                     name: str):
        """
        $ 注意：可能无包名，需要定义一个无包名的默认包空间
        """
        if self.verbose:
            print(f"add package: {name}")
        if name != "" and name is not None:
            package_inst = Node({
                "pkg_name": name
            })
            self._create_node(package_inst, Node_Type.PACKAGE)
        
            return package_inst
        return self.defaultPackage
    
    def _delete_package(self,
                        pkg):
        self.G.remove_node(pkg)
        
    def find_package(self, pkg_name):
        if "int[" == pkg_name:
            raise Exception("Incorrect package name!")
        if pkg_name is not None and pkg_name != "":
            for pkg in self.get_all_specific_nodes(Node_Type.PACKAGE):
                if pkg.data['pkg_name'] == pkg_name:
                    return pkg
        else:
            for pkg in self.get_all_specific_nodes(Node_Type.PACKAGE):
                if pkg.data["pkg_name"] is None:
                    return pkg
        return None
    
    
    """
    @ ============================== @
    @             Class
    @ ============================== @
    """
    def _add_class(self,
                   name: str,
                   access_flag: str="default",
                   superclass: str=None):
        if self.verbose:
            print(f"add class: {name}, access_flag: {access_flag}")
        class_inst = Node({
            "cls_name": name,
            "superclass": superclass,
            "cls_access_flag": access_flag
        })
        self._create_node(class_inst, Node_Type.CLASS)
        return class_inst
    
    def _delete_class(self, cls):
        self.G.remove_node(cls)
    
    def find_class(self, cls_name, pkg_name):
        assert cls_name is not None
        pkg = self.find_package(pkg_name)
        if pkg is None:
            return None
        
        if pkg_name is None:
            cls_desp = cls_name
        else:
            cls_desp = pkg_name+"."+cls_name
        for cls in self.get_specific_type_neighbors(pkg, Edge_Type.PACKAGE_CONTAIN, Node_Type.CLASS):
            if self.get_class_full_name(cls) == cls_desp:
                return cls
        return None
    
    """
    @ ============================== @
    @            Interface
    @ ============================== @
    """
    def _add_interface(self,
                       name: str,
                       access_flag: str = "public abstract",
                       superclass: str=None):
        if self.verbose:
            print(f"add interface: {name}, access_flag: {access_flag}")
        interface_inst = Node({
            "itfc_name": name,
            "superclass": superclass,
            "itfc_access_flag": access_flag
        })
        self._create_node(interface_inst, Node_Type.INTERFACE)
        return interface_inst
    
    def _delete_interface(self, itfc):
        self.G.remove_node(itfc)
        
    def find_interface(self, itfc_name, pkg_name):
        assert itfc_name is not None
        pkg = self.find_package(pkg_name)
        if pkg is None:
            return None
        
        itfc_desp = pkg_name+"."+itfc_name
        for itfc in self.get_specific_type_neighbors(pkg, Edge_Type.PACKAGE_CONTAIN, Node_Type.INTERFACE):
            if self.get_class_full_name(itfc) == itfc_desp:
                return itfc
        return None
    
    """
    @ ============================== @
    @             Method
    @ ============================== @
    """
    def _add_method(self,
                    name: str,
                    paramlist: list,
                    returnType: str,
                    access_flag: str,
                    in_interface: bool=False):
        if self.verbose:
            print(f"add method: {name}, access_flag: {access_flag}, returnType: {returnType}, args: {paramlist}")
        method_inst = Node({
            "mtd_name": name,
            "in_interface": in_interface,
            "mtd_ret": returnType,
            "mtd_access_flag": access_flag
        })
        self._create_node(method_inst, Node_Type.METHOD)
        
        assert isinstance(paramlist, list)
        for i, item in enumerate(paramlist):
            assert isinstance(item, str)
            param_vertex = self._add_parameter(item, i)
            self._add_method_with_param(method_inst, param_vertex)
        
        returnType = returnType.strip('[]')
        if returnType not in self.primitive_type|{'void'}:
            cls_vertex = self.find_class(returnType.split(".")[-1], returnType[:returnType.rfind(".")])
            if cls_vertex:
                self._create_edge(method_inst, cls_vertex, Edge_Type.CLASS_REF)
        
        return method_inst
    
    def _delete_method(self, mtd, whitelist=[]):
        if "parameters" not in whitelist:
            params = self.get_specific_type_neighbors(mtd, Edge_Type.PARAMETER, Node_Type.PARAMETER)
            for p in params:
                self._delete_param(p)
        self.G.remove_node(mtd)
    
    
    def _replace_returnType(self,
                            mtdObj,
                            retType):
        old_rettType = mtdObj.data["mtd_ret"]
        if old_rettType not in self.primitive_type|{'void'}:
            cls_obj = self.find_class(old_rettType.split(".")[-1], old_rettType[:old_rettType.rfind(".")])
            
            if cls_obj and self.G.has_edge(mtdObj, cls_obj) and\
                self.get_edge_type((mtdObj, cls_obj)) == Edge_Type.CLASS_REF:
                self.G.remove_edge(mtdObj, cls_obj)
                
        mtdObj.data["mtd_ret"] = retType
        retType = retType.strip("[]")
        if retType not in self.primitive_type|{'void'}:
            cls_obj = self.find_class(retType.split(".")[-1], retType[:retType.rfind(".")])
            if cls_obj:
                self._create_edge(mtdObj, cls_obj, Edge_Type.CLASS_REF)
                
        return mtdObj
    
    
    def find_method_with_desp(self, mtd_desp, in_interface=False):
        assert mtd_desp is not None
        if in_interface:
            for mtd in self.get_all_specific_nodes(Node_Type.METHOD):
                itfc_obj = self.get_specific_type_neighbor(mtd, Edge_Type.INTERFACE_CONTAIN, Node_Type.INTERFACE, dest=True)
                if itfc_obj is None:
                    continue
                if self.get_method_full_name(self.get_class_descriptor(itfc_obj), mtd) == mtd_desp:
                    return mtd
        else:
            for mtd in self.get_all_specific_nodes(Node_Type.METHOD):
                cls_obj = self.get_specific_type_neighbor(mtd, Edge_Type.CLASS_CONTAIN, Node_Type.CLASS, dest=True)
                if cls_obj is None:
                    continue
                if self.get_method_full_name(self.get_class_descriptor(cls_obj), mtd) == mtd_desp:
                    return mtd
        return None
    
    """
    @ ============================== @
    @           Parameter
    @ ============================== @
    """    
    def _add_parameter(self,
                       param: str,
                       position=-1):
        p_inst = Node({
            "type": param,
            "position": position
        })
        self._create_node(p_inst, Node_Type.PARAMETER)
        param = param.replace('[]', "")
        if param not in self.primitive_type:
            cls_obj = self.find_class(param.split(".")[-1], param[:param.rfind(".")])
            if cls_obj:
                self._create_edge(p_inst, cls_obj, Edge_Type.CLASS_REF)

        return p_inst
    
    def _delete_param(self, p_vertex):
        self.G.remove_node(p_vertex)

    def _add_method_with_param(self,
                               mtd_vertex,
                               p_vertex):
        if p_vertex.data['position'] == -1:
            p_vertex.data['position'] = len(self.get_all_param_of_mtd(mtd_vertex))
        else:
            for mtd in self.get_all_param_of_mtd(mtd_vertex):
                if mtd.data['position'] == p_vertex.data['position']:
                    raise Exception(f"Conflict in parameter ID: {mtd.data} and {p_vertex.data}")
        self._create_edge(mtd_vertex, p_vertex, Edge_Type.PARAMETER)
        
    def get_all_param_of_mtd(self, mtd):
        return self.get_specific_type_neighbors(mtd, Edge_Type.PARAMETER, Node_Type.PARAMETER)

    """
    @ ============================== @
    @             Field
    @ ============================== @
    """
    def _add_field(self,
                   fld_name,
                   fld_type,
                   access_flag,
                   fld_value=None,
                   in_interface: bool=False):
        if self.verbose:
            print(f"add field: {fld_name}, access_flag: {access_flag}, fld_value: {fld_value}, fld_type: {fld_type}")
        field_inst = Node({
            "fld_name": fld_name,
            "in_interface": in_interface,
            "fld_access_flag": access_flag,
            "fld_type": fld_type,
            "fld_value": fld_value
        })
        self._create_node(field_inst, Node_Type.FIELD)
        
        fld_type = fld_type.strip('[]')
        if fld_type not in self.primitive_type:
            try:
                cls_obj = self.find_class(fld_type.split(".")[-1], fld_type[:fld_type.rfind(".")])
                if cls_obj:
                    self._create_edge(field_inst, cls_obj, Edge_Type.CLASS_REF)
            except Exception as e:
                raise Exception(f"{e}: No class found {fld_type}, skiped.")
            
        return field_inst
        
    def _delete_field(self, fld):
        self.G.remove_edge(fld)

    def _replace_type(self,
                      fld,
                      Type):
        old_type = fld.data["fld_type"]
        old_type = old_type.strip('[]')
        if old_type not in self.primitive_type:
            cls_obj = self.find_class(old_type.split(".")[-1], old_type[:old_type.rfind(".")])
            if cls_obj and self.G.has_edge(fld, cls_obj) and\
                self.get_edge_type((fld, cls_obj)) == Edge_Type.CLASS_REF:
                self.G.remove_edge(fld, cls_obj)
        
        fld.data["fld_type"] = Type
        Type = Type.strip("[]")
        if Type not in self.primitive_type:
            cls_obj = self.find_class(Type.split(".")[-1], Type[:Type.rfind(".")])
            if cls_obj:
                self._create_edge(fld, cls_obj, Edge_Type.CLASS_REF)
                
                
    def find_field(self, fld_desp, in_interface=False):
        assert fld_desp is not None
        if in_interface:
            for fld in self.get_all_specific_nodes(Node_Type.FIELD):
                itfc_obj = self.get_specific_type_neighbor(fld, Edge_Type.INTERFACE_CONTAIN, Node_Type.INTERFACE, dest=True)
                if itfc_obj is None:
                    continue
                if self.get_field_full_name(self.get_class_descriptor(itfc_obj), fld) == fld_desp:
                    return fld
        else:
            for fld in self.get_all_specific_nodes(Node_Type.FIELD):
                cls_obj = self.get_specific_type_neighbor(fld, Edge_Type.CLASS_CONTAIN, Node_Type.CLASS, dest=True)
                if cls_obj is None:
                    continue
                if self.get_field_full_name(self.get_class_descriptor(cls_obj), fld) == fld_desp:
                    return fld
        return None

    """
    @ Relationships
    """
    def _add_subpackage(self,
                        pkg1,
                        pkg2):
        if not self.G.has_edge(pkg1, pkg2):
            if self.verbose:
                print(f"{pkg1.data} [has sub package] {pkg2.data}")
            self._create_edge(pkg1, pkg2, Edge_Type.SUBPACKAGE)
        
    def _add_class_implement_interface(self,
                                        cls,
                                        itfc):
        if not self.G.has_edge(cls, itfc):
            if self.verbose:
                print(f"{cls.data} [implements] {itfc.data}")
            self._create_edge(cls, itfc, Edge_Type.IMPLEMENT)
    
    def _add_class_with_method(self,
                               cls,
                               mtd):
        if not self.G.has_edge(cls, mtd):
            if self.verbose:
                print(f"{cls.data} [has method] {mtd.data}")
            self._create_edge(cls, mtd, Edge_Type.CLASS_CONTAIN)
    
    def _add_class_with_field(self,
                              cls,
                              fld):
        if not self.G.has_edge(cls, fld):
            if self.verbose:
                print(f"{cls.data} [has field] {fld.data}")
            self._create_edge(cls, fld, Edge_Type.CLASS_CONTAIN)
    
    def _add_interface_with_method(self,
                                   itfc,
                                   mtd):
        if not self.G.has_edge(itfc, mtd):
            if self.verbose:
                print(f"{itfc.data} [has method] {mtd.data}")
            self._create_edge(itfc, mtd, Edge_Type.INTERFACE_CONTAIN)
    
    def _add_interface_with_field(self,
                              itfc,
                              fld):
        if not self.G.has_edge(itfc, fld):
            if self.verbose:
                print(f"{itfc.data} [has field] {fld.data}")
            self._create_edge(itfc, fld, Edge_Type.INTERFACE_CONTAIN)

    def _add_in_package(self,
                        cls,
                        pkg):
        if not self.G.has_edge(pkg, cls):
            if self.verbose:
                print(f"{pkg.data} [Package contain] {cls.data}")
            self._create_edge(pkg, cls, Edge_Type.PACKAGE_CONTAIN)
        else:
            raise Exception(f"{pkg.data} [ALREADY Package contain] {cls.data}")
            
    def _add_class_inherit(self,
                     cls,
                     super_cls):
        if isinstance(super_cls, str):
            cls.data['superclass'] = super_cls
        elif isinstance(super_cls, Node):
            if not self.G.has_edge(cls, super_cls):
                if self.verbose:
                    print(f"{cls.data} [inherit] {super_cls.data}")
                self._create_edge(cls, super_cls, Edge_Type.INHERIT)
        else:
            raise Exception(f"Wrong type superclass: {super_cls}")
            
    def _add_inner_class(self,
                         cls,
                         innercls):
        if not self.G.has_edge(cls, innercls):
            if self.verbose:
                print(f"{cls.data} [has inner class] {innercls.data}")
            self._create_edge(cls, innercls, Edge_Type.INNER_CLASS)
            
    def _add_field_with_value(self,
                         fld,
                         value):
        fld.data["fld_value"] = value
        return fld
    
    def _add_field_reference(self,
                              mtd,
                              fld):
        if not self.G.has_edge(mtd, fld):
            if self.verbose:
                print(f"{mtd.data} [use filed] {fld.data}")
            self._create_edge(mtd, fld, Edge_Type.FIELD_REFERENCE)
            
    def _add_method_invoke(self,
                            mtd1,
                            mtd2):
        if not self.G.has_edge(mtd1, mtd2):
            if self.verbose:
                print(f"{mtd1.data} [invoke] {mtd2.data}")
            self._create_edge(mtd1, mtd2, Edge_Type.METHOD_INVOKE)
            
    def _remove_edge(self, node1, node2, edge_type):
        if self.G.has_edge(node1, node2) and self.get_edge_type((node1, node2)) == edge_type:
            self.G.remove_edge(node1, node2)
            
            
    def get_ordered_method_parameters(self, mtd):
        params = self.get_specific_type_neighbors(mtd, Edge_Type.PARAMETER, Node_Type.PARAMETER)
        ordered_list = []
        mapper = {}
        for p in params:
            if p.data['position'] not in mapper:
                mapper[p.data['position']] = p
            else:
                raise Exception(f"Conflict Parameter: {p.data['position']}, {mtd.data}")
        for i, p in sorted(mapper.items(), key=lambda x:x[0]):
            ordered_list.append(p)
        return ordered_list
    
    def get_superclass(self, cls):
        supercls = self.get_specific_type_neighbor(cls, Edge_Type.INHERIT, Node_Type.CLASS)
        if supercls:
            if cls.data["superclass"] is not None:
                raise Exception(f"Inconsistency superclass: {cls.data['superclass']}, {supercls.data['cls_name']}")
            return supercls
        return cls.data["superclass"]
              
    def get_innerclass(self, cls, self_create=False):
        if self_create:
            uuid_pattern = re.compile(r'innercls_[0-9a-fA-F]{8}_[0-9a-fA-F]{4}_[0-9a-fA-F]{4}_[0-9a-fA-F]{4}_[0-9a-fA-F]{12}')
            ret = []
            innerclasses = self.get_specific_type_neighbors(cls, Edge_Type.INNER_CLASS, Node_Type.CLASS)
            for incls in innerclasses:
                match = uuid_pattern.match(incls.data["cls_name"].strip(cls.data['cls_name']))
                if match:
                    ret.append(incls)
            return ret
        else:
            return self.get_specific_type_neighbors(cls, Edge_Type.INNER_CLASS, Node_Type.CLASS)

    
    def get_specific_type_neighbor(self, node, edge_type, node_type, dest=False):
        if dest:
            for edge in self.G.in_edges(node):
                if self.get_edge_type((edge[0], edge[1])) == edge_type and self.get_node_type(edge[0]) == node_type:
                    return edge[0]
        else:
            for edge in self.G.out_edges(node):
                if self.get_edge_type((edge[0], edge[1])) == edge_type and self.get_node_type(edge[1]) == node_type:
                    return edge[1]
        return None
    
    def get_specific_type_neighbors(self, node, edge_type, node_type, dest=False):
        ret_nodes = []
        if dest:
            for edge in self.G.in_edges(node):
                if self.get_edge_type((edge[0], edge[1])) == edge_type and self.get_node_type(edge[0]) == node_type:
                    ret_nodes.append(edge[0])
        else:
            for edge in self.G.out_edges(node):
                if self.get_edge_type((edge[0], edge[1])) == edge_type and self.get_node_type(edge[1]) == node_type:
                    ret_nodes.append(edge[1])
        return ret_nodes
    
    def get_type_descriptor(self, type):
        if type == "int":
            return "I"
        elif type == "long":
            return "J"
        elif type == "float":
            return "F"
        elif type == "double":
            return "D"
        elif type == "char":
            return "C"
        elif type == "boolean":
            return "Z"
        elif type == "void":
            return "V"
        elif type == "byte":
            return "B"
        elif '[]' in type:
            return "[" + self.get_type_descriptor(type[:type.rfind('[]')])
        else:
            return "L" + type.replace('.', '/') + ";"
    
    def get_method_descriptor(self, mtd_obj):
        mtd_params = self.get_ordered_method_parameters(mtd_obj)
        descriptor = []
        for p in mtd_params:
            descriptor.append(self.get_type_descriptor(p.data["type"]))
        descriptor = "(" + " ".join(descriptor) + ")" + self.get_type_descriptor(mtd_obj.data["mtd_ret"])
        return descriptor
    
    def get_field_descriptor(self, fld):
        if isinstance(fld, Node):
            cls_obj = self.get_specific_type_neighbor(fld,
                                                    Edge_Type.CLASS_CONTAIN,
                                                    Node_Type.CLASS,
                                                    True)
            return self.get_field_full_name(self.get_class_full_name(cls_obj), fld)
        else:
            return self.get_type_descriptor(fld)
    
    def get_method_full_name(self, class_name, mtd_obj):
        """Return class_name + name + descriptor, separated by spaces (no access flags"""
        mtd_desp = self.get_method_descriptor(mtd_obj)
        return " ".join([class_name,  mtd_obj.data["mtd_name"], mtd_desp])

    def get_field_full_name(self, class_name, fld_obj):
        """Return class_name + name + descriptor, separated by spaces (no access flags"""
        fld_desp = self.get_field_descriptor(fld_obj.data["fld_type"])
        return " ".join([class_name,  fld_obj.data["fld_name"], fld_desp])
    
    def get_method_SootSubSig(self, mtd_obj):
        mtd_params = self.get_ordered_method_parameters(mtd_obj)
        descriptor = []
        for p in mtd_params:
            descriptor.append(p.data["type"])
        descriptor = "(" + ",".join(descriptor) + ")"
        return mtd_obj.data["mtd_ret"]+" "+mtd_obj.data["mtd_name"]+descriptor
    
    def get_method_SootSig(self, mtd_obj):
        assert mtd_obj is not None
        cls_obj = self.get_specific_type_neighbor(mtd_obj,
                                                    Edge_Type.CLASS_CONTAIN,
                                                    Node_Type.CLASS,
                                                    True)

        return self.get_class_full_name(cls_obj)+": "+self.get_method_SootSubSig(mtd_obj)
    
        
    
    def get_class_full_name(self, cls_obj):
        assert cls_obj is not None
        if isinstance(cls_obj, Node):
            pkg_obj = self.get_specific_type_neighbor(cls_obj,
                                                    Edge_Type.PACKAGE_CONTAIN,
                                                    Node_Type.PACKAGE,
                                                    True)
            if pkg_obj is None:
                raise Exception(f"Class {cls_obj.data} does not have package!")
            if self.get_node_type(cls_obj) == Node_Type.CLASS:
                _name = cls_obj.data["cls_name"]
            else:
                _name = cls_obj.data["itfc_name"]
        
            if pkg_obj.data['pkg_name'] is None:
                return _name
            else:
                pkg_name = pkg_obj.data['pkg_name']
                return pkg_name + "." + _name
                
        elif isinstance(cls_obj, str) and cls_obj in self.primitive_type|{"void"}:
            return cls_obj
        
        elif cls_obj.startswith("L"):
            return cls_obj[1:-1].replace("/", ".")
    
    def get_class_descriptor(self, cls_obj):
        assert cls_obj is not None
        if isinstance(cls_obj, Node):
            pkg_obj = self.get_specific_type_neighbor(cls_obj,
                                                    Edge_Type.PACKAGE_CONTAIN,
                                                    Node_Type.PACKAGE,
                                                    True)
            pkg_name = pkg_obj.data['pkg_name']
            if self.get_node_type(cls_obj) == Node_Type.CLASS:
                _name = cls_obj.data["cls_name"]
            else:
                _name = cls_obj.data["itfc_name"]
            if pkg_name is not None:
                desp = pkg_name + "." + _name
            else:
                desp = _name
            return "L"+desp.replace(".", "/")+";"
        elif isinstance(cls_obj, str) and cls_obj in self.primitive_type|{"void"}:
            return cls_obj
            
        
    def get_access_flag(self, obj):
        if self.get_node_type(obj) == Node_Type.CLASS:
            return obj.data["cls_access_flag"]

        elif self.get_node_type(obj) == Node_Type.INTERFACE:
            return obj.data["itfc_access_flag"]

        elif self.get_node_type(obj) == Node_Type.METHOD:
            return obj.data["mtd_access_flag"]

        elif self.get_node_type(obj) == Node_Type.FIELD:
            return obj.data["fld_access_flag"]

        else:
            return None
                
    def get_type(self, type):
        if type == "I":
            return "int"
        if type == "J":
            return "long"
        if type == "F":
            return "float"
        if type == "D":
            return "double"
        if type == "C":
            return "char"
        if type == "Z":
            return "boolean"
        if type == "V":
            return "void"
        if type == "B":
            return "byte"
        elif type.startswith("["):
            return self.get_type_descriptor(type[type.find('[')+1:])+'[]'
        elif type.startswith("L"):
            return type.replace('/', '.').strip("L").strip(";")
        else:
            return type
        
    def get_SootDescriptor(self, node):
        desp = ""
        if self.get_node_type(node) == Node_Type.PACKAGE:
            desp = node.data['pkg_name']
        
        elif self.get_node_type(node) == Node_Type.CLASS:
            desp = self.get_class_full_name(node)
        
        elif self.get_node_type(node) == Node_Type.METHOD:
            desp = self.get_method_SootSig(node)
        
        elif self.get_node_type(node) == Node_Type.FIELD:
            cls_vertex = self.get_specific_type_neighbor(node, Edge_Type.CLASS_CONTAIN, Node_Type.CLASS, dest=True)
            fld2_SootSig = self.get_class_full_name(cls_vertex) +": "+node.data["fld_type"]+" "+node.data["fld_name"]
            desp = fld2_SootSig
        
        elif self.get_node_type(node) == Node_Type.PARAMETER:
            class_ref = self.get_specific_type_neighbor(node, Edge_Type.CLASS_REF, Node_Type.CLASS)
            desp = self.get_SootDescriptor(class_ref)
        
        return desp
        
    
    def add_node(self, granularity, tobe_added_node, added_target):
        import random
        if granularity == Node_Type.PACKAGE:
            assert self.get_node_type(tobe_added_node) == Node_Type.PACKAGE and self.get_node_type(added_target) == Node_Type.PACKAGE
            
            if added_target != self.defaultPackage:
                if parent_pkg := self.get_specific_type_neighbor(added_target, Edge_Type.SUBPACKAGE, Node_Type.PACKAGE, dest=True):
                    self._remove_edge(parent_pkg, added_target, Edge_Type.SUBPACKAGE)
                    self._add_subpackage(parent_pkg, tobe_added_node)
                self._add_subpackage(tobe_added_node, added_target)
            
        elif granularity == Node_Type.CLASS:
            assert self.get_node_type(tobe_added_node) == Node_Type.CLASS and self.get_node_type(added_target) == Node_Type.PACKAGE
            
            self._add_in_package(tobe_added_node, added_target)
            init_mtd = self._add_method('<init>', [], 'void', 'public')
            self._add_class_with_method(tobe_added_node, init_mtd)
            
        elif granularity == Node_Type.METHOD:
            assert self.get_node_type(tobe_added_node) == Node_Type.METHOD and self.get_node_type(added_target) == Node_Type.CLASS
            
            self._add_class_with_method(added_target, tobe_added_node)
            all_mtds = set(self.get_all_specific_nodes(Node_Type.METHOD))
            callee_mtd = random.choice(list(all_mtds))
            while callee_mtd.data['in_interface'] and len(all_mtds):
                callee_mtd = random.choice(list(all_mtds-{callee_mtd}))
            self._add_method_invoke(tobe_added_node, callee_mtd)
            return callee_mtd
            
        elif granularity == Node_Type.FIELD:
            assert self.get_node_type(tobe_added_node) == Node_Type.FIELD and self.get_node_type(added_target) == Node_Type.CLASS
            
            self._add_class_with_field(added_target, tobe_added_node)
            
        elif granularity == Node_Type.PARAMETER:
            assert self.get_node_type(tobe_added_node) == Node_Type.PARAMETER and self.get_node_type(added_target) == Node_Type.METHOD
            
            self._add_method_with_param(added_target, tobe_added_node)
            
        else:
            raise Exception(f"Wrong action type: {granularity}")
        return True
    
    def merge_nodes(self, granularity, tobe_merged_node, merged_target):
        if granularity == Node_Type.PACKAGE:
            to_delete_edge = []
            
            assert self.get_node_type(tobe_merged_node) == Node_Type.PACKAGE and self.get_node_type(merged_target) == Node_Type.PACKAGE
            
            tgt_cls2_set, tgt_itfc2_set, tgt_subpkg_set = set(), set(), set()
            for edge in self.get_all_edge_for_node(merged_target, mode='out'):
                target_node = edge[1]
                if self.get_node_type(target_node) == Node_Type.CLASS:
                    assert self.get_edge_type((edge[0], edge[1])) == Edge_Type.PACKAGE_CONTAIN
                    tgt_cls2_set.add(target_node.data["cls_name"])
                    
                elif self.get_node_type(target_node) == Node_Type.INTERFACE:
                    assert self.get_edge_type((edge[0], edge[1])) == Edge_Type.PACKAGE_CONTAIN
                    tgt_itfc2_set.add(target_node.data["itfc_name"])
                    
            
            Skip = False
            for edge in self.get_all_edge_for_node(tobe_merged_node, mode='out'):
                target_node = edge[1]
                if self.get_node_type(target_node) == Node_Type.CLASS:
                    assert self.get_edge_type((edge[0], edge[1])) == Edge_Type.PACKAGE_CONTAIN
                    if target_node.data["cls_name"] in tgt_cls2_set:
                        Skip = True
                    else:
                        to_delete_edge.append(edge)
                        self._add_in_package(target_node, merged_target)
                    
                if self.get_node_type(target_node) == Node_Type.INTERFACE:
                    assert self.get_edge_type((edge[0], edge[1])) == Edge_Type.PACKAGE_CONTAIN
                    if target_node.data["itfc_name"] in tgt_itfc2_set:
                        Skip = True
                    else:
                        to_delete_edge.append(edge)
                        self._add_in_package(target_node, merged_target)
                
            
            for edge in to_delete_edge:
                self._remove_edge(edge[0], edge[1], Edge_Type.PACKAGE_CONTAIN)
            return True, [tobe_merged_node]
            
        elif granularity == Node_Type.CLASS:
            assert self.get_node_type(tobe_merged_node) == Node_Type.CLASS and self.get_node_type(merged_target) == Node_Type.CLASS
            
            to_delete_node = defaultdict(list)
            
            mtd1_dict, mtd2_dict = {}, {}
            fld1_dict, fld2_dict = {}, {}
            for edge in self.get_all_edge_for_node(merged_target, mode='out'):
                target_node = edge[1]
                if self.get_node_type(target_node) == Node_Type.METHOD:
                    assert self.get_edge_type((edge[0], edge[1])) == Edge_Type.CLASS_CONTAIN
                    mtd2_dict[target_node.data["mtd_name"] + " " +self.get_method_descriptor(target_node)] = target_node
                    
                elif self.get_node_type(target_node) == Node_Type.FIELD:
                    assert self.get_edge_type((edge[0], edge[1])) == Edge_Type.CLASS_CONTAIN
                    fld2_dict[target_node.data["fld_name"]] = target_node
            
            
            supercls1 = self.get_superclass(tobe_merged_node)
            supercls2 = self.get_superclass(merged_target)
            if supercls1:
                if supercls2 is None or supercls2 == "java.lang.Object":
                    if isinstance(supercls1, str):
                        merged_target.data["superclass"] = supercls1
                    else:
                        self._add_class_inherit(merged_target, supercls1)
                        merged_target.data['superclass'] = None
                    
                elif supercls2 is not None and supercls2 != supercls1:
                    if isinstance(supercls2, Node) and isinstance(supercls1, Node):
                        raise Exception(f"Intend to merge classes with different extends: {supercls2.data} and {supercls1.data}")
                    
                    elif isinstance(supercls2, str) and isinstance(supercls1, Node):
                        if supercls2 == "java.lang.Object":
                            self._add_class_inherit(merged_target, supercls1)
                            merged_target.data["superclass"] = None
                        else:
                            raise Exception(f"Intend to merge classes with different extends: {supercls2} and {supercls1.data}")
                    
                    elif isinstance(supercls1, str) and supercls1 != "java.lang.Object" and isinstance(supercls2, Node):
                        raise Exception(f"Intend to merge classes with different extends: {supercls2.data} and {supercls1}")
                    
                    elif isinstance(supercls1, str) and isinstance(supercls2, str):
                        if supercls1 != "java.lang.Object":
                            raise Exception(f"Intend to merge classes with different extends: {supercls2} and {supercls1}")
                        else:
                            pass
            
            
            merged_target.data["cls_access_flag"] = "public" #+ (" static" if "static" in merged_target.data["cls_access_flag"]+' '+cls1_inst.data["cls_access_flag"] else "")
                    
            for edge in self.get_all_edge_for_node(tobe_merged_node, mode='in'):
                source_node = edge[0]
                target_node = edge[1]
                if self.get_edge_type((edge[0], edge[1])) == Edge_Type.PACKAGE_CONTAIN or \
                    self.get_edge_type((edge[0], edge[1])) == Edge_Type.INNER_CLASS:
                    continue
                
                self._create_edge(source_node, merged_target, type=self.get_edge_type((edge[0], edge[1])))
                if self.get_edge_type((edge[0], edge[1])) == Edge_Type.CLASS_REF:
                    if self.get_node_type(source_node) == Node_Type.PARAMETER:
                        source_node.data["type"] = self.get_class_full_name(merged_target)
                    elif self.get_node_type(source_node) == Node_Type.FIELD:
                        source_node.data["fld_type"] = self.get_class_full_name(merged_target)
                    elif self.get_node_type(source_node) == Node_Type.METHOD:
                        source_node.data["mtd_ret"] = self.get_class_full_name(merged_target)
            
            for edge in self.get_all_edge_for_node(tobe_merged_node, mode='out'):
                source_node = edge[0]
                target_node = edge[1]
                if self.get_node_type(target_node) == Node_Type.METHOD:
                    curt_mtd_name = target_node.data["mtd_name"] + " " +self.get_method_descriptor(target_node)
                    if curt_mtd_name in mtd2_dict:
                        if "<init>" == target_node.data["mtd_name"] or "<clinit>" == target_node.data["mtd_name"]:
                            for tmp_edge in self.get_all_edge_for_node(target_node, mode='out'):
                                tmp_mtd_dst = tmp_edge[1]
                                if self.get_edge_type((tmp_edge[0], tmp_edge[1])) == Edge_Type.METHOD_INVOKE or\
                                    self.get_edge_type((tmp_edge[0], tmp_edge[1])) == Edge_Type.FIELD_REFERENCE:
                                    self._add_method_invoke(mtd2_dict[curt_mtd_name], tmp_mtd_dst)
                                    
                            for tmp_edge in self.get_all_edge_for_node(target_node, mode='in'):
                                tmp_mtd_src = tmp_edge[1]
                                if self.get_edge_type((tmp_edge[0], tmp_edge[1])) == Edge_Type.METHOD_INVOKE:
                                    self._add_method_invoke(tmp_mtd_src, mtd2_dict[curt_mtd_name])
                            to_delete_node['method'].append(target_node)
                        else:
                            while target_node.data["mtd_name"] + " " +self.get_method_descriptor(target_node) in mtd2_dict:
                                target_node.data["mtd_name"] += "_new"
                            self._add_class_with_method(merged_target, target_node)
                    else:
                        self._add_class_with_method(merged_target, target_node)
                
                
                elif self.get_node_type(target_node) == Node_Type.FIELD:
                    curt_fld_name = target_node.data["fld_name"]
                    if curt_fld_name in fld2_dict:
                        while target_node.data["fld_name"] in fld2_dict:
                            target_node.data["fld_name"] += "_new"
                        self._add_class_with_field(merged_target, target_node)
                    else:
                        self._add_class_with_field(merged_target, fld=target_node)
                        
                elif self.get_node_type(target_node) == Node_Type.INTERFACE:
                    self._add_class_implement_interface(merged_target, target_node)
                
            for key in to_delete_node:
                if key == "method":
                    for node in to_delete_node[key]:
                        self._delete_method(node)
            self._delete_class(tobe_merged_node)
            return True, []
        
            
        elif granularity == Node_Type.METHOD:
            cls1_inst = self.get_specific_type_neighbor(tobe_merged_node, Edge_Type.CLASS_CONTAIN, Node_Type.CLASS, True)
            cls2_inst = self.get_specific_type_neighbor(merged_target, Edge_Type.CLASS_CONTAIN, Node_Type.CLASS, True)
            assert self.get_node_type(tobe_merged_node) == Node_Type.METHOD and self.get_node_type(merged_target) == Node_Type.METHOD
            
            cls2_inst.data["cls_access_flag"] = "public" + (" strictfp" if "strictfp" in cls1_inst.data["cls_access_flag"]+" "+cls2_inst.data["cls_access_flag"] else "")
            merged_target.data["mtd_access_flag"] = "public" + (" strictfp" if "strictfp" in tobe_merged_node.data["mtd_access_flag"]+" "+merged_target.data["mtd_access_flag"] else "") + (" static" if "static" in merged_target.data["mtd_access_flag"] else "") +(" synchronized" if "synchronized" in tobe_merged_node.data["mtd_access_flag"]+" "+merged_target.data["mtd_access_flag"] else "")
                                                
            for cls1_fld in self.get_specific_type_neighbors(cls1_inst, Edge_Type.CLASS_CONTAIN, Node_Type.FIELD):
                if "private" not in cls1_fld.data["fld_access_flag"] and \
                    "protected" not in cls1_fld.data["fld_access_flag"] and \
                    "public" not in cls1_fld.data["fld_access_flag"]:
                    cls1_fld.data["fld_access_flag"] = "public " + cls1_fld.data["fld_access_flag"]
                else:
                    cls1_fld.data["fld_access_flag"].replace("private", "public").replace("protected", "public").replace("0x0", "public")
            
            mtd1_params = self.get_all_param_of_mtd(tobe_merged_node)
            mtd2_param_len = len(self.get_all_param_of_mtd(merged_target))
            for p in mtd1_params:
                p_vertex = self._add_parameter(p.data["type"], p.data["position"]+mtd2_param_len)
                self._add_method_with_param(merged_target, p_vertex)
            p_vertex = self._add_parameter("boolean")
            self._add_method_with_param(merged_target, p_vertex)
            if "static" not in tobe_merged_node.data["mtd_access_flag"]:
                p_vertex = self._add_parameter(self.get_class_full_name(cls1_inst))
                self._add_method_with_param(merged_target, p_vertex)
            
            for edge in self.get_all_edge_for_node(tobe_merged_node, mode='in'):
                source_node = edge[0]
                target_node = edge[1]
                if self.get_edge_type((edge[0], edge[1])) == Edge_Type.METHOD_INVOKE:
                    self._add_method_invoke(source_node, merged_target)
            
            for edge in self.get_all_edge_for_node(tobe_merged_node, mode='out'):
                source_node = edge[0]
                target_node = edge[1]
                if self.get_edge_type((edge[0], edge[1])) == Edge_Type.METHOD_INVOKE or\
                    self.get_edge_type((edge[0], edge[1])) == Edge_Type.FIELD_REFERENCE:
                    self._create_edge(merged_target, target_node, type=self.get_edge_type((edge[0], edge[1])))

            ret1 = tobe_merged_node.data["mtd_ret"]
            ret2 = merged_target.data["mtd_ret"]
            tobeblist = []
            wrap_cls_name = True
            packing_cls, fld_inst1, fld_inst2, packing_cls_init = None, None, None, None
            if (ret1 == ret2) or ret1 == "void":
                pass

            elif ret1 != "void" and ret2 == "void":
                self._replace_returnType(merged_target, ret1)

            else:
                wrap_cls_name = generate_name("cls")
                tmp_cls_acsf = "public"
                packing_cls = self._add_class(wrap_cls_name, tmp_cls_acsf, superclass="java.lang.Object")
                self._add_in_package(packing_cls, self.defaultPackage)
                fld_inst1 = self._add_field("method1Return", ret1, "public")
                fld_inst2 = self._add_field("method2Return", ret2, "public")
                self._add_class_with_field(packing_cls, fld_inst1)
                self._add_class_with_field(packing_cls, fld_inst2)
                packing_cls_init = self._add_method("<init>", [], "void", "public")
                self._add_class_with_method(packing_cls, packing_cls_init)
                self._replace_returnType(merged_target, self.get_class_full_name(packing_cls))
                tobeblist += [packing_cls, fld_inst1, fld_inst2, packing_cls_init]
                
            self._delete_method(tobe_merged_node, [])
            return wrap_cls_name, tobeblist
            
        elif granularity == Node_Type.FIELD:
            assert self.get_node_type(tobe_merged_node) == Node_Type.FIELD and self.get_node_type(merged_target) == Node_Type.FIELD
            
            tmp_cls_acsf = "public"
            wrap_cls_name = generate_name("cls")
            packing_cls = self._add_class(wrap_cls_name, tmp_cls_acsf, superclass="java.lang.Object")
            assert self.defaultPackage is not None
            self._add_in_package(packing_cls, self.defaultPackage)
            
            new_fld_inst1 = self._add_field("field1", tobe_merged_node.data["fld_type"], "public", tobe_merged_node.data["fld_value"])
            new_fld_inst2 = self._add_field("field2", merged_target.data["fld_type"], "public", merged_target.data["fld_value"])
            self._add_class_with_field(packing_cls, new_fld_inst1)
            self._add_class_with_field(packing_cls, new_fld_inst2)
            
            packing_cls_init = self._add_method("<init>", [], "void", "public")
            self._add_class_with_method(packing_cls, packing_cls_init)
            
            new_fld_type = self.get_class_full_name(packing_cls)
            self._replace_type(tobe_merged_node, new_fld_type)
            self._replace_type(merged_target, new_fld_type)
            
            return wrap_cls_name, [packing_cls, new_fld_inst1, new_fld_inst2, packing_cls_init]
            
            
        elif granularity == Node_Type.PARAMETER:
            assert self.get_node_type(tobe_merged_node) == Node_Type.PARAMETER and self.get_node_type(merged_target) == Node_Type.PARAMETER
            mtd_inst = self.get_specific_type_neighbor(tobe_merged_node, Edge_Type.PARAMETER, Node_Type.METHOD, dest=True)
            
            tmp_cls_acsf = "public"
            wrap_cls_name = generate_name("cls")
            packing_cls = self._add_class(wrap_cls_name, tmp_cls_acsf, superclass="java.lang.Object")
        
            self._add_in_package(packing_cls, self.defaultPackage)
        
            fld_inst1 = self._add_field("param1", tobe_merged_node.data["type"], "public", None)
            fld_inst2 = self._add_field("param2", merged_target.data["type"], "public", None)
            self._add_class_with_field(packing_cls, fld_inst1)
            self._add_class_with_field(packing_cls, fld_inst2)
        
            packing_cls_init = self._add_method("<init>", [], "void", "public")
            self._add_class_with_method(packing_cls, packing_cls_init)
        
            smaller = min(tobe_merged_node.data["position"], merged_target.data["position"])
            larger = max(tobe_merged_node.data["position"], merged_target.data["position"])
            
            
            params = self.get_ordered_method_parameters(mtd_inst)
            param_num = len(params)
            for p in params:
                if p.data["position"] > larger:
                    p.data["position"] -= 1
            self._delete_param(tobe_merged_node)
            self._delete_param(merged_target)

                
            new_param = self._add_parameter(self.get_class_full_name(packing_cls), smaller)

            self._add_method_with_param(mtd_inst, new_param)
            assert len(self.get_ordered_method_parameters(mtd_inst)) + 1 == param_num
            return wrap_cls_name, [packing_cls, fld_inst1, fld_inst2, packing_cls_init]
            
        else:
            raise Exception(f"Wrong action type: {granularity}")
        