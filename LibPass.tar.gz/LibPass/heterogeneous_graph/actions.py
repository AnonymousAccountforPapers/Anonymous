# -*- coding: utf-8 -*-
# ************************************
# @Author           : Bolin Zhou
# @File             : actions_V3.py
# @Create           : 2023/1/12
# @LastModified     : 2024/8/19
# ************************************

from collections import defaultdict
import os, sys
import uuid
import random
import networkx as nx
from heterogeneous_graph.build_graph.create_graph import Edge_Type, HeterogeneousGraph, Node_Type, Node

G_Names = defaultdict(set)
G_Names_without_udl = defaultdict(set)

def generate_name(prefix):
    name = 'abc_'+prefix + "_" + str(uuid.uuid4()).replace("-", "_")
    while name in G_Names[prefix]:
        name = prefix + "_" + str(uuid.uuid4()).replace("-", "_")
    G_Names[prefix].add(name)
    return name

def generate_name_without_underline(prefix, concat_char=""):
    name = 'abc'+prefix + str(uuid.uuid4()).replace("-", concat_char)
    while name in G_Names_without_udl[prefix]:
        name = prefix + str(uuid.uuid4()).replace("-", concat_char)
    G_Names_without_udl[prefix].add(name)
    return name

class Action:
    def __init__(self, Graph: HeterogeneousGraph) -> None:
        self.graph = Graph
        self.backup_graph = None
        self.primitive_type = ["int", "char", "boolean", "byte", "long", "short", "float", "double"]
    
    def recover(self):
        if self.backup_graph:
            del self.graph
            self.graph = self.backup_graph
            self.backup_graph = None
        else:
            print("No checkpoint!")
    
    def checkpoint(self):
        self.backup_graph = self.graph.make_copy()
    
    def add_node(self, params_list):
        if params_list["type"] == "package":
            newpkg_inst = self.graph._add_package(params_list["pkg_name"])
            parent_pkg = None
            if "." in params_list["pkg_name"]:
                parent_pkg = self.graph.find_package(params_list["pkg_name"][:params_list["pkg_name"].rfind(".")])
            if parent_pkg:
                self.graph._add_subpackage(parent_pkg, newpkg_inst)
            return newpkg_inst
            
        elif params_list["type"] == "class":
            newcls_inst = self.graph._add_class(params_list["cls_name"], params_list["cls_access_flag"], superclass="Ljava/lang/Object")
            pkg_inst = self.graph.find_package(params_list["pkg_name"])
            self.graph._add_in_package(newcls_inst, pkg_inst)
            init_mtd = self.graph._add_method('<init>', [], 'void', 'public')
            self.graph._add_class_with_method(newcls_inst, init_mtd)
            return newcls_inst
            
        elif params_list["type"] == "method":
            newmtd_inst = self.graph._add_method(params_list["mtd_name"], params_list["parameters"], params_list["returnType"], params_list["mtd_access_flag"])
            cls_inst = self.graph.find_class(params_list["cls_name"], params_list["pkg_name"])
            self.graph._add_class_with_method(cls_inst, newmtd_inst)
            return newmtd_inst
            
        elif params_list["type"] == "field":
            cls_inst = self.graph.find_class(params_list["in_class"], params_list["in_package"])
            newfld_inst = self.graph._add_field(params_list["fld_name"], params_list["fld_type"], params_list["fld_access_flag"], params_list["fld_value"])
            self.graph._add_class_with_field(cls_inst, newfld_inst)
            return newfld_inst
            
        elif params_list["type"] == "parameter":
            mtd_vertex = params_list["mtd"]
            p_vertex = self.graph._add_parameter(params_list["param_type"])
            self.graph._create_edge_mtd_param(mtd_vertex, p_vertex, Edge_Type.PARAMETER)
            return p_vertex
            
        else:
            raise Exception(f"Wrong action type: {params_list['type']}")
    
    def merge_node(self, params_list):
        if params_list["type"] == "package":
            pkg1_inst = params_list["pkg1"]
            pkg2_inst = params_list["pkg2"]
            assert pkg1_inst and pkg2_inst
            
            cls2_set, itfc2_set = list(), list()
            for edge in self.graph.get_all_edge_for_node(pkg2_inst, mode='out'):
                target_node = self.graph.get_node_by_id(edge.target)
                if target_node["type"] == Node_Type.CLASS:
                    cls2_set.append(target_node['node'].data["cls_name"])
                elif target_node["type"] == Node_Type.INTERFACE:
                    itfc2_set.append(target_node['node'].data["itfc_name"])
            
            Skip = False
            for edge in self.graph.get_all_edge_for_node(pkg1_inst, mode='out'):
                # source_node = self.graph.get_node_by_id(edge.source)
                target_node = self.graph.get_node_by_id(edge.target)
                if (target_node["type"] == Node_Type.CLASS and target_node['node'].data["cls_name"] in cls2_set) or \
                    target_node["type"] == Node_Type.INTERFACE:
                    # 跳过同名类和所有接口
                    Skip = True
                    continue
                self.graph._create_edge(pkg2_inst, target_node, type=edge["type"])
            
            if not Skip:
                self.graph._delete_package(pkg1_inst)
            return Skip
            
        elif params_list["type"] == "class":
            cls1_inst = params_list["cls1"]
            cls2_inst = params_list["cls2"]
            assert cls1_inst and cls2_inst
            
            mtd1_dict, mtd2_dict = {}, {}
            fld1_dict, fld2_dict = {}, {}
            mtd_name_set = set()
            fld_name_set = set()
            for edge in list(self.graph.get_all_edge_for_node(cls2_inst, mode='out')):
                target_node = self.graph.get_node_by_id(edge.target)
                if target_node["type"] == Node_Type.METHOD:
                    mtd2_dict[target_node['node'].data["mtd_name"] + " " +self.graph.get_method_descriptor(target_node)] = dst
                    mtd_name_set.add(target_node['node'].data["mtd_name"] + " " +self.graph.get_method_descriptor(target_node))
                elif target_node["type"] == Node_Type.FIELD:
                    fld2_dict[target_node['node'].data["fld_name"]] = target_node
                    fld_name_set.add(target_node['node'].data["fld_name"])
            
            supercls1 = self.graph.get_superclass(cls1_inst)
            supercls2 = self.graph.get_superclass(cls2_inst)
            if supercls1 is None and supercls2:
                pass
            elif supercls1 and supercls2 is None:
                if isinstance(supercls1, str):
                    cls2_inst['node'].data["superclass"] = supercls1
                else:
                    self.graph._create_edge(cls2_inst, supercls1, Edge_Type.INHERIT)    
            elif supercls1 and supercls2 and supercls2 != supercls1:
                if isinstance(supercls2, Node) and isinstance(supercls1, Node):
                    pass
                elif isinstance(supercls2, str) and isinstance(supercls1, Node):
                    cls2_inst['node'].data["superclass"] = None
                    self.graph._create_edge(cls2_inst, supercls1, Edge_Type.INHERIT)
                elif isinstance(supercls1, str) and isinstance(supercls2, Node):
                    pass
                elif isinstance(supercls1, str) and isinstance(supercls2, str):
                    if supercls1 != "java.lang.Object" and supercls2 == "java.lang.Object":
                        cls2_inst['node'].data["superclass"] = supercls1
            
            cls2_inst.data["cls_access_flag"] = "public" + (" static" if "static" in cls2_inst.data["cls_access_flag"]+' '+cls1_inst.data["cls_access_flag"] else "")
                    
            for edge in self.graph.get_all_edge_for_node(cls1_inst, mode='in'):
                source_node = self.graph.get_node_by_id(edge.source)
                target_node = self.graph.get_node_by_id(edge.target)
                if edge["type"] == Edge_Type.PACKAGE_CONTAIN or \
                    edge["type"] == Edge_Type.INNER_CLASS:
                    continue
                
                self.graph._create_edge(source_node, cls2_inst, type=edge["type"])
                if edge["type"] == Edge_Type.CLASS_REF:
                    if source_node["type"] == Node_Type.PARAMETER:
                        source_node['node'].data["type"] = self.graph.get_class_full_name(cls2_inst)
                    elif source_node["type"] == Node_Type.FIELD:
                        source_node['node'].data["fld_type"] = self.graph.get_class_full_name(cls2_inst)
                    elif source_node["type"] == Node_Type.METHOD:
                        source_node['node'].data["mtd_ret"] = self.graph.get_class_full_name(cls2_inst)
            
            for edge in self.graph.get_all_edge_for_node(cls1_inst, mode='out'):
                source_node = self.graph.get_node_by_id(edge.source)
                target_node = self.graph.get_node_by_id(edge.target)
                if target_node["type"] == Node_Type.METHOD:
                    curt_mtd_name = target_node['node'].data["mtd_name"] + " " +self.graph.get_method_descriptor(target_node)
                    if curt_mtd_name in mtd2_dict:
                        mtd1_dict[target_node] = mtd2_dict[curt_mtd_name]
                        if "<init>" == target_node['node'].data["mtd_name"] or "<clinit>" == target_node['node'].data["mtd_name"]:
                            for tmp_edge in self.graph.get_all_edge_for_node(target_node, mode='out'):
                                tmp_mtd_dst = self.graph.get_node_by_id(edge.target)
                                if tmp_edge["type"] == Edge_Type.METHOD_INVOKE or\
                                    tmp_edge["type"] == Edge_Type.FIELD_REFERENCE:
                                    self.graph._add_method_invoke(mtd2_dict[curt_mtd_name], tmp_mtd_dst)
                            for tmp_edge in self.graph.get_all_edge_for_node(target_node, mode='in'):
                                tmp_mtd_src = self.graph.get_node_by_id(edge.source)
                                if tmp_edge["type"] == Edge_Type.METHOD_INVOKE:
                                    self.graph._add_method_invoke(tmp_mtd_src, mtd2_dict[curt_mtd_name])
                            self.graph._delete_method(target_node)
                        else:
                            while target_node['node'].data["mtd_name"] + " " +self.graph.get_method_descriptor(target_node) in mtd2_dict:
                                target_node['node'].data["mtd_name"] += "_new"
                            self.graph._add_class_with_method(cls2_inst, target_node)
                    else:
                        self.graph._add_class_with_method(cls2_inst, target_node)
                
                
                elif target_node["type"] == Node_Type.FIELD:
                    curt_fld_name = target_node['node'].data["fld_name"]
                    if curt_fld_name in fld2_dict:
                        fld1_dict[target_node] = fld2_dict[curt_fld_name]
                        while target_node['node'].data["fld_name"] in fld2_dict:
                            target_node['node'].data["fld_name"] += "_new"
                        self.graph._add_class_with_field(cls2_inst, target_node)
                    else:
                        self.graph._add_class_with_field(cls2_inst, fld=target_node)
                        
                elif target_node["type"] == Node_Type.INTERFACE:
                    if edge["type"] == Edge_Type.IMPLEMENT:
                        self.graph._add_class_implement_interface(cls2_inst, target_node)
                
            self.graph._delete_class(cls1_inst)
            return cls2_inst
        
            
        elif params_list["type"] == "method":
            mtd1_inst = params_list["mtd1"]
            mtd2_inst = params_list["mtd2"]
            cls1_inst = self.graph.get_specific_type_neighbor(mtd1_inst, Edge_Type.CLASS_CONTAIN, Node_Type.CLASS, True)
            cls2_inst = self.graph.get_specific_type_neighbor(mtd2_inst, Edge_Type.CLASS_CONTAIN, Node_Type.CLASS, True)
            assert mtd1_inst and mtd2_inst
            
            cls2_inst['node'].data["cls_access_flag"] = "public" + (" strictfp" if "strictfp" in cls1_inst['node'].data["cls_access_flag"]+" "+cls2_inst['node'].data["cls_access_flag"] else "")
            mtd2_inst['node'].data["mtd_access_flag"] = "public" + (" strictfp" if "strictfp" in cls1_inst['node'].data["cls_access_flag"]+" "+cls2_inst['node'].data["cls_access_flag"] else "") + (" static" if "static" in mtd2_inst['node'].data["mtd_access_flag"] else "") +(" synchronized" if "synchronized" in mtd2_inst['node'].data["mtd_access_flag"] else "")
                                                
            for cls1_fld in self.graph.get_specific_type_neighbors(cls1_inst, Edge_Type.CLASS_CONTAIN, Node_Type.FIELD):
                cls1_fld['node'].data["fld_access_flag"].replace("private", "public").replace("protected", "public")
            
            mtd1_params = self.graph.get_ordered_method_parameters(mtd1_inst)
            mtd2_param_len = len(self.graph.get_ordered_method_parameters(mtd2_inst))
            for p in mtd1_params:
                p_vertex = self.graph._add_parameter(p['node'].data["type"], p['node'].data["position"]+mtd2_param_len)
                self.graph._create_edge_mtd_param(mtd2_inst, p_vertex, Edge_Type.PARAMETER)

            p_vertex = self.graph._add_parameter("boolean")
            self.graph._create_edge_mtd_param(mtd2_inst, p_vertex, Edge_Type.PARAMETER)

            if "static" not in mtd1_inst['node'].data["mtd_access_flag"]:
                p_vertex = self.graph._add_parameter(self.graph.get_class_full_name(cls1_inst))
                self.graph._create_edge_mtd_param(mtd2_inst, p_vertex, Edge_Type.PARAMETER)
            
            for edge in self.graph.get_all_edge_for_node(mtd1_inst, mode='in'):
                source_node = self.graph.get_node_by_id(edge.source)
                target_node = self.graph.get_node_by_id(edge.target)
                if edge["type"] == Edge_Type.METHOD_INVOKE:
                    self.graph._add_method_invoke(source_node, mtd2_inst)
            
            for edge in self.graph.get_all_edge_for_node(mtd1_inst, mode='out'):
                source_node = self.graph.get_node_by_id(edge.source)
                target_node = self.graph.get_node_by_id(edge.target)
                if edge["type"] == Edge_Type.METHOD_INVOKE or\
                    edge["type"] == Edge_Type.FIELD_REFERENCE:
                    self.graph._create_edge(mtd2_inst, target_node, type=edge["type"])

            ret1 = mtd1_inst['node'].data["mtd_ret"]
            ret2 = mtd2_inst['node'].data["mtd_ret"]

            packing_cls, fld_inst1, fld_inst2, packing_cls_init = None, None, None, None
            if (ret1 == ret2) or ret1 == "void":
                pass

            elif ret1 != "void" and ret2 == "void":
                self.graph._replace_returnType(mtd2_inst, ret1)

            else:
                tmp_cls_acsf = "public"
                packing_cls = self.graph._add_class(params_list["pack_cls_name"], tmp_cls_acsf, superclass="java.lang.Object")
                self.graph._add_in_package(packing_cls, params_list["pkg2"])
                fld_inst1 = self.graph._add_field("method1Return", ret1, "public")
                fld_inst2 = self.graph._add_field("method2Return", ret2, "public")
                self.graph._add_class_with_field(packing_cls, fld_inst1)
                self.graph._add_class_with_field(packing_cls, fld_inst2)
                packing_cls_init = self.graph._add_method("<init>", [], "void", "public")
                self.graph._add_class_with_method(packing_cls, packing_cls_init)
                self.graph._replace_returnType(mtd2_inst, self.graph.get_class_full_name(packing_cls))
                
            self.graph._delete_method(mtd1_inst, [])
            return packing_cls, fld_inst1, fld_inst2, packing_cls_init
            
        elif params_list["type"] == "field":
            fld_inst1 = params_list["fld1"]
            fld_inst2 = params_list["fld2"]
            assert fld_inst1 and fld_inst2
            
            tmp_cls_acsf = "public"
            packing_cls = self.graph._add_class(params_list["pack_cls_name"], tmp_cls_acsf)
            # [2] 设置包装类所属包
            self.graph._add_in_package(packing_cls, params_list["pkg2"])
            # [3] 包装类添加字段
            # self.graph.G.remove_edge(cls_inst1, fld_inst1)
            # self.graph.G.remove_edge(cls_inst2, fld_inst2)
            new_fld_inst1 = self.graph._add_field("field1", fld_inst1['node'].data["fld_type"], "public", fld_inst1['node'].data["fld_value"])
            new_fld_inst2 = self.graph._add_field("field2", fld_inst2['node'].data["fld_type"], "public", fld_inst2['node'].data["fld_value"])
            self.graph._add_class_with_field(packing_cls, new_fld_inst1)
            self.graph._add_class_with_field(packing_cls, new_fld_inst2)
            # [4] 添加<init>函数
            packing_cls_init = self.graph._add_method("<init>", [], "void", "public")
            self.graph._add_class_with_method(packing_cls, packing_cls_init)
            
            new_fld_type = self.graph.get_class_full_name(packing_cls)
            self.graph._replace_type(fld_inst1, new_fld_type)
            self.graph._replace_type(fld_inst2, new_fld_type)
            # self.graph._delete_field(fld_inst1)
            # self.graph._delete_field(fld_inst2)
            
            return packing_cls, new_fld_inst1, new_fld_inst2, packing_cls_init
            
            
        elif params_list["type"] == "parameter":
            mtd_inst = params_list["mtd"]
            params = self.graph.get_ordered_method_parameters(mtd_inst)
            assert mtd_inst
            
            # [1] 创建新的包装类
            # tmp_cls_name = generate_name("cls")
            tmp_cls_acsf = "public"
            packing_cls = self.graph._add_class(params_list["pack_cls_name"], tmp_cls_acsf)
            # [1] 设置包装类所属包
            self.graph._add_in_package(packing_cls, random.choice(self.graph.get_all_specific_nodes(Node_Type.PACKAGE)))
            # [1] 创建新字段
            type1 = params[params_list["param_id"][0]]
            type2 = params[params_list["param_id"][1]]
            fld_inst1 = self.graph._add_field("param1", type1['node'].data["type"], "public", None)
            fld_inst2 = self.graph._add_field("param2", type2['node'].data["type"], "public", None)
            # [1] 包装类添加字段
            self.graph._add_class_with_field(packing_cls, fld_inst1)
            self.graph._add_class_with_field(packing_cls, fld_inst2)
            # [1] 添加<init>函数
            packing_cls_init = self.graph._add_method("<init>", [], "void", "public")
            self.graph._add_class_with_method(packing_cls, packing_cls_init)
            # [2] 删除参数
            smaller = min(params_list["param_id"])
            larger = max(params_list["param_id"])
            for p in params:
                if p['node'].data["position"] > larger:
                    p['node'].data["position"] -= 1
            self.graph._delete_param(type1)
            self.graph._delete_param(type2)
            # [2] 修改参数列表
            new_param = self.graph._add_parameter(self.graph.get_class_full_name(packing_cls), smaller)
            self.graph._create_edge_mtd_param(mtd_inst, new_param, Edge_Type.PARAMETER)
            return packing_cls, fld_inst1, fld_inst2, new_param, packing_cls_init
            
        else:
            raise Exception(f"Wrong action type: {params_list['type']}")