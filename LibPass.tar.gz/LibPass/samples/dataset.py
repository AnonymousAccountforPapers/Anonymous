class GroundTruth:
    def __init__(self, gt_file):
        if isinstance(gt_file, str):
            self.gt_file = gt_file
        elif isinstance(gt_file, int):
            self.gt_file = "samples/D"+str(gt_file)+"/GroundTruth.txt"
        self.groundtruth = {}
        self.__read_gt()
        
    def __read_gt(self):
        with open(self.gt_file) as f:
            lines = [line.strip() for line in f.readlines()]
            for line in lines:
                apk = line.split(":")[0]
                libs = line.split(":")[-1].split(",")
                self.groundtruth[apk] = libs
    
    def __call__(self):
        return self.groundtruth