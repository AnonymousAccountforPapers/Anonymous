import random
import os
import time
import argparse
from datetime import datetime
from samples.dataset import GroundTruth
from attacks.FOA import Attack

random.seed(666)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--detector", type=str, default="libscan")
    parser.add_argument("--budget", type=int, default=20)
    parser.add_argument("--dataset", type=int, default=1)
    parser.add_argument("--score", action="store_true")
    args = parser.parse_args()
    
    gt = GroundTruth(args.dataset)
    
    succeed = 0
    counter = 0
    attack_time_consume = []
    query_time_consume = []
    problem_time_consume = []
    EOR = []
    attacker = Attack(max_step=args.budget, dataset=args.dataset, detector=args.detector, use_score=args.score)
    for apk in gt.groundtruth:
        for tpl in gt.groundtruth[apk]:
            try:
                print(f"\n[{datetime.now()}] {counter}th: {apk+'.apk'} target-{{{tpl+'.dex'}}} | Max_Step: {args.budget} | Attack: LibPass -----")
                start_time = time.time()
                if attacker.reset(TPL=tpl+".dex", APK=apk+'.apk'):
                    is_succeed, _ = attacker()
                    end_time = time.time()
                    if is_succeed:
                        print("    [+] Succeed")
                        succeed += 1
                        
                        attack_time_consume.append(end_time - start_time)
                        query_time_consume.append(attacker.query_time)
                        problem_time_consume.append(attacker.modify_time-attacker.query_time)
                    else:
                        print("    [+] Fail")
            except Exception as e:
                continue
            finally:
                counter += 1
    print(f"\nASR: {succeed/counter*100}%")
    # if succeed:
    #     print(f"Avg Attack Time Consume: {sum(attack_time_consume)/len(attack_time_consume)} (s)")
    #     print(f"Avg Decouple Time Consume: {sum(attacker.decouple_time_consume)/len(attacker.decouple_time_consume)} (s)")
    #     print(f"Avg Query Time Consume: {sum(query_time_consume)/len(query_time_consume)} (s)")
    #     print(f"Avg Problem Space Query Time Consume: {sum(problem_time_consume)/len(problem_time_consume)} (s)")