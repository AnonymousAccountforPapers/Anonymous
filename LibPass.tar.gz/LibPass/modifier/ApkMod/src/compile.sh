javac -encoding utf-8 -cp .:../ThirdParty/soot-4.5.0-20230320.123751-11-jar-with-dependencies.jar tplmod/Main.java

# jar cvf main-1.0.jar tplmod/Main.class
# jar cmf META-INF/MANIFEST.MF main-1.0.jar tplmod/Main.class
# jar uvf main-1.0.jar ../ThirdParty/soot-4.5.0-20230320.123751-11-jar-with-dependencies.jar