package tplmod.utils;

import soot.*;
import soot.jimple.*;
import soot.util.Chain;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class ModUtils {
    private static HashMap<String, HashSet<String>> gNames = new HashMap<>();
    private static HashMap<String, HashSet<String>> gNamesWithoutUdl = new HashMap<>();
    public static String InvokeClass_ClassName = "apkmod.attack.Invoke";
    // public static String InvokeClass_ClassName = generateNameWithoutUnderline("pkg", ".")+"."+"Invoke";
    public static String generateName(String prefix) {
        if (!gNames.containsKey(prefix)) {
            gNames.put(prefix, new HashSet<>());
        }

        String name = prefix + "_" + UUID.randomUUID().toString().replace("-", "_");
        while (gNames.get(prefix).contains(name)) {
            name = prefix + "_" + UUID.randomUUID().toString().replace("-", "_");
        }
        gNames.get(prefix).add(name);
        return name;
    }
    public static String generateNameWithoutUnderline(String prefix, String concatChar) {
        if (!gNamesWithoutUdl.containsKey(prefix)) {
            gNamesWithoutUdl.put(prefix, new HashSet<>());
        }

        String name = prefix + UUID.randomUUID().toString().replace("-", concatChar);
        while (gNamesWithoutUdl.get(prefix).contains(name)) {
            name = prefix + UUID.randomUUID().toString().replace("-", concatChar);
        }
        gNamesWithoutUdl.get(prefix).add(name);
        return name;
    }
    public static void create_invoker(){
        if (!Scene.v().containsClass(InvokeClass_ClassName)){
            return;
        }
        // 创建一个新的Soot类
        SootClass sootClass = new SootClass(InvokeClass_ClassName, Modifier.PUBLIC);
        sootClass.setSuperclass(Scene.v().getSootClass("java.lang.Object"));
        sootClass.setApplicationClass();
        // 创建构造函数
        SootMethod constructor = new SootMethod("<init>", Arrays.asList(), VoidType.v(), Modifier.PUBLIC);
        sootClass.addMethod(constructor);
        // 创建构造函数的body
        JimpleBody wbody = Jimple.v().newBody(constructor);
        constructor.setActiveBody(wbody);
        // 获取构造函数的参数列表和局部变量列表
        Chain<Local> locals = wbody.getLocals();
        Chain<Unit> units = wbody.getUnits();
        // 创建this引用
        Local thisRef = Jimple.v().newLocal("$this", sootClass.getType());
        locals.add(thisRef);
        units.add(Jimple.v().newIdentityStmt(thisRef, Jimple.v().newThisRef(sootClass.getType())));
        // 调用Object类的构造函数
        SootMethod toCall = Scene.v().getMethod("<java.lang.Object: void <init>()>");
        units.add(Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(thisRef, toCall.makeRef())));
        // 构造函数的返回
        units.add(Jimple.v().newReturnVoidStmt());

        // 创建一个新的Soot方法
        SootMethod sootMethod = new SootMethod("invoke_object_method",
                Collections.singletonList(RefType.v("java.lang.Object")),
                VoidType.v(),
                Modifier.PUBLIC | Modifier.STATIC);
        sootClass.addMethod(sootMethod);

        // 创建Soot方法的主体
        JimpleBody body = Jimple.v().newBody(sootMethod);
        sootMethod.setActiveBody(body);

        // 获取方法参数
        Local obj = Jimple.v().newLocal("$obj", sootMethod.getParameterTypes().get(0));
        body.getLocals().add(obj);

        // 添加try块的开头，获取参数
        body.getUnits().addFirst(Jimple.v().newIdentityStmt(obj, Jimple.v().newParameterRef(RefType.v("java.lang.Object"), 0)));

        // 创建一个空的参数列表
        Local argsArray = Jimple.v().newLocal("$obj_args", ArrayType.v(RefType.v("java.lang.Object"), 1));
        body.getLocals().add(argsArray);
        body.getUnits().add(Jimple.v().newAssignStmt(argsArray, Jimple.v().newNewArrayExpr(RefType.v("java.lang.Object"), IntConstant.v(1))));

        // 创建一个临时变量(1维数组)来存储所有方法
        //Local methodsArray = Jimple.v().newLocal("$methodsArray", ArrayType.v(RefType.v("java.lang.Object"), 1));
        Local methodsArray = Jimple.v().newLocal("$methodsArray", ArrayType.v(RefType.v("java.lang.reflect.Method"), 1));
        body.getLocals().add(methodsArray);

        // 获取对象的类
        Local objClass = Jimple.v().newLocal("$objClass", RefType.v("java.lang.Class"));
        body.getLocals().add(objClass);
        body.getUnits().addLast(Jimple.v().newAssignStmt(objClass, Jimple.v().newVirtualInvokeExpr(obj, Scene.v().getSootClass("java.lang.Object").getMethodByName("getClass").makeRef())));

        // 获取对象的所有方法
        //Local methodArrayRef = Jimple.v().newLocal("$methodArrayRef", RefType.v("java.lang.reflect.Method[]"));
        //body.getLocals().add(methodArrayRef);
        body.getUnits().addLast(Jimple.v().newAssignStmt(methodsArray, Jimple.v().newVirtualInvokeExpr(objClass, Scene.v().getSootClass("java.lang.Class").getMethodByName("getDeclaredMethods").makeRef())));
        // 将方法数组存储到临时变量中
        //body.getUnits().addLast(Jimple.v().newAssignStmt(methodsArray, methodArrayRef));

        // 遍历方法并调用
        Local methodIndex = Jimple.v().newLocal("$methodIndex", IntType.v());
        body.getLocals().add(methodIndex);
        Local method = Jimple.v().newLocal("$method", RefType.v("java.lang.reflect.Method"));
        body.getLocals().add(method);
        Local methodCount = Jimple.v().newLocal("$methodCount", IntType.v());
        body.getLocals().add(methodCount);
        body.getUnits().addLast(Jimple.v().newAssignStmt(methodCount, Jimple.v().newLengthExpr(methodsArray)));
        body.getUnits().addLast(Jimple.v().newAssignStmt(methodIndex, IntConstant.v(0)));

        Unit LastNop = Jimple.v().newNopStmt();
        body.getUnits().addLast(LastNop);

        IfStmt check = Jimple.v().newIfStmt(Jimple.v().newLtExpr(methodCount, IntConstant.v(1)), LastNop);
        body.getUnits().insertBefore(check, LastNop);

        IfStmt loopStart = Jimple.v().newIfStmt(Jimple.v().newEqExpr(methodIndex, methodCount), LastNop);
        body.getUnits().insertBefore(loopStart, LastNop);
        body.getUnits().insertBefore(Jimple.v().newAssignStmt(method, Jimple.v().newArrayRef(methodsArray, methodIndex)), LastNop);
        body.getUnits().insertBefore(Jimple.v().newInvokeStmt(Jimple.v().newVirtualInvokeExpr(method, Scene.v().getSootClass("java.lang.reflect.Method").getMethodByName("invoke").makeRef(), obj, argsArray)), LastNop);

        body.getUnits().insertBefore(Jimple.v().newAssignStmt(methodCount, Jimple.v().newAddExpr(methodCount, IntConstant.v(1))), LastNop);
        body.getUnits().insertBefore(Jimple.v().newGotoStmt(loopStart), LastNop);

        Local exception = Jimple.v().newLocal("exception", RefType.v("java.lang.Exception"));
        body.getLocals().add(exception);
        Unit catchExcep = Jimple.v().newIdentityStmt(exception, Jimple.v().newCaughtExceptionRef());
        body.getUnits().add(catchExcep);

        body.getUnits().addLast(Jimple.v().newReturnVoidStmt());
        // 创建一个try块
        Unit beginStmt = body.getUnits().getFirst();
        Unit endStmt = body.getUnits().getPredOf(catchExcep);
        Unit handlerStmt = catchExcep;//body.getUnits().getLast();

        SootClass exceptionClass = Scene.v().getSootClass("java.lang.Exception");
        Trap handler = Jimple.v().newTrap(exceptionClass, beginStmt, endStmt, handlerStmt);
        sootMethod.getActiveBody().getTraps().add(handler);



        check.setTarget(body.getUnits().getLast());
        loopStart.setTarget(body.getUnits().getLast());
        /*System.out.println(body.getLocals());
        System.out.println(body.getUnits());
        System.out.println(body.getTraps());
        System.out.println(body);*/
        //body.validate();
    }

    public static Map<String, String> parseMethodSignature(String methodSignature) {

        // 定义正则表达式
        String regex = "([^:]+): ([^ ]+) ([^(]+)\\(([^)]*)\\)";
        // 编译正则表达式
        Pattern pattern = Pattern.compile(regex);
        // 创建 Matcher 对象
        Matcher matcher = pattern.matcher(methodSignature);

        Map<String, String> result = new HashMap<>();
        // 检查是否匹配成功
        if (matcher.matches()) {
            // 提取类名（包含包名）
            String className = matcher.group(1);
            // 提取返回类型
            String returnType = matcher.group(2);
            // 提取函数名
            String methodName = matcher.group(3);
            // 提取参数列表
            String parameters = matcher.group(4);

            // 输出提取的信息
            /*
            System.out.println("Class Name: " + className);
            System.out.println("Return Type: " + returnType);
            System.out.println("Method Name: " + methodName);
            System.out.println("Parameters: " + parameters);
            */
            result.put("className", className);
            result.put("returnType", returnType);
            result.put("methodName", methodName);
            result.put("parameters", parameters);
            result.put("methodSubSignature", returnType+ " " +methodName+ "(" +parameters+ ")");
        } else {
            System.out.println("Method signature does not match the pattern.");

        }
        return result;
    }

    public static Map<String, String> parseFieldSignature(String fieldSignature) {
        // 定义正则表达式
        String regex = "([^:]+): ([^ ]+) ([^ ]+)";
        // 编译正则表达式
        Pattern pattern = Pattern.compile(regex);
        // 创建 Matcher 对象
        Matcher matcher = pattern.matcher(fieldSignature);

        Map<String, String> result = new HashMap<>();
        // 检查是否匹配成功
        if (matcher.matches()) {
            // 提取类名（包含包名）
            String className = matcher.group(1);
            // 提取类型
            String fieldType = matcher.group(2);
            // 提取字段名
            String fieldName = matcher.group(3);

            // 输出提取的信息
/*
            System.out.println("Class Name: " + className);
            System.out.println("fieldType: " + fieldType);
            System.out.println("fieldName: " + fieldName);
*/
            result.put("className", className);
            result.put("fieldType", fieldType);
            result.put("fieldName", fieldName);
            result.put("fieldSubSignature", fieldType+" "+fieldName);
        } else {
            System.out.println("Method signature does not match the pattern.");
        }
        return result;
    }

    public static void insertDebugInfo(JimpleBody methodBody, String info){
        /*InvokeStmt printStmt = Jimple.v().newInvokeStmt(
                Jimple.v().newStaticInvokeExpr(
                        Scene.v().getSootClass("java.io.PrintStream").getMethod("void println(java.lang.String)").makeRef(),
                        StringConstant.v(info)
                )
        );*/
        Local outputStream = Jimple.v().newLocal("outStream", RefType.v("java.io.PrintStream"));
        methodBody.getLocals().add(outputStream);

        Stmt getOutputStreamStmt = Jimple.v().newAssignStmt(
                outputStream,
                Jimple.v().newStaticFieldRef(
                        Scene.v().getField("<java.lang.System: java.io.PrintStream out>").makeRef()
                )
        );
        methodBody.getUnits().add(getOutputStreamStmt);

        Stmt printStmt = Jimple.v().newInvokeStmt(
                Jimple.v().newVirtualInvokeExpr(
                        outputStream,
                        Scene.v().getMethod("java.io.PrintStream println(java.lang.String)").makeRef(),
                        StringConstant.v(info)
                )
        );
        methodBody.getUnits().insertBefore(printStmt, methodBody.getFirstNonIdentityStmt());
    }
}
