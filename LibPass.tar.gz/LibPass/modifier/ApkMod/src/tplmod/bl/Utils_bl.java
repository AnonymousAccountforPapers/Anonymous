package tplmod.bl;

import soot.*;
import soot.jimple.*;
import soot.jimple.internal.JInvokeStmt;
import soot.jimple.internal.JNewExpr;
import soot.jimple.toolkits.callgraph.CallGraph;
import soot.jimple.toolkits.callgraph.Edge;

import java.lang.reflect.Method;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils_bl {
    private static HashMap<String, HashSet<String>> gNames = new HashMap<>();
    private static HashMap<String, HashSet<String>> gNamesWithoutUdl = new HashMap<>();
    public static String generateName(String prefix) {
        if (!gNames.containsKey(prefix)) {
            gNames.put(prefix, new HashSet<>());
        }

        String name = prefix + "_" + UUID.randomUUID().toString().replace("-", "_");
        while (gNames.get(prefix).contains(name)) {
            name = prefix + "_" + UUID.randomUUID().toString().replace("-", "_");
        }
        gNames.get(prefix).add(name);
        return name;
    }
    public static String generateNameWithoutUnderline(String prefix, String concatChar) {
        if (!gNamesWithoutUdl.containsKey(prefix)) {
            gNamesWithoutUdl.put(prefix, new HashSet<>());
        }

        String name = prefix + UUID.randomUUID().toString().replace("-", concatChar);
        while (gNamesWithoutUdl.get(prefix).contains(name)) {
            name = prefix + UUID.randomUUID().toString().replace("-", concatChar);
        }
        gNamesWithoutUdl.get(prefix).add(name);
        return name;
    }

    public static boolean check_exist_expr(Unit u){
        Class<?>[] u_interface = u.getClass().getInterfaces();
        for (Class<?> itfc: u_interface){
            Method[] mtds = itfc.getMethods();
            for (Method mtd: mtds){
                if (mtd.getName().equals("containsInvokeExpr")){
                    return true;
                }
            }
        }
        return false;
    }

    public static void Process_Xref_Class(SootClass old, SootClass curt, Map<String, String> mapFields, Map<String, String>mapMethods){
        // 继承关系
        // 类型声明
        // 实例化：字段、局部变量
        // 反射
        // 方法调用、静态字段引用
        for(SootClass cls: Scene.v().getClasses()){
            // 1. 继承
            if (cls.getSuperclass() == old){
                cls.setSuperclass(curt);
            }
            // 2. 字段类型声明
            //    [!] 其他字段声明为被合并的类类型
            for(SootField fld: cls.getFields()){
                if (fld.getType().toString().equals(old.getName())){
                    String old_sig = fld.getSignature();
                    fld.setType(curt.getType());
                    String new_sig = fld.getSignature();
                    mapFields.put(old_sig, new_sig);
                }
            }
            // 3. 函数内部：局部变量 + 参数引用 + 参数声明
            // TODO: JIdentityStmt除了用于@this和@parameter还用于什么情况
            for(SootMethod mtd: cls.getMethods()){
                List<Type> param_list = new ArrayList<>();
                for (Type param: mtd.getParameterTypes()){

                    if (param instanceof ArrayType && param.toString().substring(0, param.toString().indexOf("[]")).equals(old.getType().toString())){
                        String substr = param.toString();
                        ArrayType new_param = curt.getType().makeArrayType();
                        while (substr.contains("[]")){
                            substr = substr.substring(0, substr.lastIndexOf("[]"));
                            new_param = new_param.makeArrayType();
                        }

                        param_list.add(new_param);
                    }
                    else if (!(param instanceof ArrayType) && param.equals(old.getType())){
                        param_list.add(curt.getType());
                    }
                    else{
                        param_list.add(param);
                    }
                }

                if (!param_list.isEmpty()){
                    mtd.setParameterTypes(param_list);
                }

                for (Unit unit: mtd.getActiveBody().getUnits()){
                    if (unit instanceof IdentityStmt identityStmt && identityStmt.getRightOp().getType() == old.getType()){
                        ((Local) identityStmt.getLeftOp()).setType(curt.getType());

                        // Type: JimpleLocal ParamterRef
                        if (identityStmt.getRightOp().getClass() == ParameterRef.class){
                            ParameterRef paramRef = new ParameterRef(curt.getType(), ((ParameterRef) identityStmt.getRightOp()).getIndex());
                            identityStmt.setRightOp(paramRef);
                        }
                        // Type: JimpleLocal ThisRef
                        else if(identityStmt.getRightOp().getClass() == ThisRef.class){
                            ThisRef thisRef = new ThisRef(curt.getType());
                            identityStmt.setRightOp(thisRef);
                        }
                    }
                    else if (unit instanceof AssignStmt assignStmt){
                        // LeftType: JimpleLocal
                        if (assignStmt.getLeftOp().getClass() == soot.jimple.internal.JimpleLocal.class && assignStmt.getLeftOp().getType() == old.getType()){
                            ((Local) assignStmt.getLeftOp()).setType(curt.getType());
                        }
                        // LeftType: JInstanceFieldRef
                        //    [!] 其他函数引用
                        else if (assignStmt.getLeftOp().getClass() == soot.jimple.internal.JInstanceFieldRef.class && assignStmt.getLeftOp().getType() == old.getType()){
                            soot.jimple.internal.JInstanceFieldRef jInstanceFieldRef = (soot.jimple.internal.JInstanceFieldRef) assignStmt.getLeftOp();
                            SootFieldRef fldref = jInstanceFieldRef.getFieldRef();
                            SootField fld = Scene.v().getField(mapFields.get(fldref.getSignature()));
                            Value base = jInstanceFieldRef.getBase();
                            ((soot.jimple.internal.JimpleLocal) base).setType(Scene.v().getSootClass("com.l.adlib_android.AdView").getType());
                            soot.jimple.internal.JInstanceFieldRef newfldref = new soot.jimple.internal.JInstanceFieldRef(base, fld.makeRef());
                            assignStmt.setLeftOp(newfldref);
                        }



                        // RightType: JNewExpr
                        if (assignStmt.getRightOp().getClass() == JNewExpr.class && assignStmt.getRightOp().getType() == old.getType()){
                            JNewExpr jNewExpr = new JNewExpr(curt.getType());
                            assignStmt.setRightOp(jNewExpr);
                        }
                        // RightType: JimpleLocal
                        else if (assignStmt.getRightOp().getClass() == soot.jimple.internal.JimpleLocal.class && assignStmt.getRightOp().getType() == old.getType()){
                            ((Local) assignStmt.getLeftOp()).setType(curt.getType());
                        }
                        // LeftType: JNewArrayExpr
                        else if (assignStmt.getRightOp().getClass() == soot.jimple.internal.JNewArrayExpr.class && assignStmt.getRightOp().getType() == old.getType()){
                            ((soot.jimple.internal.JNewArrayExpr) assignStmt.getRightOp()).setBaseType(curt.getType());
                        }
                        // LeftType: JInstanceFieldRef
                        else if (assignStmt.getRightOp().getClass() == soot.jimple.internal.JInstanceFieldRef.class && assignStmt.getRightOp().getType() == old.getType()){
                            soot.jimple.internal.JInstanceFieldRef jInstanceFieldRef = (soot.jimple.internal.JInstanceFieldRef) assignStmt.getRightOp();
                            SootFieldRef fldref = jInstanceFieldRef.getFieldRef();
                            SootField fld = Scene.v().getField(mapFields.get(fldref.getSignature()));
                            Value base = jInstanceFieldRef.getBase();
                            ((soot.jimple.internal.JimpleLocal) base).setType(Scene.v().getSootClass("com.l.adlib_android.AdView").getType());
                            soot.jimple.internal.JInstanceFieldRef newfldref = new soot.jimple.internal.JInstanceFieldRef(base, fld.makeRef());
                            assignStmt.setRightOp(newfldref);
                        }
                    }

                    else if (unit instanceof JInvokeStmt invokeStmt) {
                        InvokeExpr invokeExpr = invokeStmt.getInvokeExpr();
                        SootMethod refMtd = invokeExpr.getMethod();
                        if (mapMethods.containsKey(refMtd.getSignature())){
                            invokeExpr.setMethodRef(Scene.v().getMethod(mapMethods.get(refMtd.getSignature())).makeRef());
                        }
                    }
                    else{
                        if (check_exist_expr(unit)){
                            // un
//                            InvokeExpr invokeExpr = unit.getInvokeExpr();
//                            SootMethod refMtd = invokeExpr.getMethod();
//                            if (mapMethods.containsKey(refMtd.getSignature())){
//                                invokeExpr.setMethodRef(Scene.v().getMethod(mapMethods.get(refMtd.getSignature())).makeRef());
                            }
                        }
                    }
                }
            }
            // 4. 反射
        }

    public static void Process_Xref_Method(SootMethod old, SootMethod curt){
        // 3. 函数内部：函数调用
        /*
            JIdentityStmt: 变量声明
            JInvokeStmt:
                - specialinvoke: super()初始化
                - staticinvoke: 静态调用
                - virtualinvoke: 对象成员函数调用
             JAssignStmt: 变量赋值（可能存在字段引用，如：this.adView.setOnAdListenerEx(0);）
                - 可能存在invoke，如：$z0 = virtualinvoke $r2.<android.app.Activity: boolean isFinishing()>()
        */
        CallGraph cg = Scene.v().getCallGraph();
        Iterator<Edge> in_edges = cg.edgesInto(old);
        while (in_edges.hasNext()){
            Edge edge = in_edges.next();
            SootMethod src_mtd = edge.src();
            Body src_mtd_body = src_mtd.getActiveBody();
            for (Unit u: src_mtd_body.getUnits()){
                if (u instanceof JInvokeStmt invokeStmt){
                    InvokeExpr invokeExpr = invokeStmt.getInvokeExpr();
                    invokeExpr.setMethodRef(curt.makeRef());
                }
                else {
                    if(check_exist_expr(u)){
                        //un
//                        InvokeExpr invokeExpr = invokeStmt.getInvokeExpr();
//                        invokeExpr.setMethodRef(curt.makeRef());
                    }
                }
            }
        }

    }


    public static int GetModifier(String access_flag){
        int modifiers = 0;
        if (access_flag.contains("public")){
            modifiers |= Modifier.PUBLIC;
        }
        if (access_flag.contains("private")){
            modifiers |= Modifier.PRIVATE;
        }
        if (access_flag.contains("protected")){
            modifiers |= Modifier.PROTECTED;
        }
        if (access_flag.contains("static")){
            modifiers |= Modifier.STATIC;
        }
        if (access_flag.contains("final")){
            modifiers |= Modifier.FINAL;
        }
        if (access_flag.contains("synchronized")){
            modifiers |= Modifier.SYNCHRONIZED;
        }
        if (access_flag.contains("volatile")){
            modifiers |= Modifier.VOLATILE;
        }
        if (access_flag.contains("transient")){
            modifiers |= Modifier.TRANSIENT;
        }
        if (access_flag.contains("native")){
            modifiers |= Modifier.NATIVE;
        }
        if (access_flag.contains("interface")){
            modifiers |= Modifier.INTERFACE;
        }
        if (access_flag.contains("abstract")){
            modifiers |= Modifier.ABSTRACT;
        }
        if (access_flag.contains("strict")){
            modifiers |= Modifier.STATIC;
        }
        if (access_flag.contains("annotation")){
            modifiers |= Modifier.ANNOTATION;
        }
        if (access_flag.contains("constructor")){
            modifiers |= Modifier.CONSTRUCTOR;
        }
        if (access_flag.contains("declared_synchronized")){
            modifiers |= Modifier.DECLARED_SYNCHRONIZED;
        }
        if (access_flag.contains("enum")){
            modifiers |= Modifier.ENUM;
        }
        return modifiers;
    }



    static Type String2Type(String strType){

        Type retType = null;
        // PrimType
        if (strType.equals("Boolean")){
            retType = BooleanType.v();
        } else if (strType.equalsIgnoreCase("byte")) {
            retType = ByteType.v();
        } else if (strType.equalsIgnoreCase("char")) {
            retType = CharType.v();
        } else if (strType.equalsIgnoreCase("double")) {
            retType = DoubleType.v();
        } else if (strType.equalsIgnoreCase("float")) {
            retType = FloatType.v();
        } else if (strType.equalsIgnoreCase("int")) {
            retType = IntType.v();
        } else if (strType.equals("long")) {
            retType = LongType.v();
        } else if (strType.equals("short")) {
            retType = ShortType.v();
        }
        // VoidType
        else if (strType.equals("void")) {
            retType = VoidType.v();
        }
        // ArrayType
        else if (strType.contains("[]")) {
            String[] tmp = strType.split("\\[");
            int dim = 0;
            Pattern pattern = Pattern.compile("\\[]");
            Matcher matcher = pattern.matcher(strType);
            while (matcher.find()){
                dim ++;
            }
            if (!tmp[0].isEmpty()) {
                retType = ArrayType.v(Utils_bl.String2Type(tmp[0]), dim);
            }
        }
        // TODO: 泛型 Ljava/util/Map;`<I:Ljava/lang/String;>;
        else if (strType.contains("<>")) {
            return null;
        }
        // RefType
        else{
            retType = RefType.v(strType.substring(1, strType.length()-1).replace("/", "."));
        }
        return retType;
    }

    static List<Type> ConvertParameters(List<String> params){
        List<Type> parameters = new ArrayList<>();
        for (String p: params){
            Type param = Utils_bl.String2Type(p);
            parameters.add(param);
        }
        return parameters;
    }

    static String getType(String desp){
        if (desp.equals("I"))
            return "int";
        else if (desp.equals("J"))
            return "long";
        else if (desp.equals("F"))
            return "float";
        else if (desp.equals("D"))
            return "double";
        else if (desp.equals("C"))
            return "char";
        else if (desp.equals("Z"))
            return "boolean";
        else if (desp.equals("V"))
            return "void";
        else if (desp.equals("B"))
            return "byte";
        else if (desp.contains("["))
            return Utils_bl.getType(desp.substring(1)) + "[]";
        else
            return desp.substring(1, desp.length()-1).replace('/', '.');
    }


    static int compatible_modifier_for_method(int modifier1, int modifier2){
        boolean final_volatile = (((modifier1 & Modifier.FINAL) != 0) && ((modifier2 & Modifier.VOLATILE) !=0)) ||
                                    (((modifier1 & Modifier.VOLATILE) != 0) && ((modifier2 & Modifier.FINAL) !=0));
        boolean abstract_synchronized = (((modifier1 & Modifier.ABSTRACT) != 0) && ((modifier2 & Modifier.SYNCHRONIZED) !=0)) ||
                                        (((modifier1 & Modifier.SYNCHRONIZED) != 0) && ((modifier2 & Modifier.ABSTRACT) !=0));
        boolean abstract_native = (((modifier1 & Modifier.ABSTRACT) != 0) && ((modifier2 & Modifier.NATIVE) !=0)) ||
                (((modifier1 & Modifier.NATIVE) != 0) && ((modifier2 & Modifier.ABSTRACT) !=0));
        boolean abstract_private = (((modifier1 & Modifier.ABSTRACT) != 0) && ((modifier2 & Modifier.PRIVATE) !=0)) ||
                (((modifier1 & Modifier.PRIVATE) != 0) && ((modifier2 & Modifier.ABSTRACT) !=0));
        boolean abstract_final = (((modifier1 & Modifier.FINAL) != 0) && ((modifier2 & Modifier.ABSTRACT) !=0)) ||
                (((modifier1 & Modifier.ABSTRACT) != 0) && ((modifier2 & Modifier.FINAL) !=0));

        boolean abstract_static = (((modifier1 & Modifier.ABSTRACT) != 0) && ((modifier2 & Modifier.STATIC) !=0)) ||
                (((modifier1 & Modifier.STATIC) != 0) && ((modifier2 & Modifier.ABSTRACT) !=0));

        boolean w_o_static = (((modifier1 & Modifier.STATIC) != 0) && ((modifier2 & Modifier.STATIC) ==0)) ||
                (((modifier1 & Modifier.STATIC) == 0) && ((modifier2 & Modifier.STATIC) !=0));

        if (abstract_static || w_o_static) {
            System.out.println("conflict modifiers! " + modifier1 + " and " + modifier2);
            return 0;
        }

        if (final_volatile)
            return (modifier1 | modifier2) ^ Modifier.FINAL;
        else if (abstract_synchronized)
            return (modifier1 | modifier2) ^ Modifier.ABSTRACT;
        else if (abstract_native)
            return (modifier1 | modifier2) ^ Modifier.NATIVE;
        else if (abstract_private)
            return (modifier1 | modifier2) ^ Modifier.ABSTRACT ^ Modifier.PRIVATE | Modifier.PUBLIC;
        else if (abstract_final)
            return (modifier1 | modifier2) ^ Modifier.ABSTRACT ^ Modifier.FINAL;
        else
            return modifier1 | modifier2;
    }

    public static List<String> GetInvokes(String invokes){
        // mtd_sig1, mtd_sig2, mtd_sig3, ...
        List<String> ret = new ArrayList<>();
        ret.addAll(Arrays.asList(invokes.split(", ")));
        return ret;
    }

}
