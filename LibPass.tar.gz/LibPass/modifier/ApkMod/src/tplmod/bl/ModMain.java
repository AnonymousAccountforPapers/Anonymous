package tplmod.bl;

import soot.*;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class ModMain {
    public static List<String> action_seq;
    static String granularity;
    static String action_Type;
    static Map<String, String> parameters = new HashMap<>();

    static List<String> add_packages;

    static boolean start = false;

    public static void main(String[] args) throws Exception {
        String action_seq_file = args[0];
        String apk_path = args[2];
        String save_path = args[3];
        String outPath = args[4];

        System.out.println(apk_path);
        SootEnvironment.init(apk_path, "android_jars", outPath);

        List<String> lines = Files.readAllLines(Paths.get(action_seq_file));

        for (String line : lines) {
            if (line.startsWith("[granularity]")) {
                String regex = "\\[granularity]\\s(.*)\\s\\[action type]\\s(.*)";
                Pattern pattern = Pattern.compile(regex);
                Matcher matcher = pattern.matcher(line);
                if (matcher.find()) {
                    // 提取 [granularity] 后面的内容
                    granularity = matcher.group(1);

                    // 提取 [action type] 后面的内容
                    action_Type = matcher.group(2);

                    // 输出结果
                    System.out.println("granularity: " + granularity);
                    System.out.println("action type: " + action_Type);
                }
                parameters.clear();
            } else {
                String regex = "[a-zA-Z0-9_]*:(.*)";
                Pattern pattern = Pattern.compile(regex);
                Matcher matcher = pattern.matcher(line);
                if (matcher.find()) {
                    String param_name = matcher.group(1);
                    String param_value = matcher.group(2);
                    parameters.put(param_name, param_value);
                }
            }
        }

        apply_action();
    }

    static void apply_action() {
        if (action_Type.equals("add_node")) {
            if (granularity.equals("package")) {
                String pkg_name = parameters.get("pkg_name");
                add_package(pkg_name);
            } else if (granularity.equals("class")) {
                String pkg_name = parameters.get("pkg_name");
                String cls_name = parameters.get("cls_name");
                String cls_access_flag = parameters.get("cls_access_flag");
                SootClass newClass = add_class(pkg_name, cls_name, cls_access_flag);
            } else if (granularity.equals("method")) {
                String pkg_name = parameters.get("pkg_name");
                String cls_name = parameters.get("cls_name");
                String mtd_name = parameters.get("mtd_name");
                String mtd_access_flag = parameters.get("mtd_access_flag");
                String parameter_list = parameters.get("parameters");
                String returnType = parameters.get("returnType");
                SootMethod newMethod = add_method(pkg_name, cls_name, mtd_name, mtd_access_flag, parameter_list, returnType);
            } else if (granularity.equals("field")) {
                String pkg_name = parameters.get("pkg_name");
                String cls_name = parameters.get("cls_name");
                String fld_name = parameters.get("fld_name");
                String fld_type = parameters.get("fld_type");
                String fld_access_flag = parameters.get("fld_access_flag");
                SootField newField = add_field(pkg_name, cls_name, fld_name, fld_type, fld_access_flag);
            } else if (granularity.equals("parameter")) {
                String mtd_fullname = parameters.get("mtd_fullname");
                String param_type = parameters.get("param_type");
                SootMethod modMethod = add_parameter(mtd_fullname, param_type);
            }

        } else if (action_Type.equals("merge_node")) {
            if (granularity.equals("package")) {
                String pkg1_name = parameters.get("pkg1_name");
                String pkg2_name = parameters.get("pkg2_name");
                List<SootClass> merged_Classes = merge_package(pkg1_name, pkg2_name);
            } else if (granularity.equals("class")) {
                String cls1_fullname = parameters.get("cls1_fullname");
                String cls2_fullname = parameters.get("cls2_fullname");
                SootClass merged_cls = merge_class(cls1_fullname, cls2_fullname);
            } else if (granularity.equals("method")) {
                String mtd1_fullname = parameters.get("mtd1_fullname");
                String mtd2_fullname = parameters.get("mtd2_fullname");
                String pkg_name = parameters.get("pkg_name");
                SootMethod merge_method = merge_method(mtd1_fullname, mtd2_fullname, pkg_name);
                //un
//            } else if (action_config[0] == "field") {
//                merge_field();
//            } else if (action_config[0] == "parameter") {
//                merge_parameter();
            }
        }
    }
    /************************************************************************/
    /*********************************ADD NODE*******************************/
    /************************************************************************/
    static void add_package(String pkg_name) {
        add_packages.add(pkg_name);
    }

    static SootClass add_class(String pkg_name, String cls_name, String access_flag) {
        // TODO: SuperClass ?
        int modifiers = Utils_bl.GetModifier(access_flag);
        SootClass class2Add;
        if (pkg_name != null) {
            class2Add = new SootClass(pkg_name + "." + cls_name, modifiers);
        } else {
            class2Add = new SootClass(cls_name, modifiers);
        }
        Scene.v().addClass(class2Add);

        return class2Add;
        // getApplicationClasses()
        /*for(SootClass sClass: Scene.v().getClasses()){
            sClass.
        }*/
    }


    static SootMethod add_method(String pkg_name, String cls_name, String mtd_name, String access_flag, String params, String ret) {
        int modifiers = Utils_bl.GetModifier(access_flag);
        List<String> str_params = new ArrayList<>();
        StringBuilder sb = null;
        for (char ch : params.toCharArray()) {
            if (ch == '\'') {
                if (!start) {
                    sb = new StringBuilder();
                    start = true;
                } else {
                    start = false;
                    str_params.add(sb.toString());
                }
                continue;
            }
            if (start) {
                sb.append(ch);

            }
        }
        List<Type> parameters = Utils_bl.ConvertParameters(str_params);
        Type retType = Utils_bl.String2Type(ret);
        SootMethod method2Add = null;
        for (SootClass curtClass : Scene.v().getClasses()) {
            if (curtClass.getPackageName().equals(pkg_name) && curtClass.getShortName().equals(cls_name)) {
                // TODO: List<SootClass> thrownExceptions
                method2Add = new SootMethod(mtd_name, parameters, retType, modifiers);
                curtClass.addMethod(method2Add);
                break;
            }
        }
        assert method2Add != null;
        return method2Add;
    }

    static SootField add_field(String pkg_name, String cls_name, String fld_name, String fld_type, String access_flag) {
        int modifiers = Utils_bl.GetModifier(access_flag);
        Type fldType = Utils_bl.String2Type(fld_type);
        SootField field2Add = null;
        for (SootClass curtClass : Scene.v().getClasses()) {
            if (curtClass.getPackageName().equals(pkg_name) && curtClass.getShortName().equals(cls_name)) {
                // TODO: List<SootClass> thrownExceptions
                assert fldType != null;
                field2Add = new SootField(fld_name, fldType, modifiers);
                curtClass.addField(field2Add);
            }
        }
        assert field2Add != null;
        return field2Add;
    }

    static SootMethod add_parameter(String mtd_fullname, String param_type) {
        String[] parts = mtd_fullname.split(" ");
        int split_idx = parts[0].lastIndexOf(".");
        String pkg_name = parts[0].substring(0, split_idx);
        String cls_name = parts[0].substring(split_idx + 1);
        String mtd_name = parts[1];
        Type ParamAdd = Utils_bl.String2Type(param_type);
        SootMethod methodMod = null;
        for (SootClass curtClass : Scene.v().getClasses()) {
            if (curtClass.getPackageName().equals(pkg_name) && curtClass.getShortName().equals(cls_name)) {
                // TODO: List<SootClass> thrownExceptions
                methodMod = curtClass.getMethodByName(mtd_name);
                List<Type> parameters = methodMod.getParameterTypes();
                parameters.add(ParamAdd);
                methodMod.setParameterTypes(parameters);
            }
        }
        assert methodMod != null;
        // TODO: body
        Body mtdbody = methodMod.getActiveBody();
        // TODO: do something

        return methodMod;
    }

    /************************************************************************/
    /********************************MERGE NODE******************************/
    /************************************************************************/
    static List<SootClass> merge_package(String pkg_name1, String pkg_name2) {
        List<SootClass> merged_classes = new ArrayList<>();
        for (SootClass curtClass : Scene.v().getClasses()) {
            if (curtClass.getPackageName().equals(pkg_name1)) {
                curtClass.setName(pkg_name2 + "." + curtClass.getShortName());
                merged_classes.add(curtClass);
            }
        }
        return merged_classes;
    }

    static SootClass merge_class(String cls1_fullname, String cls2_fullname) {
        int modifiers = Utils_bl.GetModifier("public");
        Map<String, String> mapMethods = new HashMap<>();
        Map<String, String> mapFields = new HashMap<>();
        SootClass cls1 = null, cls2 = null;
        for (SootClass curtClass : Scene.v().getClasses()) {
            if (curtClass.getName().equals(cls1_fullname))
                cls1 = curtClass;
            if (curtClass.getName().equals(cls2_fullname))
                cls2 = curtClass;
        }
        assert cls1 != null && cls2 != null;
        cls2.setModifiers(modifiers);

        // 处理 <init> 和 <clinit> 函数
        // <init>构造函数可以有多个？因此不需要额外处理
        List<String> mtd_desp_set2 = new ArrayList<>();
        for (SootMethod mtd : cls2.getMethods())
            mtd_desp_set2.add(mtd.getSubSignature());
        for (SootMethod mtd : cls1.getMethods()) {
            if (mtd.getName().contains("<clinit>")) {
                SootMethod clinit_mtd2 = cls2.getMethodByName("<clinit>");
                if (clinit_mtd2 != null) {
                    Body clinit_body2 = clinit_mtd2.getActiveBody();
                    Body clinit_body1 = mtd.getActiveBody();
                    for (Unit u : clinit_body1.getUnits()) {
                        clinit_body2.getUnits().add(u);
                    }
                    clinit_body2.validate();
                    Utils_bl.Process_Xref_Method(mtd, clinit_mtd2);
                    continue;
                }
            } else if (mtd_desp_set2.contains(mtd.getSubSignature()))
                mtd.setName(Utils_bl.generateName(mtd.getName()));

            cls2.addMethod(mtd);
            cls1.removeMethod(mtd);
        }
        // 处理同名字段，同名函数不需要处理，因为参数列表不同
        List<String> fld_name_set2 = new ArrayList<>();
        for (SootField fld : cls2.getFields())
            fld_name_set2.add(fld.getName());
        for (SootField fld : cls1.getFields()) {
            if (fld_name_set2.contains(fld.getName())) {
                fld.setName(Utils_bl.generateName(fld.getName()));

                cls2.addField(fld);
            }
        }

        for (SootClass itfc : cls1.getInterfaces())
            cls2.addInterface(itfc);

        // 处理父类
        SootClass supercls1 = cls1.getSuperclass();
        SootClass supercls2 = cls2.getSuperclass();
        if (supercls1 != supercls2) {
            if (supercls2.getName().equals("java.lang.Objects")) {
                cls2.setSuperclass(supercls1);
            } else {
                // TODO
                System.out.println("superclass1: " + supercls1.getName());
                System.out.println("superclass2: " + supercls2.getName());
            }
        }

        // 处理交叉引用
        //un
//        Utils_bl.Process_Xref(cls1, cls2);

        Scene.v().removeClass(cls1);
        return cls2;

    }

    static SootMethod merge_method(String mtd1_fullname, String mtd2_fullname, String pkg_name) {
        SootClass cls1 = null, cls2 = null;
        SootMethod mtd1 = null, mtd2 = null;
        // 获取到类和方法对象
        for (SootClass curtClass : Scene.v().getClasses()) {
            if (curtClass.getName().equals(mtd1_fullname.split(" ")[0])) {
                cls1 = curtClass;
                for (SootMethod curtMtd : curtClass.getMethods()) {
                    List<String> params_desp = Arrays.asList(mtd1_fullname.split(" ")[2].split("\\(")[1].split("\\)")[0].split(" "));
                    List<String> params_str = params_desp.stream().map(Utils_bl::getType).toList();
                    List<Type> params = Utils_bl.ConvertParameters(params_str);
                    Type retType = Utils_bl.String2Type(Utils_bl.getType(mtd1_fullname.split(" ")[2].split("\\)")[1]));
                    assert retType != null;
                    if (curtMtd.getSubSignature().equals(
                            SootMethod.getSubSignature(mtd1_fullname.split(" ")[1], params, retType))
                    ) {
                        mtd1 = curtMtd;
                    }
                }
            }
            if (curtClass.getName().equals(mtd2_fullname.split(" ")[0])) {
                cls2 = curtClass;
                for (SootMethod curtMtd : curtClass.getMethods()) {
                    List<String> params_desp = Arrays.asList(mtd2_fullname.split(" ")[2].split("\\(")[1].split("\\)")[0].split(" "));
                    List<String> params_str = params_desp.stream().map(Utils_bl::getType).toList();
                    List<Type> params = Utils_bl.ConvertParameters(params_str);
                    Type retType = Utils_bl.String2Type(Utils_bl.getType(mtd2_fullname.split(" ")[2].split("\\)")[1]));
                    assert retType != null;
                    if (curtMtd.getSubSignature().equals(
                            SootMethod.getSubSignature(mtd2_fullname.split(" ")[1], params, retType))
                    ) {
                        mtd2 = curtMtd;
                    }
                }
            }
        }

        // 处理修饰符
        int new_modifiers = Utils_bl.compatible_modifier_for_method(mtd1.getModifiers(), mtd2.getModifiers());
        mtd2.setModifiers(new_modifiers);
        //
        //un
        return mtd2;
    }



}