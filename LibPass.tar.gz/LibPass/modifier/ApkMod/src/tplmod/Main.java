package tplmod;

import tplmod.add.*;
import tplmod.merge.*;
import tplmod.bl.Utils_bl;
import tplmod.utils.ModUtils;

import soot.*;
import soot.options.Options;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    static public class PerturbClass{
        public String ActType;
        List<String> params;
    }

    public static int cnt = 0;
    public static boolean DEBUG = false;
    public static List<String> add_packages = new ArrayList<>();
    public static void main(String[] args) throws IOException {
        long startTime = System.nanoTime();
        if (args.length == 1 && (args[0].equals("--help") || args[0].equals("-h"))) {
            // 显示帮助信息
            System.out.println("""
            ApkMod v0.1      Jingkun Zhang, Bolin Zhou     Mar 20th 2024
            Usage： java -jar ApkMod.jar -ap android-platforms_dir -app apk_dir -out output_path -mod modifications file/dir
            Example: java -jar ApkMod.jar
                            -ap android-platforms-master
                            -app test_v2\\apks\\
                            -out test_v2\\output\\
                            -mod test_v2\\modifications\\
            """);
            return;
        }
        String androidPlatformsDir = null;
        String apkPath = null;
        String outputPath = null;
        String modificationsFile = null;

        // 遍历参数数组
        for (int i = 0; i < args.length; i++) {
            if (args[i].equals("-ap") && i + 1 < args.length) {
                androidPlatformsDir = args[i + 1];
            } else if (args[i].equals("-app") && i + 1 < args.length) {
                apkPath = args[i + 1];
            } else if (args[i].equals("-out") && i + 1 < args.length) {
                outputPath = args[i + 1];
            } else if (args[i].equals("-mod") && i + 1 < args.length) {
                modificationsFile = args[i + 1];
            }
        }
        // System.out.println("androidPlatformsDir: "+androidPlatformsDir);
        // System.out.println("apkPath: "+apkPath);
        // System.out.println("outputPath: "+outputPath);
        // System.out.println("modificationsFile: "+modificationsFile);

        

        // Map<String, List<List<String>>> parseResult = parsePerturbations(modificationsFile);
        List<PerturbClass> parseResult = parsePerturbations(modificationsFile);
        SootSetup(androidPlatformsDir, apkPath, outputPath);
        ModUtils.create_invoker();
        String[] tmp_list = apkPath.split("/");
        String OutapkName = outputPath + tmp_list[tmp_list.length - 1];
        Run(parseResult, OutapkName);
        // try {
        //     Run(parseResult);
        // } catch (IOException e) {
        //     System.out.println(e);
        // }
        

        long endTime = System.nanoTime();
        long elapsedTime = endTime - startTime;
        long elapsedTimeInMilliseconds = elapsedTime / 1000000000;
        // System.out.println("Run time(s): " + elapsedTimeInMilliseconds);

    }

    public static void Run(List<PerturbClass> parseResult, String outputApk) { // throws IOException
        for (PerturbClass item : parseResult) {
            List<String> params = item.params;
            if (item.ActType.equals("AddPackage")){
                AddPackage.process(params.get(0).substring(1, params.get(0).length()-1), 
                        params.get(1).substring(1, params.get(1).length()-1));
            } else if (item.ActType.equals("AddClass")){
                AddClass.process(params.get(0).substring(1, params.get(0).length()-1),
                        Utils_bl.GetModifier(params.get(1).substring(1, params.get(1).length()-1)));
            } else if (item.ActType.equals("AddMethod")){
                AddMethod.process(params.get(0).substring(1, params.get(0).length()-1),
                        Utils_bl.GetModifier(params.get(1).substring(1, params.get(1).length()-1)),
                        params.get(2).substring(1, params.get(2).length()-1));
            } else if (item.ActType.equals("AddField")){
                AddField.process(params.get(0).substring(1, params.get(0).length()-1),
                        Utils_bl.GetModifier(params.get(1).substring(1, params.get(1).length()-1)));
            } else if (item.ActType.equals("AddParam")){
                AddParam.process(params.get(0).substring(1, params.get(0).length()-1),
                        params.get(1).substring(1, params.get(1).length()-1));
            } else if (item.ActType.equals("MergePackage")){
                MergePackage.process(params.get(0).substring(1, params.get(0).length()-1),
                        params.get(1).substring(1, params.get(1).length()-1));
            } else if (item.ActType.equals("MergeClass")){
                try {
                    MergeClass.process(params.get(0).substring(1, params.get(0).length() - 1),
                            params.get(1).substring(1, params.get(1).length() - 1));
                }
                catch (Exception e) {System.out.println(e);}
            } else if (item.ActType.equals("MergeMethod")){
                MergeMethod.process(params.get(0).substring(1, params.get(0).length()-1),
                                    params.get(1).substring(1, params.get(1).length()-1),
                                    params.get(2).substring(1, params.get(2).length()-1));
            } else if (item.ActType.equals("MergeField")){
                MergeField.process(params.get(0).substring(1, params.get(0).length()-1),
                                    params.get(1).substring(1, params.get(1).length()-1),
                                    params.get(2).substring(1, params.get(2).length()-1));
            } else if (item.ActType.equals("MergeParam")){
                MergeParam.process(params.get(0).substring(1, params.get(0).length()-1),
                                    Integer.parseInt(params.get(1).substring(1, params.get(1).length()-1)),
                                    Integer.parseInt(params.get(2).substring(1, params.get(2).length()-1)),
                                    params.get(3).substring(1, params.get(3).length()-1));
            }
            
            // long endTime = System.nanoTime();
            // long elapsedTime = endTime - startTime;
            // long elapsedTimeInMilliseconds = elapsedTime / 1000000000;
            // System.out.println("Done: " + elapsedTimeInMilliseconds+"(s)\n");
        }

        // runPacks的话mergeclass就报错，其他三个合并没问题
        //PackManager.v().runPacks();

        File file = new File(outputApk);
        // 检查文件是否存在
        if (file.exists()) {
            // System.out.println("Apk existed.");
            file.delete();
        }

        PackManager.v().writeOutput();
        // System.out.println("Perturbation Done: "+outputApk);
        // try {
        // }
        // catch (Exception e) {
        //     System.out.println("ERROR: wrong when write");
        //     System.out.println(e);
        // }
    }

    // public static Map<String, List<List<String>>> parsePerturbations(String modificationsFile){
    //     Map<String, List<List<String>>> result = new HashMap<>();
    //     String regex = "\\{[^}]+}";
    //     Pattern pattern = Pattern.compile(regex);

    //     try {
    //         FileReader fileReader = new FileReader(modificationsFile);
    //         BufferedReader bufferedReader = new BufferedReader(fileReader);
    //         String line;

    //         String ActionType;
    //         line = bufferedReader.readLine();
    //         if (line.charAt(0) == '0') {
    //             ActionType = "Add";
    //         } else {
    //             ActionType = "Merge";
    //         }

    //         if (line.charAt(1) == '0') {
    //             ActionType += "Package";
    //         } else if (line.charAt(1) == '1') {
    //             ActionType += "Class";
    //         } else if (line.charAt(1) == '2') {
    //             ActionType += "Method";
    //         } else if (line.charAt(1) == '3') {
    //             ActionType += "Field";
    //         } else {
    //             ActionType += "Param";
    //         }
    //         List<List<String>> all_params = new ArrayList<>();
    //         while ((line = bufferedReader.readLine()) != null) {
    //             List<String> params = new ArrayList<>();
    //             Matcher matcher = pattern.matcher(line);
    //             while (matcher.find()) {
    //                 String param = matcher.group();
    //                 params.add(param);
    //             }
    //             all_params.add(params);
    //         }
    //         result.put(ActionType, all_params);
    //         bufferedReader.close();
    //     }catch (IOException e){
    //         System.out.println("ERROR: wrong when read: "+modificationsFile);
    //         System.out.println(e);
    //     }


    //     return result;
    // }

    public static List<PerturbClass> parsePerturbations(String modificationsFile){
        int count = 0;
        List<PerturbClass> result = new ArrayList<>();
        String regex = "\\{[^}]+}";
        Pattern pattern = Pattern.compile(regex);

        try {
            FileReader fileReader = new FileReader(modificationsFile);
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            String line;
            String ActionType = null;
            while ((line = bufferedReader.readLine()) != null) {
                if (line.charAt(0) == '0' || line.charAt(0) == '1'){
                    if (line.charAt(0) == '0') {
                        ActionType += "Add";
                    } else {
                        ActionType += "Merge";
                    }

                    if (line.charAt(1) == '0') {
                        ActionType += "Package";
                    } else if (line.charAt(1) == '1') {
                        ActionType += "Class";
                    } else if (line.charAt(1) == '2') {
                        ActionType += "Method";
                    } else if (line.charAt(1) == '3') {
                        ActionType += "Field";
                    } else {
                        ActionType += "Param";
                    }
                } else{
                    PerturbClass tmp = new PerturbClass();
                    tmp.ActType = ActionType;
                    List<String> params = new ArrayList<>();
                    Matcher matcher = pattern.matcher(line);
                    while (matcher.find()) {
                        params.add(matcher.group());
                    }
                    tmp.params = params;
                    result.add(tmp);
                }
            }
            bufferedReader.close();
        }catch (IOException e){
            System.out.println("ERROR: wrong when read: "+modificationsFile);
            System.out.println(e);
        }

        return result;
    }

    public static void SootSetup(String androidJar, String apkPath, String outputPath) {
        // Reset the Soot settings (it's necessary if you are analyzing several APKs)
        G.reset();
        // Generic options
//        Options.v().set_no_bodies_for_excluded(true);
        Options.v().set_allow_phantom_refs(true);
        Options.v().set_whole_program(true);
        Options.v().set_src_prec(Options.src_prec_apk); // Determine the input is an APK
//        Options.v().set_prepend_classpath(true);
        // Read (APK Dex-to-Jimple) Options
        Options.v().set_android_jars(androidJar); // The path to Android Platforms
        Options.v().set_process_dir(Collections.singletonList(apkPath)); // Provide paths to the APK
        Options.v().set_process_multiple_dex(true);  // Inform Dexpler that the APK may have more than one .dex files
        Options.v().set_include_all(true);
        // Write (APK Generation) Options
        Options.v().set_output_format(Options.output_format_dex);
        Options.v().set_output_dir(outputPath);
        Options.v().set_validate(true); // Validate Jimple bodies in each transofrmation pack
//        Options.v().set_app(true);

        Options.v().set_throw_analysis(Options.throw_analysis_dalvik);
        Options.v().set_ignore_resolution_errors(true);
        Options.v().set_wrong_staticness(3);
        // Resolve required classes
        Scene.v().loadNecessaryClasses();
        Scene.v().loadBasicClasses();
        
    }

    // 本来尝试用调用图找xref，没成功
//        public static Set<SootMethod> MethodXREF(SootMethod targetMethod, CallGraph cg, SootMethod smt) throws IOException {
//        // 创建一个集合来保存调用或反射给定方法的其他方法
//        Set<SootMethod> methodCallers = new HashSet<>();
////        FileWriter fileWriter = new FileWriter("./test.txt", true);
////        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
//        // 遍历调用图的边缘
//        for (Edge edge : cg) {
////            bufferedWriter.write(edge.src().getSubSignature().toString() + " --> " + edge.tgt().getSubSignature().toString() + "\n");
//            if (edge.srcStmt() != null && edge.srcStmt().containsInvokeExpr()) {
//                System.out.println(edge.src().getSubSignature().toString() + " --> " + edge.tgt().getSubSignature().toString());
//                InvokeExpr invokeExpr = edge.srcStmt().getInvokeExpr();
//                if (invokeExpr.getMethod().getSignature().equals(targetMethod.getSubSignature())) {
//                    methodCallers.tplmod.add(edge.src().method());
//                }
//            }
//        }
////        bufferedWriter.close();
//        // 打印结果
//        System.out.println("Methods calling or reflecting method " + targetMethod.getSubSignature() + ":");
//        for (SootMethod caller : methodCallers) {
//            System.out.println(caller);
//        }
//        return methodCallers;
//    }

}




