package tplmod.add;

import soot.*;
import soot.jimple.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import tplmod.Main;
public class AddPackage {
    public static void process(String pkg_name, String old_pkgname){
        Main.add_packages.add(pkg_name);
        if (old_pkgname.equals(" ")){
            return;
        }
        List<String> tmp = Arrays.asList(old_pkgname.split("\\."));
        String sub_pkg = tmp.get(tmp.size()-1);

        for (SootClass sootClass: Scene.v().getApplicationClasses()){
            String originalPackage = sootClass.getPackageName();
            if (originalPackage.startsWith(old_pkgname)){
                List<String> curt_sub_pkgNames = Arrays.asList(originalPackage.split("\\."));
                
                int index = curt_sub_pkgNames.indexOf(sub_pkg);
                curt_sub_pkgNames.add(index, pkg_name);
                String newPackageName = String.join(".", curt_sub_pkgNames);
                modifyClassPackage(sootClass, newPackageName);
            }
        }
    }

    private static void modifyClassPackage(SootClass sootClass, String newPackageName) {
        String old_name = sootClass.getName();
        
        // 构建新的类名
        String newClassName = newPackageName + "." + sootClass.getShortName();

        // 更新 SootClass 名称
        sootClass.setName(newClassName);

        // TODO 对应修改 字段、方法、指令...
        process_methods(sootClass, old_name);
    }

    public static void process_methods(SootClass new_cls, String cls_old_signature){
        List<String> smtd_sigs = new ArrayList<>();
        for (SootMethod smtd: new_cls.getMethods()){
            smtd_sigs.add(smtd.getSignature());
            // System.out.println(smtd.getSignature());
        }

        // Notice: invoke会不会变？ InvokeExpr不会变，但是其通过getMethod()获取到的调用方法是会改变的，因此需要手动修改Expr(makeRef)，所以要提前记录invokeExpr
        Map<InvokeExpr, String> invokeExprs2Sig = new HashMap<>();
        for (SootClass App_cls : Scene.v().getApplicationClasses()) {
            for (SootMethod sm: App_cls.getMethods()){
                if (sm.isConcrete()) {
                    Body body = sm.retrieveActiveBody();
                    for (Unit u : body.getUnits()) {
                        if (u instanceof Stmt stmt) {
                            if (stmt.containsInvokeExpr()) {
                                InvokeExpr invokeExpr = stmt.getInvokeExpr();
                                if (smtd_sigs.contains(invokeExpr.getMethod().getSignature())) {
                                    //invokeExpr.setMethodRef(smtd_map.get(invokeExpr.getMethod().getSignature()).makeRef());
                                    invokeExprs2Sig.put(invokeExpr, invokeExpr.getMethod().getSignature());
                                }
                            }
                        }
                    }
                }
            }
        }

        // 构建老的sig到新的SootMethod对象的映射
        Map<String, SootMethod> smtd_map = new HashMap<>();

        for (SootMethod smtd: new_cls.getMethods()) {
            // TAG 还未更新Sig
            String old_signature = smtd.getSignature();
            // Notice: 重新设置声明类，让signature置null，然后重新计算signature
            smtd.setDeclaringClass(new_cls);
            smtd_map.put(old_signature, smtd);
        }

        for (InvokeExpr invokeExpr: invokeExprs2Sig.keySet()){
            invokeExpr.setMethodRef(smtd_map.get(invokeExprs2Sig.get(invokeExpr)).makeRef());
        }

        // TAG 修改参数、返回、local、字段是该类的地方
        for (SootClass cls : new ArrayList<>(Scene.v().getApplicationClasses())) {
            List<SootMethod> method_params_need = new ArrayList<>();
            List<List<Type>> method_params = new ArrayList<>();
            List<SootMethod> method_return_need = new ArrayList<>();
            List<SootMethod> need_modify_methods = new ArrayList<>();
            List<String> need_modify_methods_sig = new ArrayList<>();
            for (SootMethod method : new ArrayList<>(cls.getMethods())) {
                boolean need_modify_method = false;
                String ori_sm_sig = method.getSignature();
                if (method.isConcrete()) {
                    Body body = method.retrieveActiveBody();
                    if (method.getParameterTypes().contains(RefType.v(cls_old_signature))) {
                        need_modify_method = true;
                        List<Type> params = new ArrayList<>(method.getParameterTypes());

                        for (int i = 0; i < method.getParameterCount(); i++) {
                            if (params.get(i).equals(RefType.v(cls_old_signature))) {
//                                method.getParameterTypes().set(i, sc2.getType());
                                params.set(i, new_cls.getType());
                                for (Unit unit : body.getUnits()) {
                                    for (ValueBox box : unit.getUseAndDefBoxes()) {
                                        Value value = box.getValue();
                                        if (value instanceof ParameterRef paramRef) {
                                            if (paramRef.getType().equals(RefType.v(cls_old_signature))) {
                                                ParameterRef newParamRef = Jimple.v().newParameterRef(new_cls.getType(), paramRef.getIndex());
                                                box.setValue(newParamRef);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        method_params_need.add(method);
                        method_params.add(params);

                    }
                    if (method.getReturnType().equals(RefType.v(cls_old_signature))) {
                        need_modify_method = true;
                        method_return_need.add(method);
                    }

                    for (Local local : body.getLocals()) {
                        if (local.getType().equals(RefType.v(cls_old_signature))) {
                            local.setType(new_cls.getType());
                        }
                    }

                    for (Unit u : body.getUnits()) {
                        if (u instanceof AssignStmt as) {
                            if (as.getRightOp() instanceof NewExpr ne) {
                                if (ne.getType().equals(RefType.v(cls_old_signature))) {
                                    as.setRightOp(Jimple.v().newNewExpr(new_cls.getType()));
                                }
                            }
                        }
                    }
                    if (need_modify_method) {
                        need_modify_methods_sig.add(ori_sm_sig);
                        need_modify_methods.add(method);
                    }
                }
            }
            for (int i = 0; i < method_params_need.size(); i++) {
                SootMethod smt = method_params_need.get(i);
                smt.setParameterTypes(method_params.get(i));
                if (smt.hasTag("SignatureTag")) {
                    smt.removeTag("SignatureTag");
                }
                smt.setDeclared(true);
            }

            for (SootMethod smt : method_return_need) {
                smt.setReturnType(new_cls.getType());
            }

            for (SootField sf : cls.getFields()) {
                if (sf.getType().equals(RefType.v(cls_old_signature))) {
                    sf.setType(new_cls.getType());
                    SootField sft = sf;
                    for (SootClass cls_t : Scene.v().getApplicationClasses()) {
                        for (SootMethod method_t : cls_t.getMethods()) {
                            if (method_t.isConcrete()) {
                                Body bd = method_t.retrieveActiveBody();
                                for (Unit unit : bd.getUnits()) {
                                    for (ValueBox box : unit.getUseAndDefBoxes()) {
                                        Value value = box.getValue();
                                        if (value instanceof FieldRef fieldRef) {
                                            if (fieldRef.getType().equals(new_cls.getType())) {
                                                if (fieldRef instanceof StaticFieldRef sfr) {
                                                    sfr.setFieldRef(sft.makeRef());
                                                } else if (fieldRef instanceof InstanceFieldRef ifr) {
                                                    ifr.setFieldRef(sft.makeRef());
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }
}
