package tplmod.add;

import soot.*;
import soot.jimple.*;
import soot.util.Chain;

import java.util.Arrays;

public class AddClass {
    public static void process(String cls_fullname, int modifiers){
        //int modifiers = Modifier.PUBLIC;
        SootClass class2Add = new SootClass(cls_fullname, modifiers);
        Scene.v().addClass(class2Add);
        // 设置父类
        class2Add.setSuperclass(Scene.v().getSootClass("java.lang.Object"));
        class2Add.setApplicationClass();
        // 创建构造函数
        SootMethod constructor = new SootMethod("<init>", Arrays.asList(), VoidType.v(), Modifier.PUBLIC);
        class2Add.addMethod(constructor);
        // 创建构造函数的body
        JimpleBody wbody = Jimple.v().newBody(constructor);
        constructor.setActiveBody(wbody);
        // 获取构造函数的参数列表和局部变量列表
        Chain<Local> locals = wbody.getLocals();
        Chain<Unit> units = wbody.getUnits();
        // 创建this引用
        Local thisRef = Jimple.v().newLocal("$this", class2Add.getType());
        locals.add(thisRef);
        units.add(Jimple.v().newIdentityStmt(thisRef, Jimple.v().newThisRef(class2Add.getType())));
        // 调用Object类的构造函数
        SootMethod toCall = Scene.v().getMethod("<java.lang.Object: void <init>()>");
        units.add(Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(thisRef, toCall.makeRef())));
        // 构造函数的返回
        units.add(Jimple.v().newReturnVoidStmt());
    }
}
