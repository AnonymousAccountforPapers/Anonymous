package tplmod.add;

import tplmod.bl.Utils_bl;
import soot.*;
import tplmod.utils.ModUtils;

import java.util.Map;

public class AddField {
    public static void process(String fldSignature, int modifiers){
        Map<String, String> matcher =  ModUtils.parseFieldSignature(fldSignature);
        if (matcher.size() < 3){
            System.out.println("Wrong Signature of field: ");
            System.out.println(fldSignature);
            return;
        }

        String ClsName = matcher.get("className");
        Type fld_type = Scene.v().getType(matcher.get("fieldType"));
        String fld_name = matcher.get("fieldName");

        SootClass sc = Scene.v().loadClassAndSupport(ClsName);
        try{
            String fldSig = matcher.get("fieldSubSignature");
            if (sc.getField(fldSig) != null){
                fld_name = Utils_bl.generateName("fld");
            }
        }catch (Exception ignored){}

        SootField field2Add = new SootField(fld_name, fld_type, modifiers);
        sc.addField(field2Add);
        //System.out.println("Field Signature:"+ field2Add.getSignature());
        //System.out.println("Field SubSignature:"+ field2Add.getSubSignature());
    }
}
