package tplmod.add;

import soot.*;
import soot.jimple.*;
import soot.tagkit.ParamNamesTag;
import soot.tagkit.Tag;
import tplmod.Main;
import tplmod.bl.Utils_bl;
import tplmod.merge.MergeParam;
import tplmod.utils.ModUtils;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class AddParam {
    public static int cnt = Main.cnt;

    public static void process(String mtdSignature, String param_type){
        Map<String, String> matcher = ModUtils.parseMethodSignature(mtdSignature);
        if (matcher.size() < 4){
            System.out.println("Wrong Signature of method: ");
            System.out.println(mtdSignature);
            return;
        }
        String ClsName = matcher.get("className");
        Type retType = Scene.v().getType(matcher.get("returnType"));
        String MtdName = matcher.get("methodName");
        String mtdSubString = matcher.get("methodSubSignature");

        SootClass Cls = Scene.v().loadClassAndSupport(ClsName);
        SootMethod modMethod = Cls.getMethod(mtdSubString);
        JimpleBody body = (JimpleBody) modMethod.retrieveActiveBody();

        SootClass paramClass = null;
        // String转Type
        Type paramType = null;
        // PrimType
        boolean basic_type = true;
        if (param_type.equals("boolean")) {
            paramType = BooleanType.v();
        } else if (param_type.equalsIgnoreCase("byte")) {
            paramType = ByteType.v();
        } else if (param_type.equalsIgnoreCase("char")) {
            paramType = CharType.v();
        } else if (param_type.equalsIgnoreCase("double")) {
            paramType = DoubleType.v();
        } else if (param_type.equalsIgnoreCase("float")) {
            paramType = FloatType.v();
        } else if (param_type.equalsIgnoreCase("int")) {
            paramType = IntType.v();
        } else if (param_type.equals("long")) {
            paramType = LongType.v();
        } else if (param_type.equals("short")) {
            paramType = ShortType.v();
        } else {
            // 获取参数类
            paramClass = Scene.v().loadClassAndSupport(param_type);
            assert paramClass != null;
            paramType = paramClass.getType();
            basic_type = false;
            boolean has_noarg_init = false;
            for (SootMethod sm: paramClass.getMethods()){
                if (sm.getSubSignature().equals("void <init>()")){
                    has_noarg_init = true;
                }
            }
            if (!has_noarg_init){
                AddMethod.process(paramClass.getName() + ": void <init>()", Utils_bl.GetModifier("public"), "");
            }
        }

        // 添加参数
        // System.out.println(modMethod.getParameterTypes().getClass());


        /*
        System.out.println(body.toString());
        Logging.write_logger("getParameterTypes: " + modMethod.getParameterTypes());
        Logging.write_logger("getUseAndDefBoxes: " + body.getUseAndDefBoxes());
        Logging.write_logger("getParameterRefs: " + body.getParameterRefs());
        Logging.write_logger("getParameterLocals: " + body.getParameterLocals());
        Logging.write_logger("getLocals: " + body.getLocals());

         */
        // System.out.println("Add Param Method before: "+modMethod.getSignature());

        List<Type> paramTypeList = new ArrayList<>(modMethod.getParameterTypes());
        paramTypeList.add(paramType);
        modMethod.setParameterTypes(paramTypeList);
        // 添加 ParamTag
        List<String> paramTagNames = null;
        int indx = -1;
        for (Tag t: modMethod.getTags()){
            indx += 1;
            if (t instanceof ParamNamesTag){
                paramTagNames = new ArrayList<>(((ParamNamesTag) t).getNames());
                break;
            }
        }

        if (indx != -1){
            //assert paramTagNames != null;
            if (paramTagNames != null){
                paramTagNames.add("addParam1");
                modMethod.getTags().remove(indx);
                modMethod.getTags().add(indx, new ParamNamesTag(paramTagNames));
            }
        }


        Local local_param_receive = Jimple.v().newLocal("$local_param_receive"+paramTypeList.size()+1, paramType);
        body.getLocals().add(local_param_receive);
        IdentityStmt newIntParamStmt = Jimple.v().newIdentityStmt(local_param_receive, Jimple.v().newParameterRef(paramType, modMethod.getParameterTypes().size()-1));
        body.getUnits().insertBefore(newIntParamStmt, body.getFirstNonIdentityStmt());


        /*// 如果不是基本类型，添加函数调用
        assert paramClass != null;
        if (!basic_type){
            body.getUnits().insertBefore(Jimple.v().newInvokeStmt(
                            Jimple.v().newStaticInvokeExpr(Scene.v().getSootClass(ModUtils.InvokeClass_ClassName).getMethodByName("invoke_object_method").makeRef(), local_param_receive)
                    ),
                    body.getFirstNonIdentityStmt()
            );
        }*/

        // System.out.println("Add Param Method after: "+modMethod.getSignature());

        // Notice TODO 修改调用者的参数传递
        modify_invoke(Cls, mtdSubString, modMethod, paramType, paramClass);


        /*System.out.println(body.toString());
        System.out.println(modMethod.getTags());


        Logging.write_logger("getParameterTypes: " + modMethod.getParameterTypes());
        Logging.write_logger("getUseAndDefBoxes: " + body.getUseAndDefBoxes());
        Logging.write_logger("getParameterRefs: " + body.getParameterRefs());
        Logging.write_logger("getParameterLocals: " + body.getParameterLocals());
        Logging.write_logger("getLocals: " + body.getLocals());*/
        // System.out.println("Add Param Method: "+modMethod.getSignature());
    }

    public static void modify_invoke(SootClass targetClass, String origin_signature, SootMethod modMethod, Type paramType, SootClass paramClass){
        Random random = new Random();
        for (SootClass cls : Scene.v().getApplicationClasses()) {
            CopyOnWriteArrayList<SootMethod> Mtdlist = new CopyOnWriteArrayList<>(cls.getMethods());
            for (SootMethod method : Mtdlist) {
                if (method.isConcrete()) {
                    Body body = method.retrieveActiveBody();
                    List<Unit> invokeUnits = new ArrayList<>();
                    List<AssignStmt> assignsBeforeUnit = new ArrayList<>();
                    List<List<Stmt>> instance_create = new ArrayList<>();
                    for (Unit unit : body.getUnits()) {
                        if (unit instanceof Stmt) {
                            Stmt stmt = (Stmt) unit;
                            if (stmt.containsInvokeExpr()) {
                                InvokeExpr invokeExpr = stmt.getInvokeExpr();
                                /*if (invokeExpr.getMethod().getSubSignature().equals(origin_signature) || invokeExpr.getMethod().getSubSignature().equals(modMethod.getSubSignature()))
                                    System.out.println("invoker: "+invokeExpr.getMethod().getSubSignature());*/
                                if (invokeExpr.getMethod().getSubSignature().equals(origin_signature) && invokeExpr.getMethod().getDeclaringClass().equals(targetClass)) {
                                    // 调用了目标方法
                                    Local local_param_send = Jimple.v().newLocal("$local_param_send" + (body.getLocals().size()+1), paramType);
                                    body.getLocals().add(local_param_send);
                                    invokeUnits.add(unit);

                                    if (paramType == IntType.v()){
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(local_param_send, IntConstant.v(random.nextInt()));
                                        assignsBeforeUnit.add(assignStmt);
                                    }
                                    else if (paramType == BooleanType.v()){
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(local_param_send, IntConstant.v(random.nextInt(0,2)));
                                        assignsBeforeUnit.add(assignStmt);
                                    }
                                    else if (paramType == ByteType.v()){
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(local_param_send, IntConstant.v(random.nextInt(-128,128)));
                                        assignsBeforeUnit.add(assignStmt);
                                    }
                                    else if (paramType == CharType.v()){
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(local_param_send, IntConstant.v(random.nextInt(0,128)));
                                        assignsBeforeUnit.add(assignStmt);
                                    }
                                    else if (paramType == ShortType.v()){
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(local_param_send, IntConstant.v(random.nextInt(0,65536)));
                                        assignsBeforeUnit.add(assignStmt);
                                    }
                                    else if (paramType == LongType.v()){
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(local_param_send, LongConstant.v(random.nextLong()));
                                        assignsBeforeUnit.add(assignStmt);
                                    }
                                    else if (paramType == FloatType.v()){
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(local_param_send, FloatConstant.v(random.nextFloat()));
                                        assignsBeforeUnit.add(assignStmt);
                                    }
                                    else if (paramType == DoubleType.v()){
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(local_param_send, DoubleConstant.v(random.nextDouble()));
                                        assignsBeforeUnit.add(assignStmt);
                                    }
                                    else {
                                        SootMethod noarg_init = null;
                                        for (SootMethod sm: paramClass.getMethods()){
                                            if (sm.getSubSignature().equals("void <init>()")){
                                                noarg_init = sm;
                                                break;
                                            }
                                        }
                                        if (noarg_init == null){
                                            System.out.println("noarg_init is null");
                                            continue;
                                        }
                                        AssignStmt newInstanceStmt = Jimple.v().newAssignStmt(local_param_send, Jimple.v().newNewExpr(RefType.v(paramClass.toString())));
                                        InvokeStmt ivkstmt = Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(local_param_send, noarg_init.makeRef()));
                                        /*body.getUnits().addLast(newInstanceStmt);
                                        body.getUnits().addLast(ivkstmt);*/
                                        instance_create.add(Arrays.asList(newInstanceStmt, ivkstmt));
                                    }

                                    List<Value> newArgs = new ArrayList<>(invokeExpr.getArgs());
                                    newArgs.add(local_param_send);

//                                    InvokeExpr newInvokeExpr = Jimple.v().newStaticInvokeExpr(modMethod.makeRef(), newArgs);
//                                    stmt.getInvokeExprBox().setValue(newInvokeExpr);
                                    InvokeExpr newInvokeExpr = null;
                                    if (invokeExpr instanceof StaticInvokeExpr) {
                                        newInvokeExpr = Jimple.v().newStaticInvokeExpr(modMethod.makeRef(), newArgs);
                                    } else if (invokeExpr instanceof VirtualInvokeExpr vie) {
                                        newInvokeExpr = Jimple.v().newVirtualInvokeExpr((Local)vie.getBase(), modMethod.makeRef(), newArgs);
                                    } else if (invokeExpr instanceof SpecialInvokeExpr sie) {
                                        newInvokeExpr = Jimple.v().newSpecialInvokeExpr((Local)sie.getBase(), modMethod.makeRef(), newArgs);
                                    } else if (invokeExpr instanceof InstanceInvokeExpr iie) {
                                        newInvokeExpr = Jimple.v().newSpecialInvokeExpr((Local)iie.getBase(), modMethod.makeRef(), newArgs);
                                    }
                                    stmt.getInvokeExprBox().setValue(newInvokeExpr);
                                }
                            }
                        }
                    }
                    if (!assignsBeforeUnit.isEmpty()){
                        for (int i = 0; i < invokeUnits.size(); i++){
                            body.getUnits().insertBefore(assignsBeforeUnit.get(i), invokeUnits.get(i));
                        }
                    }
                    if (!instance_create.isEmpty()){
                        for (int i = 0; i < invokeUnits.size(); i++){
                            for (Stmt stmt: instance_create.get(i)){
                                body.getUnits().insertBefore(stmt, invokeUnits.get(i));
                            }
                        }
                    }

                    //body.validate();
                }
            }
        }
    }
}
