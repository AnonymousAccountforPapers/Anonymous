package tplmod.add;

import soot.jimple.*;
import soot.util.Chain;
import tplmod.bl.Utils_bl;
import soot.*;
import tplmod.utils.ModUtils;

import java.lang.module.FindException;
import java.util.*;

import static soot.Modifier.*;

public class AddMethod {
    public static void process(String mtdSignature, int modifiers, String invoked_methodsSignature) {
        Map<String, String> matcher = ModUtils.parseMethodSignature(mtdSignature);
        if (matcher.size() < 4){
            System.out.println("Wrong Signature of method: ");
            System.out.println(mtdSignature);
            return;
        }

        String ClsName = matcher.get("className");
        // System.out.println(matcher.get("returnType"));
        Type retType = Scene.v().getType(matcher.get("returnType"));
        String MtdName = matcher.get("methodName");
        SootClass sc = Scene.v().loadClassAndSupport(ClsName);
        // System.out.println(sc);
        try{
            String mtdSubString = matcher.get("methodSubSignature");
            if (sc.getMethod(mtdSubString) != null) {
                MtdName = Utils_bl.generateName("mtd");
            }
        }catch (Exception ignored){}

        List<Type> params = new ArrayList<>();
        if (matcher.get("parameters") != ""){
            for (String p: matcher.get("parameters").split(",")){
                // System.out.println(p);
                params.add(Scene.v().getType(p));
            }
        }

        SootMethod method2Add = new SootMethod(MtdName, params, retType, modifiers);
        sc.addMethod(method2Add);
        //body: 添加函数调用

        List<SootMethod> invoked_methods = new ArrayList<>();

        /*for (SootMethod tmp_mtd: Scene.v().loadClassAndSupport("android.support.v4.widget.ScrollerCompat$ScrollerCompatImplBase").getMethods()){
            System.out.println(tmp_mtd);
        }*/

        if (invoked_methodsSignature != ""){
            Map<String, String> tmp_matcher = ModUtils.parseMethodSignature(invoked_methodsSignature);
            SootClass tmp_cls = Scene.v().loadClassAndSupport(tmp_matcher.get("className"));
            invoked_methods.add(tmp_cls.getMethod(tmp_matcher.get("methodSubSignature")));
        }


        create_body(method2Add, invoked_methods);

    }



    public static void create_body(SootMethod method2Add, List<SootMethod> invoked_methods){
        // 创建body
        JimpleBody body = Jimple.v().newBody(method2Add);
        method2Add.setActiveBody(body);
        if (method2Add.getName().equals("<init>")){
            Local thisRef = Jimple.v().newLocal("$this", method2Add.getDeclaringClass().getType());
            body.getLocals().add(thisRef);
            body.getUnits().add(Jimple.v().newIdentityStmt(thisRef, Jimple.v().newThisRef( method2Add.getDeclaringClass().getType())));
            SootMethod toCall = Scene.v().getMethod("<java.lang.Object: void <init>()>");
            body.getUnits().add(Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(thisRef, toCall.makeRef())));
            body.getUnits().add(Jimple.v().newReturnVoidStmt());
            int count = 0;
            for (Type param: method2Add.getParameterTypes()){
                Local paramRef = Jimple.v().newLocal("$param"+count, param);
                body.getLocals().add(paramRef);
                body.getUnits().insertBefore(Jimple.v().newIdentityStmt(paramRef, Jimple.v().newParameterRef(param, count)), body.getFirstNonIdentityStmt());
                count ++;
            }
        }
        else {
            int count = 0;
            for (Type param: method2Add.getParameterTypes()){
                Local paramRef = Jimple.v().newLocal("$param"+count, param);
                body.getLocals().add(paramRef);
                body.getUnits().addLast(Jimple.v().newIdentityStmt(paramRef, Jimple.v().newParameterRef(param, count)));
                count ++;
            }
        }


        int param_count = 0;
        int instance_count = 0;
        Random random = new Random();
        for (SootMethod ivkMtd: invoked_methods) {
            //System.out.println("First mtd: "+ivkMtd);
            // 判断是不是静态函数
            boolean static_function = (ivkMtd.getModifiers() & Modifier.STATIC) == 8;
            boolean init_function = ivkMtd.getName().equals("<init>");
            List<Type> paramList = ivkMtd.getParameterTypes();
            // 创建用于传参的局部变量
            List<Local> tmp_locals = new ArrayList<>();
            for (Type param : paramList) {
                Local local = Jimple.v().newLocal("$arg" + param_count, param);
                body.getLocals().add(local);
                tmp_locals.add(local);
                ++param_count;
            }
            // 给每一个参数赋值
            for (Local local: tmp_locals){
                //System.out.println("local type: "+local.getType());
                if (local.getType() == IntType.v()){
                    AssignStmt assignStmt = Jimple.v().newAssignStmt(local, IntConstant.v(random.nextInt()));
                    body.getUnits().addLast(assignStmt);
                }
                else if (local.getType() == BooleanType.v()){
                    AssignStmt assignStmt = Jimple.v().newAssignStmt(local, IntConstant.v(random.nextInt(0,2)));
                    body.getUnits().addLast(assignStmt);
                }
                else if (local.getType() == ByteType.v()){
                    AssignStmt assignStmt = Jimple.v().newAssignStmt(local, IntConstant.v(random.nextInt(-128,128)));
                    body.getUnits().addLast(assignStmt);
                }
                else if (local.getType() == CharType.v()){
                    AssignStmt assignStmt = Jimple.v().newAssignStmt(local, IntConstant.v(random.nextInt(0,128)));
                    body.getUnits().addLast(assignStmt);
                }
                else if (local.getType() == ShortType.v()){
                    AssignStmt assignStmt = Jimple.v().newAssignStmt(local, IntConstant.v(random.nextInt(0,65536)));
                    body.getUnits().addLast(assignStmt);
                }
                else if (local.getType() == LongType.v()){
                    AssignStmt assignStmt = Jimple.v().newAssignStmt(local, LongConstant.v(random.nextLong()));
                    body.getUnits().addLast(assignStmt);
                }
                else if (local.getType() == FloatType.v()){
                    AssignStmt assignStmt = Jimple.v().newAssignStmt(local, FloatConstant.v(random.nextFloat()));
                    body.getUnits().addLast(assignStmt);
                }
                else if (local.getType() == DoubleType.v()){
                    AssignStmt assignStmt = Jimple.v().newAssignStmt(local, DoubleConstant.v(random.nextDouble()));
                    body.getUnits().addLast(assignStmt);
                }
                else if(isInterface(Scene.v().loadClassAndSupport(local.getType().toString()).getModifiers())) {
                    // TODO
                    /*
                    List<SootClass> clsImplItfc = getClassimplementItfc(local.getType().toString());
                    assert !clsImplItfc.isEmpty();

                    SootClass callee_cls = clsImplItfc.get(0);
                    SootMethod callee_mtd = callee_cls.getMethodByName("<init>");
                    AssignStmt createObjectStmt = Jimple.v().newAssignStmt(local, Jimple.v().newNewExpr(RefType.v(callee_cls.getType().toString())));
                    InvokeStmt callConstructorStmt = Jimple.v().newInvokeStmt(
                            Jimple.v().newSpecialInvokeExpr(
                                    local,
                                    callee_mtd.makeRef()
                            )
                    );
                    body.getUnits().addLast(createObjectStmt);
                    body.getUnits().addLast(callConstructorStmt);
                    */
                }
                else if(isAnnotation(Scene.v().loadClassAndSupport(local.getType().toString()).getModifiers())) {
                    // TODO

                }
                else if(isEnum(Scene.v().loadClassAndSupport(local.getType().toString()).getModifiers())) {
                    // TODO
                    SootClass enumClass = Scene.v().getSootClass(local.getType().toString());
                    Chain<SootField> fields = enumClass.getFields();
                    SootField refEnumFld = fields.getFirst();
                    AssignStmt assignStmt = Jimple.v().newAssignStmt(local,
                            Jimple.v().newStaticFieldRef(
                                    Scene.v().makeFieldRef(enumClass, refEnumFld.getName(), refEnumFld.getType(), true)
                            )
                    );
                    body.getUnits().addLast(assignStmt);
                }
                else{
                    /*
                    AssignStmt createObjectStmt = Jimple.v().newAssignStmt(local, Jimple.v().newNewExpr(RefType.v(local.getType().toString())));
                    // TODO: 对象初始化所需参数
                    SootClass callee_cls = Scene.v().getSootClass(local.getType().toString());
                    SootMethod callee_mtd = callee_cls.getMethodByName("<init>");

                    InvokeStmt callConstructorStmt = Jimple.v().newInvokeStmt(
                            Jimple.v().newSpecialInvokeExpr(
                                    local,
                                    callee_mtd.makeRef()
                            )
                    );
                    body.getUnits().addLast(createObjectStmt);
                    body.getUnits().addLast(callConstructorStmt);
                    */
                }
            }

            if (!init_function) {
                // 调用函数
                if (!static_function) {
                    // TODO 创建实例的参数列表：
                    SootClass callee_cls = ivkMtd.getDeclaringClass();
                    // 获取所有init函数
                    List<SootMethod> callee_cls_mtds = callee_cls.getMethods();
                    SootMethod callee_cls_init = null;
                    for (SootMethod mtd : callee_cls_mtds) {
                        if (mtd.getSubSignature().equals("void <init>()")) {
                            callee_cls_init = mtd;
                            break;
                        }
                    }
                    if (callee_cls_init == null){
                        // 创建一个无参构造函数
                        AddMethod.process(callee_cls.getName() + ": void <init>()", Utils_bl.GetModifier("public"), "");
                        for (SootMethod mtd : callee_cls_mtds) {
                            if (mtd.getSubSignature().equals("void <init>()")) {
                                callee_cls_init = mtd;
                                break;
                            }
                        }
                    }
                    //System.out.println(callee_cls_init);
                    // 如果不是静态函数，通过实例调用
                    Local instance = Jimple.v().newLocal("$instance" + instance_count, ivkMtd.getDeclaringClass().getType());
                    AssignStmt createObjectStmt = Jimple.v().newAssignStmt(instance, Jimple.v().newNewExpr(RefType.v(ivkMtd.getDeclaringClass().getType().toString())));

                    InvokeStmt callConstructorStmt = Jimple.v().newInvokeStmt(
                            Jimple.v().newSpecialInvokeExpr(
                                    instance,
                                    callee_cls_init.makeRef()//ivkMtd.getDeclaringClass().getMethodByName("<init>").makeRef()
                            )
                    );
                    body.getUnits().addLast(createObjectStmt);
                    body.getUnits().addLast(callConstructorStmt);
                    instance_count++;

                    InvokeStmt invokeFunc = Jimple.v().newInvokeStmt(Jimple.v().newVirtualInvokeExpr(instance, ivkMtd.makeRef(), tmp_locals));
                    body.getUnits().addLast(invokeFunc);
                } else {
                    // 静态函数直接调用
                    InvokeStmt invokeFunc = Jimple.v().newInvokeStmt(Jimple.v().newStaticInvokeExpr(ivkMtd.makeRef(), tmp_locals));
                    body.getUnits().addLast(invokeFunc);
                }
            } else{
                Local instance = Jimple.v().newLocal("$instance" + instance_count, ivkMtd.getDeclaringClass().getType());
                AssignStmt createObjectStmt = Jimple.v().newAssignStmt(instance, Jimple.v().newNewExpr(RefType.v(ivkMtd.getDeclaringClass().getType().toString())));
                InvokeStmt callConstructorStmt = Jimple.v().newInvokeStmt(
                        Jimple.v().newSpecialInvokeExpr(
                                instance,
                                ivkMtd.makeRef()
                        )
                );
                body.getUnits().addLast(createObjectStmt);
                body.getUnits().addLast(callConstructorStmt);
                instance_count++;

                InvokeStmt invokeFunc = Jimple.v().newInvokeStmt(Jimple.v().newVirtualInvokeExpr(instance, ivkMtd.makeRef(), tmp_locals));
                body.getUnits().addLast(invokeFunc);
            }
        }

        //Unit LastNop = body.getUnits().getLast();
        //body.getUnits().add(LastNop);
        // 创建一个try块
        if (!invoked_methods.isEmpty()){
            Unit beginStmt = body.getUnits().getFirst();
            Unit endStmt = body.getUnits().getLast();
            body.getUnits().add(Jimple.v().newNopStmt());
            Unit handlerStmt = body.getUnits().getLast();
            SootClass exceptionClass = Scene.v().getSootClass("java.lang.Exception");
            Trap handler = Jimple.v().newTrap(exceptionClass, beginStmt, endStmt, handlerStmt);
            body.getTraps().add(handler);
        }


        // 返回类型要匹配retType
        AssignStmt assignStmt = null;
        if (method2Add.getReturnType() != VoidType.v()){
            Local retTmp = Jimple.v().newLocal("$fakeRet", method2Add.getReturnType());
            if (method2Add.getReturnType() == IntType.v()){
                assignStmt = Jimple.v().newAssignStmt(retTmp, IntConstant.v(random.nextInt()));
                body.getUnits().addLast(assignStmt);
            }
            else if (method2Add.getReturnType() == BooleanType.v()){
                assignStmt = Jimple.v().newAssignStmt(retTmp, IntConstant.v(random.nextInt(0,2)));
                body.getUnits().addLast(assignStmt);
            }
            else if (method2Add.getReturnType() == ByteType.v()){
                assignStmt = Jimple.v().newAssignStmt(retTmp, IntConstant.v(random.nextInt(-128,128)));
                body.getUnits().addLast(assignStmt);
            }
            else if (method2Add.getReturnType() == CharType.v()){
                assignStmt = Jimple.v().newAssignStmt(retTmp, IntConstant.v(random.nextInt(0,128)));
                body.getUnits().addLast(assignStmt);
            }
            else if (method2Add.getReturnType() == ShortType.v()){
                assignStmt = Jimple.v().newAssignStmt(retTmp, IntConstant.v(random.nextInt(0,65536)));
                body.getUnits().addLast(assignStmt);
            }
            else if (method2Add.getReturnType() == LongType.v()){
                assignStmt = Jimple.v().newAssignStmt(retTmp, LongConstant.v(random.nextLong()));
                body.getUnits().addLast(assignStmt);
            }
            else if (method2Add.getReturnType() == FloatType.v()){
                assignStmt = Jimple.v().newAssignStmt(retTmp, FloatConstant.v(random.nextFloat()));
                body.getUnits().addLast(assignStmt);
            }
            else if (method2Add.getReturnType() == DoubleType.v()){
                assignStmt = Jimple.v().newAssignStmt(retTmp, DoubleConstant.v(random.nextDouble()));
                body.getUnits().addLast(assignStmt);
            }
            else {
                SootClass target_cls = null;
                for (SootClass sc: Scene.v().getApplicationClasses()){
                    if (sc.getType() == method2Add.getReturnType()){
                        target_cls = sc;
                        break;
                    }
                }
                if (target_cls != null){
                    boolean hash_noargs_init = false;
                    SootMethod noarg_init = null;
                    for (SootMethod mtd: target_cls.getMethods()){
                        if (mtd.getSubSignature().equals("void <init>()")){
                            hash_noargs_init = true;
                            noarg_init = mtd;
                            break;
                        }
                    }
                    if (!hash_noargs_init){
                        // 为该类创建无参构造函数
                        AddMethod.process(target_cls.getName() + ": void <init>()", Utils_bl.GetModifier("public"), "");
                        for (SootMethod mtd: target_cls.getMethods()){
                            if (mtd.getSubSignature().equals("void <init>()")){
                                noarg_init = mtd;
                                break;
                            }
                        }
                    }
                    AssignStmt newInstanceStmt = Jimple.v().newAssignStmt(retTmp, Jimple.v().newNewExpr(RefType.v(method2Add.getReturnType().toString())));
                    InvokeStmt ivkstmt = Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(retTmp, noarg_init.makeRef()));
                    body.getUnits().addLast(newInstanceStmt);
                    body.getUnits().addLast(ivkstmt);
                }
            }

            body.getUnits().addLast(Jimple.v().newReturnStmt(retTmp));
        }
        else{
            body.getUnits().addLast(Jimple.v().newReturnVoidStmt());
        }
    }

    public static List<SootClass> getClassimplementItfc(String itfc_name){
        List<SootClass> ret = new ArrayList<>();
        // 遍历所有的类
        Iterator<SootClass> classIter = Scene.v().getApplicationClasses().snapshotIterator();
        while (classIter.hasNext()) {
            SootClass cls = classIter.next();
            // 检查当前类是否实现了目标接口
            if (implementsInterface(cls, itfc_name)) {
                ret.add(cls);
            }
        }

        return ret;
    }

    // 检查一个类是否实现了特定接口
    private static boolean implementsInterface(SootClass cls, String interfaceName) {
        // 遍历类的所有接口
        for (SootClass iface : cls.getInterfaces()) {
            // 检查接口是否匹配目标接口
            if (iface.getName().equals(interfaceName)) {
                return true;
            }
        }
        // 如果类没有实现目标接口，则继续检查其父类
        if (cls.hasSuperclass()) {
            return implementsInterface(cls.getSuperclass(), interfaceName);
        }
        return false;
    }
}
