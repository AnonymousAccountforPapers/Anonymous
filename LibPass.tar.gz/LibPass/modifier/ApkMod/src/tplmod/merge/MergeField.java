package tplmod.merge;

import soot.*;
import soot.jimple.*;
import soot.tagkit.ConstantValueTag;
import soot.tagkit.Tag;
import soot.util.Chain;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import tplmod.Main;
import tplmod.utils.ModUtils;

public class MergeField {
    public static int cnt = Main.cnt;

    public static void process(String fld1Signature, String fld2Signature, String packing_cls_name) {
        if (Main.DEBUG){
            System.out.println("Arg1: "+fld1Signature);
            System.out.println("Arg2: "+fld2Signature);
        }

        Map<String, String> matcher1 =  ModUtils.parseFieldSignature(fld1Signature);
        Map<String, String> matcher2 =  ModUtils.parseFieldSignature(fld2Signature);
        if (matcher1.size() < 3 || matcher2.size() < 3){
            System.out.println("Wrong Signature of fields: ");
            System.out.println(fld1Signature);
            System.out.println(fld2Signature);
            return;
        }

        String C1N = matcher1.get("className");
        String F1N = matcher1.get("fieldSubSignature");
        String C2N = matcher2.get("className");
        String F2N = matcher2.get("fieldSubSignature");
        SootClass sc1 = Scene.v().loadClassAndSupport(C1N);
        SootField sf1 = sc1.getField(F1N);
        SootClass sc2 = Scene.v().loadClassAndSupport(C2N);
        SootField sf2 = sc2.getField(F2N);

        // 提取常量
        Constant cv1 = null;
        Constant cv2 = null;
        if (!sf1.getTags().isEmpty()) {
            for (Tag tag : sf1.getTags()) {
                if (tag.toString().contains("ConstantValue")) {
                    String s = tag.getName();
                    ConstantValueTag ctag = (ConstantValueTag) sf1.getTag(s);
                    cv1 = ctag.getConstant();
                    break;
                }
            }
        }
        if (!sf2.getTags().isEmpty()) {
            for (Tag tag : sf2.getTags()) {
                if (tag.toString().contains("ConstantValue")) {
                    String s = tag.getName();
                    ConstantValueTag ctag = (ConstantValueTag) sf2.getTag(s);
                    cv2 = ctag.getConstant();
                    break;
                }
            }
        }

        //包装类
        Type sf1_type = sf1.getType();
        Type sf2_type = sf2.getType();
        // String wrapperClassName = sc1.getPackageName() + ".fieldwrapper" + cnt++;
        String wrapperClassName = packing_cls_name;
        SootClass wrapperClass =  new SootClass(wrapperClassName, Modifier.PUBLIC);
        wrapperClass.setSuperclass(Scene.v().getSootClass("java.lang.Object")); // 设置超类为Object
        SootField field1 = new SootField("field1", sf1_type, Modifier.PUBLIC);
        wrapperClass.addField(field1);
        SootField field2 = new SootField("field2", sf2_type, Modifier.PUBLIC);
        wrapperClass.addField(field2);
        SootMethod constructor = new SootMethod("<init>", java.util.Collections.emptyList(), VoidType.v(), Modifier.PUBLIC);
        wrapperClass.addMethod(constructor);
        JimpleBody wbody = Jimple.v().newBody(constructor);
        constructor.setActiveBody(wbody);
        Chain<Local> locals = wbody.getLocals();
        Chain<Unit> units = wbody.getUnits();
        Local thisRef = Jimple.v().newLocal("$this", wrapperClass.getType());
        locals.add(thisRef);
        units.add(Jimple.v().newIdentityStmt(thisRef, Jimple.v().newThisRef(wrapperClass.getType())));
        SootMethod toCall = Scene.v().getMethod("<java.lang.Object: void <init>()>");
        units.add(Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(thisRef, toCall.makeRef())));
        ReturnVoidStmt returnstmt = Jimple.v().newReturnVoidStmt();
        units.add(returnstmt);
        wrapperClass.setApplicationClass();

        // 处理所有使用了字段的地方，同时能解决初始化问题
        modify_ivk(sc1, sf1, wrapperClass, cv1, true);
        modify_ivk(sc2, sf2, wrapperClass, cv2, false);

        // 删原字段
        sc1.removeField(sf1);
        sc2.removeField(sf2);

    }

    public static void modify_ivk(SootClass sc, SootField sf, SootClass wrapperClass, Constant cv, boolean is_first) {
        int modifier = sf.getModifiers();
        SootField newfield = new SootField(sf.getName(), wrapperClass.getType(), modifier);
        sc.addField(newfield);
        if (cv != null) {
            // 有常量的话在clinit中添加赋值，不知道为什么原clinit中不会有相关赋值语句，所以只能自己加

            if (!sc.declaresMethodByName("<clinit>")) {
                SootMethod clinitMethod = new SootMethod("<clinit>", Collections.emptyList(), VoidType.v(), Modifier.STATIC);
                sc.addMethod(clinitMethod);
                JimpleBody body = Jimple.v().newBody(clinitMethod);
                clinitMethod.setActiveBody(body);
                ReturnVoidStmt rvs = Jimple.v().newReturnVoidStmt();
                body.getUnits().add(rvs);
            }
            SootMethod clinitmethod = sc.getMethodByName("<clinit>");
            AssignStmt as = Jimple.v().newAssignStmt(Jimple.v().newStaticFieldRef(newfield.makeRef()), cv);
            Chain<Unit> units = clinitmethod.retrieveActiveBody().getUnits();
            units.insertBefore(as, units.getLast());
        }
        // else {
            // 遍历所有方法，找到使用了原字段的语句并修改
            for (SootClass cls : Scene.v().getApplicationClasses()) {
                for (SootMethod sm : cls.getMethods()) {
                    if (sm.isConcrete()) {
                        Body body = sm.retrieveActiveBody();
                        List<Stmt> needAdds_l = new ArrayList<>();
                        List<Stmt> target_l = new ArrayList<>();
                        List<Stmt> needAdds_r = new ArrayList<>();
                        List<Stmt> target_r = new ArrayList<>();
                        for (Unit unit : body.getUnits()) {
                            if (unit instanceof AssignStmt as) {
                                if (!as.containsFieldRef()) {
                                    continue;
                                }
                                if (!as.getFieldRef().getField().equals(sf)) {
                                    continue;
                                }
                                Local newW = Jimple.v().newLocal("newW" + (body.getLocals().size()+1), wrapperClass.getType());
                                body.getLocals().add(newW);
                                SootFieldRef Wfr = null;
                                if (is_first) {
                                    Wfr = wrapperClass.getFields().getFirst().makeRef();
                                } else {
                                    Wfr = wrapperClass.getFields().getLast().makeRef();
                                }
                                if (as.getLeftOp() instanceof FieldRef fr) {
                                    Value value = as.getRightOp();
                                    AssignStmt newWas = Jimple.v().newAssignStmt(newW, Jimple.v().newNewExpr(wrapperClass.getType()));
                                    InvokeStmt newivk = Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(newW, wrapperClass.getMethodByName("<init>").makeRef()));
                                    AssignStmt newfas = Jimple.v().newAssignStmt(Jimple.v().newInstanceFieldRef(newW, Wfr), value);
                                    fr.setFieldRef(newfield.makeRef());
                                    as.setRightOp(newW);
                                    needAdds_l.add(newWas);
                                    needAdds_l.add(newivk);
                                    needAdds_l.add(newfas);
                                    target_l.add(as);
                                } else if (as.getRightOp() instanceof FieldRef fr) {
                                    Value value = as.getLeftOp();
                                    as.setLeftOp(newW);
                                    fr.setFieldRef(newfield.makeRef());
                                    AssignStmt newfas = Jimple.v().newAssignStmt(value, Jimple.v().newInstanceFieldRef(newW, Wfr));
                                    needAdds_r.add(newfas);
                                    target_r.add(as);
                                }
                            }
                        }
                        if (!target_l.isEmpty()) {
                            for (int i = 0; i < target_l.size(); i++) {
                                Stmt target = target_l.get(i);
                                for (int j = 0; j < 3; j++) {
                                    body.getUnits().insertBefore(needAdds_l.get(i * 3 + j), target);
                                }
                            }
                        }
                        if (!target_r.isEmpty()) {
                            for (int i = 0; i < target_r.size(); i++) {
                                body.getUnits().insertAfter(needAdds_r.get(i), target_r.get(i));
                            }
                        }
                    }
                }
            }
        // }
    }

}
