package tplmod.merge;

import soot.*;
import soot.jimple.*;
import soot.util.Chain;

import java.util.*;
import tplmod.Main;
import tplmod.utils.ModUtils;
import java.util.concurrent.CopyOnWriteArrayList;

public class MergeParam {
    public static int cnt = Main.cnt;

    public static void process(String mtdSignature, int position1, int position2, String packing_cls_name) {
        if (Main.DEBUG){
            System.out.println("Arg1: "+mtdSignature);
            System.out.println("Arg2: "+position1);
            System.out.println("Arg3: "+position2);
        }

        //System.out.println(mtdSignature);
        Map<String, String> matcher = ModUtils.parseMethodSignature(mtdSignature);
        //System.out.println(matcher);
        if (matcher.size() < 4){
            System.out.println("Wrong Signature of method: ");
            System.out.println(mtdSignature);
            return;
        }

        String CN = matcher.get("className");
        String MN = matcher.get("methodSubSignature");
        SootClass sc = Scene.v().loadClassAndSupport(CN);
        SootMethod sm = sc.getMethod(MN);
        JimpleBody body = (JimpleBody) sm.retrieveActiveBody();
        String sm_origin_signature = sm.getSubSignature();
        List<Type> paramTypes = new ArrayList<>(sm.getParameterTypes());

        int position_front = Math.min(position1, position2);
        int position_back = Math.max(position1, position2);
        Type param1 = paramTypes.get(position_front);
        Type param2 = paramTypes.get(position_back);

        // String wrapperClassName = sc.getPackageName() + ".paramwrapper" + cnt++;
        String wrapperClassName = packing_cls_name;
        SootClass wrapperClass =  new SootClass(wrapperClassName, Modifier.PUBLIC);
        wrapperClass.setSuperclass(Scene.v().getSootClass("java.lang.Object")); // 设置超类为Object
        wrapperClass.setApplicationClass();
        SootField field1 = new SootField("param1", param1, Modifier.PUBLIC);
        wrapperClass.addField(field1);
        SootField field2 = new SootField("param2", param2, Modifier.PUBLIC);
        wrapperClass.addField(field2);
        // 创建构造函数
        SootMethod constructor = new SootMethod("<init>", Arrays.asList(), VoidType.v(), Modifier.PUBLIC);
        wrapperClass.addMethod(constructor);
        // 创建构造函数的body
        JimpleBody wbody = Jimple.v().newBody(constructor);
        constructor.setActiveBody(wbody);
        // 获取构造函数的参数列表和局部变量列表
        Chain<Local> locals = wbody.getLocals();
        Chain<Unit> units = wbody.getUnits();
        // 创建this引用
        Local thisRef = Jimple.v().newLocal("$this", wrapperClass.getType());
        locals.add(thisRef);
        units.add(Jimple.v().newIdentityStmt(thisRef, Jimple.v().newThisRef(wrapperClass.getType())));
        // 调用Object类的构造函数
        SootMethod toCall = Scene.v().getMethod("<java.lang.Object: void <init>()>");
        units.add(Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(thisRef, toCall.makeRef())));
        // 构造函数的返回
        units.add(Jimple.v().newReturnVoidStmt());

        int new_modifiers_c = Modifier.PUBLIC;
        if ((sc.getModifiers() & Modifier.STRICTFP) != 0) {
            new_modifiers_c = new_modifiers_c | Modifier.STRICTFP;
        }
        sc.setModifiers(new_modifiers_c);

        int new_modifier = Modifier.PUBLIC;
        if ((sm.getModifiers() & Modifier.STATIC) != 0) {
            new_modifier = new_modifier | Modifier.STATIC;
        }
        if ((sm.getModifiers() & Modifier.SYNCHRONIZED) != 0) {
            new_modifier = new_modifier | Modifier.SYNCHRONIZED;
        }
        // 不确定ENUM影响
        if ((sm.getModifiers() & Modifier.ENUM) != 0) {
            new_modifier = new_modifier | Modifier.ENUM;
        }
        if ((sm.getModifiers() & Modifier.STRICTFP) != 0) {
            new_modifier = new_modifier | Modifier.STRICTFP;
        }
        sm.setModifiers(new_modifier);

        paramTypes.remove(position_back);
        paramTypes.remove(position_front);
        paramTypes.add(position_front, wrapperClass.getType());
        sm.setParameterTypes(paramTypes);

        Local paramwrapperLocal = Jimple.v().newLocal("$paramwrapper"+(body.getLocals().size()+1), wrapperClass.getType());
        body.getLocals().add(paramwrapperLocal);
        IdentityStmt newIntParamStmt = Jimple.v().newIdentityStmt(paramwrapperLocal, Jimple.v().newParameterRef(wrapperClass.getType(), position_front));
        body.getUnits().insertBefore(newIntParamStmt, body.getFirstNonIdentityStmt());



        Local origin1 = null;
        Local origin2 = null;
        Unit identity1 = null;
        Unit identity2 = null;
        for (Unit unit : body.getUnits()) {
            if (unit.equals(newIntParamStmt)) {
                continue;
            }
            if (unit instanceof IdentityStmt) {
                IdentityStmt stmt = (IdentityStmt) unit;
                Value rightOp = stmt.getRightOp();
                if (rightOp instanceof ParameterRef) {
                    if (((ParameterRef) rightOp).getIndex() == position_front) {
                        origin1 = (Local) stmt.getLeftOp();
                        identity1 = unit;
                    } else if (((ParameterRef) rightOp).getIndex() == position_back) {
                        origin2 = (Local) stmt.getLeftOp();
                        identity2 = unit;
                        break;
                    }
                }
            }
        }

/*        System.out.println("ParameterRef Before");
        for (Unit unit : body.getUnits()){
            if (unit instanceof IdentityStmt){
                IdentityStmt stmt = (IdentityStmt) unit;
                if (stmt.getRightOp() instanceof ParameterRef) {
                    System.out.println(stmt);
                }
            }
        }*/
        
        // Notice: 然后要把原来的参数IdentityStmt删除，否则会产生参数引用冲突，删除后右值的下标得做相应变化
        body.getUnits().remove(identity1);
        body.getUnits().remove(identity2);
        AssignStmt assign1 = Jimple.v().newAssignStmt(origin1, Jimple.v().newInstanceFieldRef(paramwrapperLocal, field1.makeRef()));
        body.getUnits().insertBefore(assign1, body.getFirstNonIdentityStmt());
        AssignStmt assign2 = Jimple.v().newAssignStmt(origin2, Jimple.v().newInstanceFieldRef(paramwrapperLocal, field2.makeRef()));
        body.getUnits().insertBefore(assign2, body.getFirstNonIdentityStmt());

        for (Unit unit : body.getUnits()) {
            for (ValueBox box : unit.getUseAndDefBoxes()) {
                Value value = box.getValue();
                if (value instanceof ParameterRef) {
                    ParameterRef paramRef = (ParameterRef) value;

                    if (paramRef.getIndex() > position_back) {
                        ParameterRef newParamRef = Jimple.v().newParameterRef(paramRef.getType(), paramRef.getIndex() - 1);
                        box.setValue(newParamRef);
                    }
                }
            }
        }

        // 删了再添加，以更新SootClass中未能动态更新的方法信息
        sc.removeMethod(sm);
        sc.addMethod(sm);

        modify_invoke(sc, sm_origin_signature, wrapperClass, position_front, position_back, sm);

        
//        System.out.println(body);
//        System.out.println("getParameterTypes: " + sm.getParameterTypes());
//        System.out.println("getUseAndDefBoxes: " + body.getUseAndDefBoxes());
//        System.out.println("getParameterRefs: " + body.getParameterRefs());
//        System.out.println("getParameterLocals: " + body.getParameterLocals());
//        System.out.println("getLocals: " + body.getLocals());
    }

    public static void modify_invoke(SootClass targetClass, String origin_signature, SootClass wrapperclass, int p1, int p2, SootMethod sm){
        for (SootClass cls : Scene.v().getApplicationClasses()) {
            CopyOnWriteArrayList<SootMethod> list = new CopyOnWriteArrayList<>(cls.getMethods());
            for (SootMethod method : list) {
                if (method.isConcrete()) {
                    Body body = method.retrieveActiveBody();

                    List<AssignStmt> newInstanceStmts = new ArrayList<>();
                    List<InvokeStmt> newSpecialIvkStmts = new ArrayList<>();
                    List<AssignStmt> fieldAssignStmt1s = new ArrayList<>();
                    List<AssignStmt> fieldAssignStmt2s = new ArrayList<>();
                    List<Unit> invokeUnits = new ArrayList<>();
                    for (Unit unit : body.getUnits()) {
                        if (unit instanceof Stmt) {
                            Stmt stmt = (Stmt) unit;
                            if (stmt.containsInvokeExpr()) {
                                InvokeExpr invokeExpr = stmt.getInvokeExpr();
                                if (invokeExpr.getMethod().getSubSignature().equals(origin_signature) && invokeExpr.getMethod().getDeclaringClass().equals(targetClass)) {
                                    Local paramwrapper = Jimple.v().newLocal("$paramwrapper" + (body.getLocals().size()+1), wrapperclass.getType());
                                    body.getLocals().add(paramwrapper);
                                    List<Value> newArgs = new ArrayList<>();
                                    invokeUnits.add(unit);
                                    newInstanceStmts.add(Jimple.v().newAssignStmt(paramwrapper, Jimple.v().newNewExpr(wrapperclass.getType())));
                                    newSpecialIvkStmts.add(Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(paramwrapper, wrapperclass.getMethodByName("<init>").makeRef())));
                                    fieldAssignStmt1s.add(Jimple.v().newAssignStmt(Jimple.v().newInstanceFieldRef(paramwrapper, wrapperclass.getFields().getFirst().makeRef()), invokeExpr.getArgs().get(p1)));
                                    fieldAssignStmt2s.add(Jimple.v().newAssignStmt(Jimple.v().newInstanceFieldRef(paramwrapper, wrapperclass.getFields().getLast().makeRef()), invokeExpr.getArgs().get(p2)));
                                    for (int i = 0; i < invokeExpr.getArgCount(); i++) {
                                        if (i == p1) {
                                            newArgs.add(paramwrapper);
                                        }
                                        else if (i == p2) {
                                            continue;
                                        }
                                        else {
                                            newArgs.add(invokeExpr.getArg(i));
                                        }
                                    }
//                                    InvokeExpr newInvokeExpr = Jimple.v().newStaticInvokeExpr(sm.makeRef(), newArgs);
//                                    stmt.getInvokeExprBox().setValue(newInvokeExpr);
                                    InvokeExpr newInvokeExpr = null;
                                    if (invokeExpr instanceof StaticInvokeExpr) {
                                        newInvokeExpr = Jimple.v().newStaticInvokeExpr(sm.makeRef(), newArgs);
                                    } else if (invokeExpr instanceof VirtualInvokeExpr vie) {
                                        newInvokeExpr = Jimple.v().newVirtualInvokeExpr((Local)vie.getBase(), sm.makeRef(), newArgs);
                                    } else if (invokeExpr instanceof SpecialInvokeExpr sie) {
                                        newInvokeExpr = Jimple.v().newSpecialInvokeExpr((Local)sie.getBase(), sm.makeRef(), newArgs);
                                    } else if (invokeExpr instanceof InstanceInvokeExpr iie) {
                                        newInvokeExpr = Jimple.v().newSpecialInvokeExpr((Local)iie.getBase(), sm.makeRef(), newArgs);
                                    }
                                    stmt.getInvokeExprBox().setValue(newInvokeExpr);
                                }
                            }
                        }
                    }
                    for (int i = 0; i < invokeUnits.size(); i++) {
                        body.getUnits().insertBefore(newInstanceStmts.get(i), invokeUnits.get(i));
                        body.getUnits().insertBefore(newSpecialIvkStmts.get(i), invokeUnits.get(i));
                        body.getUnits().insertBefore(fieldAssignStmt1s.get(i), invokeUnits.get(i));
                        body.getUnits().insertBefore( fieldAssignStmt2s.get(i), invokeUnits.get(i));
                    }
                }
            }
        }
    }
}
