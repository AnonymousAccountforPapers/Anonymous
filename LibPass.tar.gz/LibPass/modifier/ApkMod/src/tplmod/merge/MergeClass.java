package tplmod.merge;

import soot.*;
import soot.jimple.*;
import soot.tagkit.ConstantValueTag;
import soot.tagkit.Tag;
import soot.util.Chain;
import soot.util.NumberedString;
import tplmod.Main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class MergeClass {
    /*
    类一合并到类二
    遍历类一方法、改名、添加local、代码块。（init/clinit需要合并）
    遍历类一字段、改名、添加。
    处理所有使用了类一的语句（参数、返回、local、字段、调用）
    删类一

    inner/outer class未处理
     */

    public static void process(String Class1Name, String Class2Name) {
        if (Main.DEBUG){
            System.out.println("Arg1: "+Class1Name);
            System.out.println("Arg2: "+Class2Name);
        }

        SootClass sc1 = null;
        for (SootClass sct : Scene.v().getApplicationClasses()) {
            if (sct.getName().equals(Class1Name)) {
                sc1 = sct;
                break;
            }
        }
        SootClass sc2 = null;
        for (SootClass sct : Scene.v().getApplicationClasses()) {
            if (sct.getName().equals(Class2Name)) {
                sc2 = sct;
                break;
            }
        }
        if (sc1 == null || sc2 == null) {
            System.out.print("no class");
            return;
        }
        SootClass sc1super = sc1.getSuperclass();
        SootClass sc2super = sc2.getSuperclass();
        //判断两个类的父类情况
        int super_type = 0;
        if (!sc1super.getName().equals(sc2super.getName())) {
            if (sc1super.getName().equals("java.lang.Object")) {
                super_type = 2;
            }
            else if (sc2super.getName().equals("java.lang.Object")) {
                super_type = 1;
            }
            else {//两个父类不一样，无法处理
                System.out.println("extend different superclass!");
                return;
            }
        }


        sc2.setModifiers(Modifier.PUBLIC);

        // 类1的接口加到类二
        for (SootClass itf : sc1.getInterfaces()) {
            if (!sc2.getInterfaces().contains(itf)) {
                sc2.addInterface(itf);
            }
        }

        List<String> class2MethodNames = new ArrayList<>();
        for (SootMethod method : sc2.getMethods()) {
            class2MethodNames.add(method.getSubSignature().split(" ")[1]);
        }

        SootClass super_c = sc1.getSuperclass();
        if (super_type == 1) {
            // 采用类一的父类
            sc2.setSuperclass(super_c);
        }


        // 遍历类1的方法，复制到类2中
        for (SootMethod method : sc1.getMethods()) {
            Body b1 = method.retrieveActiveBody();
            String methodName = method.getName();
            String origin_method_signature = method.getSignature();
            // 特殊处理构造函数
            if (methodName.equals("<init>")) {
                if (class2MethodNames.contains(method.getSubSignature().split(" ")[1])) {
                    // 如果两个类有相同的init函数，要合并
                    SootMethod method2 = sc2.getMethod(method.getSubSignature());
                    Body b2 = method2.retrieveActiveBody();
                    String sc2_s_name = sc2.getSuperclass().getName();

                    // 在类一的方法上直接处理重命问题
                    List<String> local2 = new ArrayList<>();
                    for (Local local : b2.getLocals()){
                        local2.add(local.getName());
                    }
                    int param_cnt = 0;
                    for (Local local : b1.getLocals()) {
                        param_cnt += 1;
                        // 跳过最前面几个：r0、各参数对应local
                        if (param_cnt <= method2.getParameterCount() + 1) {
                            continue;
                        }
                        String originalName = local.getName();
                        String newName = originalName;
                        int counter = 0;
                        // 重命名
                        while (local2.contains(newName)) {
                            newName = originalName + counter++;
                        }
                        // 改名后将此方法中所有相关local修改
                        for (Unit unit : b1.getUnits()) {
                            for (ValueBox box : unit.getUseAndDefBoxes()) {
                                Value value = box.getValue();
                                if (value instanceof Local && ((Local) value).getName().equals(originalName)) {
                                    box.setValue(Jimple.v().newLocal(newName, local.getType()));
                                }
                            }
                        }
                    }

                    // 将类一方法中参数对应local换成类二方法中的
                    for (int i = 0; i < method2.getParameterCount(); i++) {
                        String oldlocalname = b1.getParameterLocal(i).getName();
                        for (Unit unit : b1.getUnits()) {
                            for (ValueBox box : unit.getUseAndDefBoxes()) {
                                Value value = box.getValue();
                                if (value instanceof Local local) {
                                    if (local.getName().equals(oldlocalname)) {
                                        box.setValue(b2.getParameterLocals().get(i));
                                    }
                                }
                            }
                        }
                    }
                    Local sc2_r0 = null;
                    Unit sc2_s = null;

                    // 找到类二init方法中r0和父类初始化init函数语句位置
                    for (Unit u : b2.getUnits()) {
                        if (u instanceof IdentityStmt is) {
                            if (is.getRightOp() instanceof ThisRef) {
                                sc2_r0 = (Local) is.getLeftOp();
                            }
                        }
                        if (u instanceof InvokeStmt is) {
                            InvokeExpr invokeExpr = is.getInvokeExpr();
                            if (invokeExpr instanceof SpecialInvokeExpr && invokeExpr.getMethod().getName().equals("<init>")) {
                                if (invokeExpr.getMethod().getDeclaringClass().getName().equals(sc2_s_name)) {
                                    sc2_s = u;
                                }
                            }
                        }
                        if (sc2_s != null && sc2_r0 != null) {
                            break;
                        }
                    }

                    // 将类一方法中r0相关改为类二方法的
                    for (Unit unit : b1.getUnits()) {
                        for (ValueBox box : unit.getUseAndDefBoxes()) {
                            Value value = box.getValue();
                            if (value instanceof Local local) {
                                if (local.getName().equals("r0")) {
                                    box.setValue(sc2_r0);
                                }
                            }
                        }
                    }

                    SpecialInvokeExpr specialInvokeExpr;
                    // 开始合并语句和local
                    for (Unit u : b1.getUnits()) {
                        Boolean ivk = false;
                        if (u instanceof IdentityStmt) {
                            // 跳过identity，用类二的即可
                            continue;
                        }
                        if (super_type == 1 && sc2_s != null) {
                            // 新父类，需要修改父类初始化函数
                            if (u instanceof InvokeStmt is) {
                                InvokeExpr invokeExpr = is.getInvokeExpr();
                                if (invokeExpr instanceof SpecialInvokeExpr && invokeExpr.getMethod().getName().equals("<init>")) {
                                    if (invokeExpr.getMethod().getDeclaringClass().getName().equals(sc1.getSuperclass().getName())) {
                                        SootMethod constructor = super_c.getMethod(invokeExpr.getMethod().getSubSignature());
                                        specialInvokeExpr = Jimple.v().newSpecialInvokeExpr(sc2_r0, constructor.makeRef(), invokeExpr.getArgs());

                                        Stmt stmt = (Stmt) sc2_s;
                                        stmt.getInvokeExprBox().setValue(specialInvokeExpr);
                                        ivk = true;
                                    }
                                }
                            }
                        }
                        if (u instanceof ReturnStmt || u instanceof ReturnVoidStmt) {
                            continue;
                        }
                        for (ValueBox box : u.getUseAndDefBoxes()) {
                            // 将此语句中所有相关locals加入到类二方法中
                            Value value = box.getValue();
                            if (value instanceof Local local) {
                                if (!local2.contains(local.getName())) {
                                    b2.getLocals().add(local);
                                    local2.add(local.getName());
                                }
                            }
                        }
                        if (!ivk) {
                            // 添加新语句
                            b2.getUnits().insertBefore(u, b2.getUnits().getLast());
                        }
                    }
                    // 同步修改所有调用了类一方法的地方
                    modify_m(sc1, origin_method_signature, method2);
                    continue;
                }
            }

            if (methodName.equals("<clinit>")) {
                // clinit没有参数，处理下重名问题直接合并即可
                if (class2MethodNames.contains(method.getSubSignature().split(" ")[1])) {
                    SootMethod method2 = sc2.getMethod(method.getSubSignature());
                    Body b2 = method2.retrieveActiveBody();

                    List<String> local2 = new ArrayList<>();
                    for (Local local : b2.getLocals()){
                        local2.add(local.getName());
                    }
                    for (Local local : b1.getLocals()) {
                        String originalName = local.getName();
                        String newName = originalName;
                        int counter = 0;
                        while (local2.contains(newName)) {
                            newName = originalName + counter++;
                        }
                        for (Unit unit : b1.getUnits()) {
                            for (ValueBox box : unit.getUseAndDefBoxes()) {
                                Value value = box.getValue();
                                if (value instanceof Local && ((Local) value).getName().equals(originalName)) {
                                    box.setValue(Jimple.v().newLocal(newName, local.getType()));
                                }
                            }
                        }
                    }

                    b2.getLocals().addAll(b1.getLocals());
                    b2.getUnits().insertBefore(b1.getUnits(), b2.getUnits().getLast());
                    b2.getUnits().remove(b2.getUnits().getLast());
                    continue;
                }
            }
            else {
                methodName = method.getName();
                // 对于非构造函数/类二中没有的构造函数：重名、加入类二
                while (class2MethodNames.contains(methodName+"("+method.getSubSignature().split("\\(")[1])) {
                    methodName += "_new";
                    //method.setName(method.getName()+"_new");
                }
            }

            // 将函数中的r0改为类二的
//            System.out.println(1);
            for (Unit u : b1.getUnits()) {
                if (u instanceof IdentityStmt is) {
                    if (is.getRightOp() instanceof ThisRef) {
                        Local old_local = (Local) is.getLeftOp();

                        Local newr0 = Jimple.v().newLocal("r0", sc2.getType());

                        b1.getLocals().insertBefore(newr0, b1.getLocals().getFirst());
                        b1.getLocals().remove(old_local);

                        for (ValueBox box : b1.getUseAndDefBoxes()) {
                            Value value = box.getValue();
                            if (value instanceof Local && ((Local) value).equals(old_local)) {
                                box.setValue(newr0);
                            }
                        }

                        IdentityStmt newStmt = Jimple.v().newIdentityStmt(newr0, Jimple.v().newThisRef(sc2.getType()));
                        b1.getUnits().insertBefore(newStmt, u);
                        b1.getUnits().remove(u);

                        break;
                    }
                }
            }
//            System.out.println(1);

            // 复制方法到类2
            int new_modifier = method.getModifiers();
            SootMethod newMethod = new SootMethod(methodName, method.getParameterTypes(), method.getReturnType(), new_modifier, method.getExceptions());
            sc2.addMethod(newMethod);
            if (method.hasActiveBody()) {
//                Body body = (Body) method.retrieveActiveBody().clone();
                newMethod.setActiveBody(b1);
                b1.setMethod(newMethod);
            }


            modify_m(sc1, origin_method_signature, newMethod);

//            System.out.println(1);
        }
//        System.out.println(2);

        // 合并字段
        List<String> class2FieldNames = new ArrayList<>();
        for (SootField field : sc2.getFields()) {
            // class2FieldNames.add(field.getType().toString() + "  " + field.getName());
            class2FieldNames.add(field.getName());
        }

        for (SootField field : sc1.getFields()) {
            // String fieldName = field.getType().toString() + "  " + field.getName();
            String fieldName = field.getName();
            // 重命名
            while (class2FieldNames.contains(fieldName)) {
                fieldName += "_new";
            }
            SootField newField = new SootField(fieldName, field.getType(), field.getModifiers());
            sc2.addField(newField);

            // 字段初始化
            Constant cv = null;
            // 如果是值是常量，要提取值并加入到clinit中
            if (!field.getTags().isEmpty()) {
                for (Tag tag : field.getTags()) {
                    if (tag.toString().contains("ConstantValue")) {
                        String s = tag.getName();
                        ConstantValueTag ctag = (ConstantValueTag) field.getTag(s);
                        cv = ctag.getConstant();
                        break;
                    }
                }
            }
            if (cv != null) {
                if (sc2.getMethodByNameUnsafe("<clinit>") == null) {
                    SootMethod clinitMethod = new SootMethod("<clinit>", Collections.emptyList(), VoidType.v(), Modifier.STATIC);
                    sc2.addMethod(clinitMethod);
                    JimpleBody body = Jimple.v().newBody(clinitMethod);
                    clinitMethod.setActiveBody(body);
                    ReturnVoidStmt rvs = Jimple.v().newReturnVoidStmt();
                    body.getUnits().add(rvs);
                }
                SootMethod clinitmethod = sc2.getMethodByName("<clinit>");
                AssignStmt as = Jimple.v().newAssignStmt(Jimple.v().newStaticFieldRef(newField.makeRef()), cv);
                Chain<Unit> units = clinitmethod.retrieveActiveBody().getUnits();
                units.insertBefore(as, units.getLast());
            }

            // invoke
            // 同步修改所有调用了类一字段的地方
            modify_f(field, newField, sc1);
        }


        // 修改子类
        modify_subclass(sc2, sc1);

        if (super_type == 1) {
            // 类二新加类一的父类后，通过类一实例引用其父类方法/字段的地方要更新
            modify_superivk(sc2, sc1);
        }

        modify_innerc(sc2, sc1);
        // 同步修改所有参数、返回、local是类一类型的地方   修改字段是类一类型

        modify_l(sc2, sc1);

        // 删除类一
        sc1.setResolvingLevel(SootClass.HIERARCHY);
        Scene.v().removeClass(sc1);

    }

    public static void modify_m(SootClass sc1, String sm1_sig, SootMethod sm2) {
        for (SootClass cls : new ArrayList<>(Scene.v().getApplicationClasses())) {
            if (cls.equals(sc1)) {

                continue;
            }
            for (SootMethod method : new ArrayList<>(cls.getMethods())) {
                if (method.isConcrete()) {
                    Body body = method.retrieveActiveBody();
                    for (Unit u : body.getUnits()) {
                        if (u instanceof Stmt stmt) {
                            if (stmt.containsInvokeExpr()) {
                                InvokeExpr invokeExpr = stmt.getInvokeExpr();
                                if (invokeExpr.getMethod().getSignature().equals(sm1_sig)) {



                                    invokeExpr.setMethodRef(sm2.makeRef());
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public static void modify_subclass(SootClass sc2, SootClass sc1) {
        for (SootClass cls : new ArrayList<>(Scene.v().getApplicationClasses())) {
            if (cls.equals(sc1) || cls.equals(sc2)) {
                continue;
            }
            if (cls.hasSuperclass() && cls.getSuperclass().equals(sc1)) {
                cls.setSuperclass(sc2);
            }
        }
    }

    public static void modify_superivk(SootClass sc2, SootClass sc1) {
        for (SootClass cls : new ArrayList<>(Scene.v().getApplicationClasses())) {
            for (SootMethod method : new ArrayList<>(cls.getMethods())) {
                if (method.isConcrete()) {
                    Body body = method.retrieveActiveBody();
                    for (Unit u : body.getUnits()) {
                        if (u instanceof Stmt stmt) {
                            if (stmt.containsInvokeExpr()) {
                                InvokeExpr invokeExpr = stmt.getInvokeExpr();
                                SootMethodRef smf = invokeExpr.getMethodRef();
                                if (smf.getDeclaringClass().getName().equals(sc1.getName())) {
                                    String name = smf.getName();
                                    List<Type> pts = smf.getParameterTypes();
                                    Type rt = smf.getReturnType();
                                    SootMethod smr = invokeExpr.getMethod();
                                    Boolean iss = smf.isStatic();
                                    String signature = smf.getSignature();
                                    String st = signature.split(": ")[0];
                                    st = st.replace(sc1.getName(), sc2.getName());
                                    signature = st + ": " + signature.split(": ")[1];
                                    String finalSignature = signature;
                                    invokeExpr.setMethodRef(new SootMethodRef() {
                                        @Override
                                        public SootClass declaringClass() {
                                            return sc2;
                                        }

                                        @Override
                                        public String name() {
                                            return name;
                                        }

                                        @Override
                                        public List<Type> parameterTypes() {
                                            return pts;
                                        }

                                        @Override
                                        public Type returnType() {
                                            return rt;
                                        }

                                        @Override
                                        public Type parameterType(int i) {
                                            return parameterTypes().get(i);
                                        }

                                        @Override
                                        public NumberedString getSubSignature() {
                                            return null;
                                        }

                                        @Override
                                        public SootMethod resolve() {
                                            return smr;
                                        }

                                        @Override
                                        public SootMethod tryResolve() {
                                            return null;
                                        }

                                        @Override
                                        public SootClass getDeclaringClass() {
                                            return declaringClass();
                                        }

                                        @Override
                                        public String getName() {
                                            return name;
                                        }

                                        @Override
                                        public List<Type> getParameterTypes() {
                                            return pts;
                                        }

                                        @Override
                                        public Type getParameterType(int i) {
                                            return parameterType(i);
                                        }

                                        @Override
                                        public Type getReturnType() {
                                            return returnType();
                                        }

                                        @Override
                                        public boolean isStatic() {
                                            return iss;
                                        }

                                        @Override
                                        public String getSignature() {
                                            return finalSignature;
                                        }
                                    });
                                }
                            }
                            if (stmt.containsFieldRef()) {
                                FieldRef fr = stmt.getFieldRef();
                                if (fr.getFieldRef().declaringClass().getName().equals(sc1.getName())) {
                                    String name = fr.getFieldRef().name();
                                    Boolean iss = fr.getFieldRef().isStatic();
                                    String sig = fr.getFieldRef().getSignature();
                                    String st = sig.split(": ")[0];
                                    Type tp = fr.getType();
                                    st = st.replace(sc1.getName(), sc2.getName());
                                    sig = st + ": " + sig.split(": ")[1];
                                    String finalSig = sig;
                                    SootField rv = Scene.v().getField(fr.getField().getSignature());
                                    fr.setFieldRef(new SootFieldRef() {
                                        @Override
                                        public SootClass declaringClass() {
                                            return sc2;
                                        }

                                        @Override
                                        public String name() {
                                            return name;
                                        }

                                        @Override
                                        public Type type() {
                                            return tp;
                                        }

                                        @Override
                                        public boolean isStatic() {
                                            return iss;
                                        }

                                        @Override
                                        public String getSignature() {
                                            return finalSig;
                                        }

                                        @Override
                                        public SootField resolve() {
                                            return rv;
                                        }
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
    }


    public static void modify_l (SootClass sc2, SootClass sc1){
        for (SootClass cls : new ArrayList<>(Scene.v().getApplicationClasses())) {
            if (cls.equals(sc1)) {
                continue;
            }
            List<SootMethod> method_params_need = new ArrayList<>();
            List<List<Type>> method_params = new ArrayList<>();
            List<SootMethod> method_return_need = new ArrayList<>();
            List<SootMethod> need_modify_methods = new ArrayList<>();
            List<String> need_modify_methods_sig = new ArrayList<>();
            for (SootMethod method : new ArrayList<>(cls.getMethods())) {
                boolean need_modify_method = false;
                String ori_sm_sig = method.getSignature();
                if (method.isConcrete()) {
                    Body body = method.retrieveActiveBody();
                    if (method.getParameterTypes().contains(sc1.getType())) {
                        need_modify_method = true;
                        List<Type> params = new ArrayList<>(method.getParameterTypes());

                        for (int i = 0; i < method.getParameterCount(); i++) {
                            if (params.get(i).equals(sc1.getType())) {
//                                method.getParameterTypes().set(i, sc2.getType());
                                params.set(i, sc2.getType());
                                for (Unit unit : body.getUnits()) {
                                    for (ValueBox box : unit.getUseAndDefBoxes()) {
                                        Value value = box.getValue();
                                        if (value instanceof ParameterRef paramRef) {
                                            if (paramRef.getType().equals(sc1.getType())) {
                                                ParameterRef newParamRef = Jimple.v().newParameterRef(sc2.getType(), paramRef.getIndex());
                                                box.setValue(newParamRef);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        method_params_need.add(method);
                        method_params.add(params);

                    }
                    if (method.getReturnType().equals(sc1.getType())) {
                        need_modify_method = true;
                        method_return_need.add(method);
                    }

                    for (Local local : body.getLocals()) {
                        if (local.getType().equals(sc1.getType())) {

                            local.setType(sc2.getType());
                        }
                    }

                    for (Unit u : body.getUnits()) {
                        if (u instanceof AssignStmt as) {
                            if (as.getRightOp() instanceof NewExpr ne) {
                                if (ne.getType().equals(sc1.getType())) {

                                    as.setRightOp(Jimple.v().newNewExpr(sc2.getType()));
                                }
                            }
                        }
                    }
                    if (need_modify_method) {
                        need_modify_methods_sig.add(ori_sm_sig);
                        need_modify_methods.add(method);
                    }
                }
            }
            for (int i = 0; i < method_params_need.size(); i++) {
                SootMethod smt = method_params_need.get(i);
                smt.setParameterTypes(method_params.get(i));
                if (smt.hasTag("SignatureTag")) {
                    smt.removeTag("SignatureTag");
                }
                smt.setDeclared(true);
            }

            for (SootMethod smt : method_return_need) {
                smt.setReturnType(sc2.getType());
            }
            for (int i = 0; i < need_modify_methods.size(); i++) {
                modify_m(null, need_modify_methods_sig.get(i), need_modify_methods.get(i));
            }
            for (SootField sf : cls.getFields()) {
                if (sf.getType().equals(sc1.getType())) {
                    sf.setType(sc2.getType());
                    SootField sft = sf;
                    for (SootClass cls_t : Scene.v().getApplicationClasses()) {
                        for (SootMethod method_t : cls_t.getMethods()) {
                            if (method_t.isConcrete()) {
                                Body bd = method_t.retrieveActiveBody();
                                for (Unit unit : bd.getUnits()) {
                                    for (ValueBox box : unit.getUseAndDefBoxes()) {
                                        Value value = box.getValue();
                                        if (value instanceof FieldRef fieldRef) {
                                            if (fieldRef.getType().equals(sc1.getType())) {
                                                if (fieldRef instanceof StaticFieldRef sfr) {
                                                    sfr.setFieldRef(sft.makeRef());
                                                } else if (fieldRef instanceof InstanceFieldRef ifr) {
                                                    ifr.setFieldRef(sft.makeRef());
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public static void modify_f(SootField sf, SootField sf_new, SootClass sc){
        for (SootClass cls : new ArrayList<>(Scene.v().getApplicationClasses())) {
            if (cls.equals(sc)) {
                continue;
            }
            for (SootMethod method : new ArrayList<>(cls.getMethods())) {
                if (method.isConcrete()) {
                    Body body = method.retrieveActiveBody();
                    for (Unit unit : body.getUnits()) {
                        if (unit instanceof AssignStmt as) {
                            if (as.containsFieldRef()) {
                                FieldRef fr = as.getFieldRef();
                                if (!fr.getField().equals(sf)) {
                                    continue;
                                }
                                if (fr instanceof StaticFieldRef sfr) {
                                    sfr.setFieldRef(sf_new.makeRef());
                                }
                                else if (fr instanceof InstanceFieldRef ifr){
                                    ifr.setFieldRef(sf_new.makeRef());
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public static void modify_innerc(SootClass sc2, SootClass sc1) {
        for (SootClass cls : new ArrayList<>(Scene.v().getApplicationClasses())) {
            if (!cls.hasOuterClass()) {
                continue;
            }
            if (!cls.getOuterClass().equals(sc1)) {
                continue;
            }
            cls.setOuterClass(sc2);
        }
    }
}
