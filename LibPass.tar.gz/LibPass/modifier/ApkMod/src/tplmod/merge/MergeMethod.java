package tplmod.merge;

import soot.*;
import soot.jimple.*;
import soot.util.Chain;
import soot.tagkit.*;





import java.util.*;
import tplmod.Main;
import tplmod.utils.ModUtils;

public class MergeMethod {
    public static int cnt = Main.cnt;

    public static void process(String mtd1Signature, String mtd2Signature, String packing_cls_name){
        if (Main.DEBUG){
            System.out.println("Arg1: "+mtd1Signature);
            System.out.println("Arg2: "+mtd2Signature);
        }

        Map<String, String> matcher1 = ModUtils.parseMethodSignature(mtd1Signature);
        Map<String, String> matcher2 = ModUtils.parseMethodSignature(mtd2Signature);
        if (matcher1.size() < 4 || matcher2.size() < 4){
            System.out.println("Wrong Signature of methods: ");
            System.out.println(mtd1Signature);
            System.out.println(mtd2Signature);
            return;
        }

        String C1N = matcher1.get("className");
        String M1N = matcher1.get("methodSubSignature");
        String C2N = matcher2.get("className");
        String M2N = matcher2.get("methodSubSignature");

        SootClass sc1 = null;
        for (SootClass sct : Scene.v().getApplicationClasses()) {
            if (sct.getName().equals(C1N)) {
                sc1 = sct;
                break;
            }
        }

        SootClass sc2 = null;
        for (SootClass sct : Scene.v().getApplicationClasses()) {
            if (sct.getName().equals(C2N)) {
                sc2 = sct;
                break;
            }
        }

        SootMethod sm1;
        SootMethod sm2;
        try {
            sm1 = sc1.getMethod(M1N);
            sm2 = sc2.getMethod(M2N);
        }catch (Exception e) {
            System.out.println("ERROR: no method");
            System.out.println(e);
            return;
        }

        JimpleBody body1 = (JimpleBody) sm1.retrieveActiveBody();
        JimpleBody body2 = (JimpleBody) sm2.retrieveActiveBody();

        String sm1_origin_signature = sm1.getSignature();
        String sm2_origin_signature = sm2.getSignature();

        // 修饰符修改
        int new_modifiers_c = Modifier.PUBLIC;
        if ((sc1.getModifiers() & Modifier.STRICTFP) != 0 || (sc2.getModifiers() & Modifier.STRICTFP) != 0) {
            new_modifiers_c = new_modifiers_c | Modifier.STRICTFP;
        }
        sc2.setModifiers(new_modifiers_c);
        int new_modifiers_m = merge_methods_modifier(sm1.getModifiers(), sm2.getModifiers());
        sm2.setModifiers(new_modifiers_m);

        List<Type> paramTypes_1 = new ArrayList<>(sm1.getParameterTypes());
        List<Type> paramTypes_2 = new ArrayList<>(sm2.getParameterTypes());

        int sm2ParamCount = sm2.getParameterCount(); // 方法二的参数数量
        int sm1ParamCount = sm1.getParameterCount(); // 方法一的参数数量
        // 新参数设置
        List<Type> paramTypes = new ArrayList<>(sm2.getParameterTypes());
        paramTypes.addAll(sm1.getParameterTypes());
        paramTypes.add(BooleanType.v()); // boolean参数，决定执行控制流
        if (!sm1.isStatic()) { // 非静态，把调用时创建的实例作为参数传入
            paramTypes.add(sc1.getType());
        }
        sm2.setParameterTypes(paramTypes);

        List<String> newnames = new ArrayList<>();
        if (sm2.hasTag("ParamNamesTag")) {
            ParamNamesTag sm2_paramnames = (ParamNamesTag) sm2.getTag("ParamNamesTag");
            newnames.addAll(sm2_paramnames.getNames());
            sm2.removeTag("ParamNamesTag");
        }
        else {
            for (int i = 0; i < sm2ParamCount; i++) {
                newnames.add("paramName" + i);
            }
        }
        if (sm1.hasTag("ParamNamesTag")) {
            ParamNamesTag sm1_paramnames = (ParamNamesTag) sm1.getTag("ParamNamesTag");
            for (String name_t : sm1_paramnames.getNames()) {
                if (newnames.contains(name_t)) {
                    newnames.add(name_t + "New");
                }
                else {
                    newnames.add(name_t);
                }
            }
        }
        else {
            for (int i = 0; i < sm1ParamCount; i++) {
                newnames.add("paramNameSm1" + i);
            }
        }
        newnames.add("paramNameBoolean");
        if (!sm1.isStatic()) {
            newnames.add("paramNameCls1");
        }
        ParamNamesTag newparamnames = new ParamNamesTag(newnames);
        sm2.addTag(newparamnames);


        // 调用方法一的地方需要改成调用方法二（新），方法二如果非静态，需要构建实例，需要void init()
        if (!sm2.isStatic()) {
            boolean sm2_init_check = false;
            for (SootMethod smt : sc2.getMethods()) {
                if (smt.getSubSignature().equals("void <init>()")) {
                    sm2_init_check = true;
                    break;
                }
            }
            if (!sm2_init_check) {
                SootMethod sc2constructor = new SootMethod("<init>", Arrays.asList(), VoidType.v(), Modifier.PUBLIC);
                sc2.addMethod(sc2constructor);
                JimpleBody cbody = Jimple.v().newBody(sc2constructor);
                sc2constructor.setActiveBody(cbody);
                Chain<Local> locals = cbody.getLocals();
                Chain<Unit> units = cbody.getUnits();
                Local thisRef = Jimple.v().newLocal("$this", sc2.getType());
                locals.add(thisRef);
                units.add(Jimple.v().newIdentityStmt(thisRef, Jimple.v().newThisRef(sc2.getType())));
                SootMethod toCall = Scene.v().getMethod("<java.lang.Object: void <init>()>");
                units.add(Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(thisRef, toCall.makeRef())));
                units.add(Jimple.v().newReturnVoidStmt());
            }
        }

        // 将类一所有字段改为public，如果是private，方法一合并后访问不了
        for (SootField sf : sc1.getFields()) {
            sf.setModifiers((sf.getModifiers() & (~(1 << 1))) | Modifier.PUBLIC);
        }

        // 解决重名、添加local
        List<String> local2 = new ArrayList<>();
        for (Local local : body2.getLocals()){
            local2.add(local.getName());
        }
        for (Local local : body1.getLocals()) {
            String originalName = local.getName();
            String newName = originalName;
            int counter = 0;
            while (local2.contains(local.getName())) {
                newName = originalName + counter++;
                local.setName(newName);
            }
            // dont need
//            if (! newName.equals(originalName)) {
//                System.out.println("yes");
//                for (Unit unit : body1.getUnits()) {
//                    // 遍历每个Unit中的UseBoxes，这些Box可能包含对Locals的引用
//                    for (ValueBox box : unit.getUseAndDefBoxes()) {
//                        Value value = box.getValue();
//                        if (value instanceof Local && ((Local) value).getName().equals(originalName)) {
//                            System.out.println(unit);
//                            // 如果这个Unit引用了被重命名的Local，则更新引用
//                            box.setValue(Jimple.v().newLocal(newName, local.getType()));
//                            System.out.println(unit);
//                        }
//                    }
//                }
//            }
            body2.getLocals().add(local);
            local2.add(newName);
        }
        // 加boolean变量
        Local B99Local = Jimple.v().newLocal("$B99", BooleanType.v());
        body2.getLocals().add(B99Local);
        Unit firstNonIdentityUnit = body2.getFirstNonIdentityStmt();
        int booleanIndex = sm2.getParameterCount() - 1;
        if (!sm1.isStatic()) {
            booleanIndex -= 1;
        }
        IdentityStmt newIntParamStmt = Jimple.v().newIdentityStmt(B99Local, Jimple.v().newParameterRef(BooleanType.v(), booleanIndex));
        body2.getUnits().insertBefore(newIntParamStmt, firstNonIdentityUnit);


        for (Unit unit : body1.getUnits()) {
            // 遍历body1中的所有Unit
            for (ValueBox box : unit.getUseAndDefBoxes()) {
                // 检查每个Unit的UseAndDefBoxes
                Value value = box.getValue();
                if (value instanceof ParameterRef) {
                    // 如果Value是ParameterRef类型，说明它是一个参数引用
                    ParameterRef paramRef = (ParameterRef) value;
                    int newIndex = paramRef.getIndex() + sm2ParamCount; // 调整参数索引
                    // 创建一个新的ParameterRef以反映新的参数位置
                    ParameterRef newParamRef = Jimple.v().newParameterRef(paramRef.getType(), newIndex);
                    box.setValue(newParamRef); // 更新ValueBox中的值
                }
            }
        }
        if (!sm1.isStatic()) {
            // 在方法一上，将this申明改成参数申明
            for (Unit unit : body1.getUnits()) {
                if (unit instanceof IdentityStmt stmt) {
                    if (stmt.getRightOp() instanceof ThisRef) {
                        ParameterRef ptr = Jimple.v().newParameterRef(sc1.getType(), sm2.getParameterCount() - 1);
                        stmt.setRightOp(ptr);
                        break;
                    }
                }
            }
        }

        // 控制流处理
        // 方法一代码的开始位置
        Unit method1Start = body1.getUnits().getFirst();
        // 方法二代码执行的位置
        Unit method2Start = body2.getUnits().getFirst();
        Unit method2Last = body2.getUnits().getLast();
        // 在方法二的开始插入一个条件跳转语句，根据$B99的值跳转到方法一代码的开始或执行方法二的代码
        IfStmt ifStmt = Jimple.v().newIfStmt(Jimple.v().newEqExpr(B99Local, IntConstant.v(1)), method1Start);
        body2.getUnits().insertBefore(ifStmt, method2Start);
        body2.getUnits().insertAfter(new ArrayList<>(body1.getUnits()), method2Last);

        // 申明语句必须在最前面
        List<Unit> idtstmts = new ArrayList<>();
        for (Unit unit : body2.getUnits()) {
            if (unit instanceof IdentityStmt idt) {
                if (idt.getRightOp() instanceof ParameterRef || idt.getRightOp() instanceof ThisRef) {
                    idtstmts.add(unit);
                }
            }
        }
        Unit target_stmt = body2.getUnits().getFirst();
        for (Unit unit : idtstmts) {
            // 移除当前位置的声明语句
            body2.getUnits().remove(unit);
            // 将声明语句添加到方法体最前面
            body2.getUnits().insertBefore(unit, target_stmt);
        }

        // 处理返回值，新包装类
        Type returnType1 = sm1.getReturnType();
        Type returnType2 = sm2.getReturnType();
        boolean needWrapper = !returnType1.equals(returnType2);// 两个方法的返回值类型一样的话就不管了
        if (needWrapper && (returnType1.toString().equals("void") || returnType2.toString().equals("void"))) {//void
            Type returnType_t = null;
            if (returnType2.toString().equals("void")) {
                returnType_t = returnType1;
                sm2.setReturnType(returnType_t);
            }
            else if (returnType1.toString().equals("void")) {
                returnType_t = returnType2;
            }

            SootField newField = new SootField("voidTmpField" + (sc2.getFields().size()+1), returnType_t, Modifier.PUBLIC | Modifier.STATIC);
            sc2.addField(newField);
            StaticFieldRef fieldRef = Jimple.v().newStaticFieldRef(newField.makeRef());
            Local tmpLocal = Jimple.v().newLocal("$tmp" + (body2.getLocals().size()+1), newField.getType());


            body2.getLocals().add(tmpLocal);
            AssignStmt assignStmt = Jimple.v().newAssignStmt(tmpLocal, fieldRef);
            body2.getUnits().insertBefore(assignStmt, body2.getFirstNonIdentityStmt());
            for (Iterator<Unit> iter = body2.getUnits().snapshotIterator(); iter.hasNext();) {
                Unit unit = iter.next();
                if (unit instanceof ReturnVoidStmt rvs) {
                    ReturnStmt newreturnstmt = Jimple.v().newReturnStmt(tmpLocal);
                    body2.getUnits().swapWith(rvs, newreturnstmt);
                }
            }
            needWrapper = false;
        }
        SootClass wrapperClass = null;
        if (needWrapper) {
            // String wrapperClassName = sc2.getPackageName() + ".returnwrapper" + cnt++;
            String wrapperClassName = packing_cls_name;
            wrapperClass = new SootClass(wrapperClassName, Modifier.PUBLIC);
            wrapperClass.setSuperclass(Scene.v().getSootClass("java.lang.Object")); // 设置超类为Object
            wrapperClass.setApplicationClass();
            // 添加第一个字段
            SootField field1 = new SootField("method1Return", returnType1, Modifier.PUBLIC);
            wrapperClass.addField(field1);
            // 添加第二个字段
            SootField field2 = new SootField("method2Return", returnType2, Modifier.PUBLIC);
            wrapperClass.addField(field2);
            // 创建构造函数
            SootMethod constructor = new SootMethod("<init>", Arrays.asList(), VoidType.v(), Modifier.PUBLIC);
            wrapperClass.addMethod(constructor);
            // 创建构造函数的body
            JimpleBody wbody = Jimple.v().newBody(constructor);
            constructor.setActiveBody(wbody);
            // 获取构造函数的参数列表和局部变量列表
            Chain<Local> locals = wbody.getLocals();
            Chain<Unit> units = wbody.getUnits();
            // 创建this引用
            Local thisRef = Jimple.v().newLocal("$this", wrapperClass.getType());
            locals.add(thisRef);
            units.add(Jimple.v().newIdentityStmt(thisRef, Jimple.v().newThisRef(wrapperClass.getType())));
            // 调用Object类的构造函数
            SootMethod toCall = Scene.v().getMethod("<java.lang.Object: void <init>()>");
            units.add(Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(thisRef, toCall.makeRef())));
            // 构造函数的返回
            units.add(Jimple.v().newReturnVoidStmt());

            Type returnType = Scene.v().getType(wrapperClass.getName());
            sm2.setReturnType(returnType);

            // 创建包装类实例并设置相应字段
            Local wrapperInstance = Jimple.v().newLocal("$wrapperInstance", RefType.v(wrapperClassName));
            body2.getLocals().add(wrapperInstance);
            for (Iterator<Unit> iter = body2.getUnits().snapshotIterator(); iter.hasNext();) {
                Unit unit = iter.next();
                if (unit instanceof ReturnStmt returnStmt) {
                    Value returnValue = returnStmt.getOp();
                    AssignStmt newInstanceStmt = Jimple.v().newAssignStmt(wrapperInstance, Jimple.v().newNewExpr(RefType.v(wrapperClassName)));
                    InvokeStmt ivkstmt = Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(wrapperInstance, wrapperClass.getMethodByName("<init>").makeRef()));
                    AssignStmt fieldAssignStmt;
                    if (returnStmt.getOp().getType().toString().equals(returnType1.toString())) {
                        // method1Return是对应方法一返回类型的字段
                        fieldAssignStmt = Jimple.v().newAssignStmt(Jimple.v().newInstanceFieldRef(wrapperInstance, field1.makeRef()), returnValue);
                    } else {
                        // method2Return是对应方法二返回类型的字段
                        fieldAssignStmt = Jimple.v().newAssignStmt(Jimple.v().newInstanceFieldRef(wrapperInstance, field2.makeRef()), returnValue);
                    }
                    ReturnStmt newReturnStmt = Jimple.v().newReturnStmt(wrapperInstance);

                    // 在原返回语句前插入新语句
                    body2.getUnits().insertBefore(newInstanceStmt, returnStmt);
                    body2.getUnits().insertBefore(ivkstmt, returnStmt);
                    body2.getUnits().insertBefore(fieldAssignStmt, returnStmt);
                    body2.getUnits().swapWith(returnStmt, newReturnStmt);
                }
            }
        }

        //body2.validate();

        List<SootMethod> xref_m1 = xref_methods(sm1_origin_signature);
        List<SootMethod> xref_m2 = xref_methods(sm2_origin_signature);

        // 修改所有调用
        modify_invoke(xref_m1, true, sm1_origin_signature, paramTypes_2, sm2, needWrapper, wrapperClass, sm1.isStatic(), sc1.getType());
        modify_invoke(xref_m2, false, sm2_origin_signature, paramTypes_1, sm2, needWrapper, wrapperClass, sm1.isStatic(), sc1.getType());

        // 删方法一
        sc1.removeMethod(sm1);
        try {
            sc2.removeMethod(Scene.v().getMethod(sm2_origin_signature));
        }
        catch (Exception e){}
        //ModUtils.insertDebugInfo(body2, "In the Merged Method.");
    }



    public static List<SootMethod> xref_methods(String origin_signature) {
        List<SootMethod> xref_m = new ArrayList<>();
        for (SootClass cls : new ArrayList<>(Scene.v().getApplicationClasses())) {
            for (SootMethod smt : new ArrayList<>(cls.getMethods())) {
                if (smt.isConcrete()) {
                    Body body = smt.retrieveActiveBody();
                    for (Unit unit : body.getUnits()) {
                        if (unit instanceof Stmt) {
                            Stmt stmt = (Stmt) unit;
                            if (stmt.containsInvokeExpr()) {
                                InvokeExpr invokeExpr = stmt.getInvokeExpr();
                                if (invokeExpr.getMethod().getSignature().equals(origin_signature)) {
                                    xref_m.add(smt);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        return xref_m;
    }

    public static void modify_invoke(List<SootMethod> xrefs, boolean is_first, String origin_signature, List<Type> paramTypes, SootMethod sm2, boolean needWrapper, SootClass wrapperClass, boolean sm1Static, Type sc1Type) {
        //is first表示是否是处理第一个方法的相关调用，影响调用的修改和参数的设置
        xrefs.add(sm2);
        for (SootMethod smt : xrefs) {

//            System.out.println(is_first);
//            System.out.println(smt.getSignature());

            SootClass cls = smt.getDeclaringClass();
            if (smt.isConcrete()){
                Body body = smt.retrieveActiveBody();
                Boolean change_flag = false;
                List<Unit> newStmts = new ArrayList<>(); // 处理新参数赋值时，新的要插入的语句
                List<Unit> targetStmts = new ArrayList<>(); // 处理新参数赋值时，插入语句的位置标记
                List<Unit> target_newC2 = new ArrayList<>(); // 处理调用时，新的要插入的语句
                List<Unit> newC2s = new ArrayList<>(); // 处理调用值时，插入语句的位置标记
                List<Local> Locals = new ArrayList<>();
                for (Unit unit : body.getUnits()) {
                    if (unit instanceof Stmt) {
                        Stmt stmt = (Stmt) unit;
                        if (stmt.containsInvokeExpr()) {
                            InvokeExpr invokeExpr = stmt.getInvokeExpr();
                            if (invokeExpr.getMethod().getSignature().equals(origin_signature)) {
//                            System.out.println(unit);
                                change_flag = true;
                                // boolean参数
                                Local BooleanLocal = Jimple.v().newLocal("$B" + (body.getLocals().size()+1), BooleanType.v());
                                body.getLocals().add(BooleanLocal);
                                Value boolvalue = null;
                                if (is_first) {
                                    boolvalue = IntConstant.v(1);
                                } else {
                                    boolvalue = IntConstant.v(0);
                                }
                                AssignStmt BooleanAssignStmt = Jimple.v().newAssignStmt(BooleanLocal, boolvalue);
                                // 处理新参数
                                List<Value> newArgs = new ArrayList<>();
                                if (newStmts.isEmpty()) {
                                    newStmts.add(BooleanAssignStmt);
                                    if (!is_first) {
                                        newArgs.addAll(invokeExpr.getArgs());
                                    }
                                    for (Type t : paramTypes) {
                                        // 新的调用有一些新参数，只构造新local没有赋值没法跑，只能构造字段作为值。
                                        String newFieldName = "newStaticField" + (cls.getFields().size()+1);
                                        SootField newField = new SootField(newFieldName, t, Modifier.PUBLIC | Modifier.STATIC);
                                        cls.addField(newField);
                                        SootField field = cls.getFieldByName(newFieldName);
                                        StaticFieldRef fieldRef = Jimple.v().newStaticFieldRef(field.makeRef());
                                        // 创建一个局部变量来存储静态字段引用的值
                                        Local tmpLocal = Jimple.v().newLocal("$tmp" + (body.getLocals().size()+1), field.getType());

                                        body.getLocals().add(tmpLocal);
                                        Locals.add(tmpLocal);
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(tmpLocal, fieldRef);
                                        newStmts.add(assignStmt); // 收集新的赋值语句
                                        // 使用局部变量作为方法调用的参数
                                        newArgs.add(tmpLocal);
                                    }
                                    if (is_first) {
                                        newArgs.addAll(invokeExpr.getArgs());
                                    }
                                } else {
                                    if (is_first) {
                                        newArgs.addAll(Locals);
                                        newArgs.addAll(invokeExpr.getArgs());
                                    } else {
                                        newArgs.addAll(invokeExpr.getArgs());
                                        newArgs.addAll(Locals);
                                    }
                                }
                                newArgs.add(BooleanLocal);
                                if (!sm1Static) {
                                    if (is_first) {
                                        Local callerLocal = (Local) invokeExpr.getUseBoxes().get(0).getValue();
                                        newArgs.add(callerLocal);
                                    }
                                    else {
                                        String newFieldName = "class1FieldParam" + (cls.getFields().size()+1);
                                        SootField newField = new SootField(newFieldName, sc1Type, Modifier.PUBLIC | Modifier.STATIC);
                                        cls.addField(newField);
                                        StaticFieldRef fieldRef = Jimple.v().newStaticFieldRef(newField.makeRef());
                                        Local tmpLocal = Jimple.v().newLocal("$tmp" + (body.getLocals().size()+1), newField.getType());
                                        body.getLocals().add(tmpLocal);
                                        Locals.add(tmpLocal);
                                        AssignStmt assignStmt = Jimple.v().newAssignStmt(tmpLocal, fieldRef);
                                        newStmts.add(assignStmt);
                                        newArgs.add(tmpLocal);
                                    }
                                }

                                InvokeExpr newInvokeExpr = null;
                                if (is_first) {
                                    if (sm2.isStatic()) {
                                        newInvokeExpr = Jimple.v().newStaticInvokeExpr(sm2.makeRef(), newArgs);
                                    } else {
                                        // 新的方法非静态的话，要构造类实例并修改调用
                                        Local newC2 = Jimple.v().newLocal("$newClassTwo" + (body.getLocals().size()+1), sm2.getDeclaringClass().getType());
                                        body.getLocals().add(newC2);
                                        AssignStmt newCas = Jimple.v().newAssignStmt(newC2, Jimple.v().newNewExpr(sm2.getDeclaringClass().getType()));
                                        InvokeStmt newivk = Jimple.v().newInvokeStmt(Jimple.v().newSpecialInvokeExpr(newC2, sm2.getDeclaringClass().getMethod("void <init>()").makeRef()));
                                        newInvokeExpr = Jimple.v().newSpecialInvokeExpr(newC2, sm2.makeRef(), newArgs);

                                        target_newC2.add(unit);
                                        newC2s.add(newCas);
                                        newC2s.add(newivk);
                                    }
                                    stmt.getInvokeExprBox().setValue(newInvokeExpr);
                                } else {
                                    if (invokeExpr instanceof StaticInvokeExpr) {
                                        newInvokeExpr = Jimple.v().newStaticInvokeExpr(sm2.makeRef(), newArgs);
                                    } else if (invokeExpr instanceof VirtualInvokeExpr vie) {
                                        newInvokeExpr = Jimple.v().newVirtualInvokeExpr((Local) vie.getBase(), sm2.makeRef(), newArgs);
                                    } else if (invokeExpr instanceof SpecialInvokeExpr sie) {
                                        newInvokeExpr = Jimple.v().newSpecialInvokeExpr((Local) sie.getBase(), sm2.makeRef(), newArgs);
                                    } else if (invokeExpr instanceof InstanceInvokeExpr iie) {
                                        newInvokeExpr = Jimple.v().newSpecialInvokeExpr((Local) iie.getBase(), sm2.makeRef(), newArgs);
                                    }
                                    stmt.getInvokeExprBox().setValue(newInvokeExpr);
                                }
                                targetStmts.add(stmt); // 标记当前语句，以便后续在其前面插入新语句
                            }
                            // 反射???
                        }
                    }
                }
                if (change_flag) {

                    for (Unit newStmt : newStmts) {
                        // 新的参数赋值
                        body.getUnits().insertBefore(newStmt, targetStmts.get(0));
                    }
                    if (!target_newC2.isEmpty()) {
                        // 需要构造实例的语句
                        for (int i = 0; i < target_newC2.size(); i++) {
                            body.getUnits().insertBefore(newC2s.get(2 * i), target_newC2.get(i));
                            body.getUnits().insertBefore(newC2s.get(2 * i + 1), target_newC2.get(i));
                        }
                    }
                    if (needWrapper) {
                        // 如果要修改包装类
                        for (Unit targetStmt : targetStmts) {
                            if (targetStmt instanceof AssignStmt assignStmt) {
                                // 如果此次调用有接受返回值
                                Value leftOp = assignStmt.getLeftOp();
                                Value rightOp = assignStmt.getRightOp();

                                if (rightOp instanceof InvokeExpr) {
                                    // 创建新的返回类型实例的局部变量
                                    Local newReturnLocal = Jimple.v().newLocal("$newReturn" + (body.getLocals().size()+1), wrapperClass.getType());
                                    body.getLocals().add(newReturnLocal);

                                    // 将调用表达式的结果赋值给新的局部变量
                                    AssignStmt newAssignStmt = Jimple.v().newAssignStmt(newReturnLocal, rightOp);
                                    body.getUnits().insertAfter(newAssignStmt, targetStmt);
                                    body.getUnits().remove(targetStmt);

                                    // 访问新返回类型中的字段，并将其值赋给原始的局部变量
                                    FieldRef fieldRef1 = Jimple.v().newInstanceFieldRef(newReturnLocal, RefType.v(wrapperClass.getName()).getSootClass().getFields().getFirst().makeRef());
                                    FieldRef fieldRef2 = Jimple.v().newInstanceFieldRef(newReturnLocal, RefType.v(wrapperClass.getName()).getSootClass().getFields().getLast().makeRef());
                                    AssignStmt fieldAssignStmt = null;
                                    if (leftOp.getType().equals(fieldRef1.getType())) {
                                        fieldAssignStmt = Jimple.v().newAssignStmt(leftOp, fieldRef1);
                                    } else {
                                        fieldAssignStmt = Jimple.v().newAssignStmt(leftOp, fieldRef2);
                                    }
                                    body.getUnits().insertAfter(fieldAssignStmt, newAssignStmt);
                                }
                            }
                        }
                    }
                }
//            System.out.println(body);
            }
        }
    }


    public static int merge_methods_modifier(int m1, int m2) {
        int new_modifier = Modifier.PUBLIC;
//        if ((m1 & Modifier.NATIVE) != 0 || (m2 & Modifier.NATIVE) != 0) {
//            new_modifier = new_modifier | Modifier.NATIVE;
//        }
        // 不确定SYNCHRONIZE影响
        if ((m2 & Modifier.STATIC) != 0) {
            new_modifier = new_modifier | Modifier.STATIC;
        }
        if ((m1 & Modifier.SYNCHRONIZED) != 0 || (m2 & Modifier.SYNCHRONIZED) != 0) {
            new_modifier = new_modifier | Modifier.SYNCHRONIZED;
        }
//        if ((m1 & Modifier.ENUM) != 0 || (m2 & Modifier.ENUM) != 0) {
//            new_modifier = new_modifier | Modifier.ENUM;
//        }
        if ((m1 & Modifier.STRICTFP) != 0 || (m2 & Modifier.STRICTFP) != 0) {
            new_modifier = new_modifier | Modifier.STRICTFP;
        }
        return new_modifier;
    }
}
