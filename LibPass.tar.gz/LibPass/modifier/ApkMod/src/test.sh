java -cp .:../ThirdParty/soot-4.5.0-20230320.123751-11-jar-with-dependencies.jar tplmod/Main \
    -ap ../android-platforms-master\
    -app ../test/orig_apk/me.shrimadhavuk.watransmitter.apk\
    -out ../test/out_apk/\
    -mod ../test/mod_file/com.android.support.support-v4.22.2.1.act
# java -jar main-1.0.jar \
#     -cp .:../ThirdParty/soot-4.5.0-20230320.123751-11-jar-with-dependencies.jar \
#     -ap ../android-platforms-master\
#     -app ../test/orig_apk/me.shrimadhavuk.watransmitter.apk\
#     -out ../test/out_apk/\
#     -mod ../test/mod_file/com.android.support.support-v4.22.2.1.act