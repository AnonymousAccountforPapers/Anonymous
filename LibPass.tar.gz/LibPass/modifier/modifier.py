import os
import sys
import time
import uuid
import hashlib
import shutil
from detectors import LibScan
from datetime import datetime

RUN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ApkMod/src")
WORK_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ApkMod/TmpDir")
ANDROID_PLATFORM_JAR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ApkMod/android-platforms-master")

def calculate_file_hash(file_path, algorithm='sha256', chunk_size=4096):
    if algorithm.lower() == 'md5':
        hasher = hashlib.md5()
    elif algorithm.lower() == 'sha1':
        hasher = hashlib.sha1()
    elif algorithm.lower() == 'sha256':
        hasher = hashlib.sha256()
    else:
        raise ValueError("Unsupported algorithm. Please choose 'md5', 'sha1', or 'sha256'.")

    with open(file_path, 'rb') as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            hasher.update(chunk)

    return hasher.hexdigest()

class Modifier:
    def __init__(self, detector, attacker, apk_path, lib_dex_path, dataset, fid, with_score=True, verbose=False):
        self.dataset = dataset
        self.verbose = verbose
        self.time_based_uuid = str(uuid.uuid1())
        self.with_score = with_score
        self.time_base = datetime.now().strftime('%Y-%m-%d_%H:%M')
        
        self.TMP_PATH = os.path.join(WORK_DIR, f"tmp/{detector}/D{dataset}/{attacker}/{os.path.basename(apk_path)}-{os.path.basename(lib_dex_path)}/{self.time_base}/ff{str(fid)}/{'withscore' if self.with_score else 'withoutscore'}/")
        self.TMP_LIB_PATH = os.path.join(self.TMP_PATH, "lib/")
        self.TMP_APP_PATH = os.path.join(self.TMP_PATH, "app/")
        if not os.path.isdir(self.TMP_PATH):
            os.makedirs(self.TMP_PATH)
        if not os.path.isdir(self.TMP_LIB_PATH):
            os.makedirs(self.TMP_LIB_PATH)
        if not os.path.isdir(self.TMP_APP_PATH):
            os.makedirs(self.TMP_APP_PATH)
            
        os.system(f"cp {apk_path} {self.TMP_APP_PATH}")
        os.system(f"cp {lib_dex_path} {self.TMP_LIB_PATH}")
        self.org_apk_path = apk_path
        self.org_lib_dex_path = lib_dex_path
        
        self.tmp_apk_path = os.path.join(self.TMP_APP_PATH, os.path.basename(apk_path))
        self.tmp_lib_path = os.path.join(self.TMP_LIB_PATH, os.path.basename(lib_dex_path))
        self.mod_path = os.path.join(WORK_DIR, f"mod/{detector}/D{dataset}/{attacker}/{os.path.basename(apk_path)}-{os.path.basename(lib_dex_path)}/{self.time_base}/ff{str(fid)}/{'withscore' if self.with_score else 'withoutscore'}/")
        if not os.path.isdir(self.mod_path):
            os.makedirs(self.mod_path)
        self.mod_apk_path = os.path.join(self.mod_path, os.path.basename(apk_path))
        
        if detector == "libscan":
            self.D = LibScan()
        else:
            raise Exception("Unknown detector")
        self.time_consume = []
        
    def recover(self):
        os.system(f"cp {self.org_apk_path} {self.tmp_apk_path}")
        
    def query(self, apk_path, lib_path):
        result = self.D((apk_path, lib_path), score=self.with_score)
        print(f"[=] Query sample hash: {calculate_file_hash(apk_path)}, result:{result}")
        return result
        
    def __call__(self, mod_inst):
        start_time = time.time()
        os.system(f"cd {RUN_DIR} && java -cp .:../ThirdParty/soot-4.5.0-20230320.123751-11-jar-with-dependencies.jar:../ThirdParty/slf4j-nop-2.0.7.jar tplmod/Main -ap {ANDROID_PLATFORM_JAR} -app {self.tmp_apk_path} -out {self.mod_path} -mod \"{mod_inst}\"")
        os.system(f"mv {self.mod_apk_path} {self.tmp_apk_path}")
        result = self.query(self.tmp_apk_path, self.tmp_lib_path)
        self.time_consume.append(time.time() - start_time)
        return result
        
    def destroy_tmp_dir(self):
        shutil.rmtree(self.TMP_PATH)
        shutil.rmtree(self.mod_path)
    
    def avg_query_time(self):
        return sum(self.time_consume) / len(self.time_consume)